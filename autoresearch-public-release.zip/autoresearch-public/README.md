# AutoResearch

LLM 驱动的多智能体自动化 ML 研究框架。给定任务文档、数据与 baseline 代码，框架自主完成复现、假设提出、实验与诊断、任务脚本评测和知识沉淀。

框架代码位于 [autoresearch/](autoresearch/)，使用 Python 实现，由 uv 管理依赖，可直接运行完整自动实验循环，也可基于代码二次开发。

- Planner / Executor / Analysis 等多智能体协作，规划、执行并诊断实验。
- 任务脚本评测：分数由任务自己的 `eval.py` 产出，候选仅在指标严格改善时留存。
- L0–L3 知识体系在实验与运行之间沉淀证据。

安装、配置与使用方式见 [框架文档](autoresearch/README.md)，示例任务见 [example_rmse](autoresearch/tasks/example_rmse/)。

本地执行会运行模型生成的 Shell/Python 代码，并非操作系统沙箱。子进程默认不继承服务凭证，文件工具限制访问范围，但任意代码仍具有当前系统用户的权限。请在无敏感文件的独立环境中运行；安全边界见[框架文档](autoresearch/README.md#运行安全边界)。

## 许可证

本项目采用 [MIT License](LICENSE) 开源，允许商业使用、修改和分发。

分发软件副本或其重要部分时，须保留版权声明和许可声明。软件按原样提供，不提供任何担保；完整条款见 [LICENSE](LICENSE)。
