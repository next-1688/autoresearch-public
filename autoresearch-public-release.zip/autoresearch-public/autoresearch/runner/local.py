from __future__ import annotations

import logging
import os
import shutil
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

from .base import BaseRunner, ExecutionResult
from .environment import build_execution_env
from .watchdog import AnomalyDetector, PhaseDetector, WatchdogConfig
from ..utils.tool_output import new_log_dir, save_output_logs

logger = logging.getLogger(__name__)


class LocalRunner(BaseRunner):
    def __init__(self, watchdog_config: WatchdogConfig | None = None):
        self._wdcfg = watchdog_config or WatchdogConfig()

    def run(
        self, code: str, workdir: Path, timeout: int,
        extra_env: dict[str, str] | None = None, *, entry_path: Path | None = None,
    ) -> ExecutionResult:
        workdir = workdir.resolve()
        workdir.mkdir(parents=True, exist_ok=True)

        if entry_path is not None:
            entry_path = entry_path.resolve()
            if not entry_path.is_relative_to(workdir) or not entry_path.is_file():
                raise ValueError("Python entry must be a file inside the working directory")
            # Execute the saved source with its own __file__/argv/import path.
            # The bootstrap lives separately, so even path='runfile.py' remains intact.
            script_path = new_log_dir(workdir, "python_launcher") / "launcher.py"
            code = (
                "import runpy, sys\n"
                f"sys.path.insert(0, {str(workdir)!r})\n"
                f"sys.path.insert(0, {str(entry_path.parent)!r})\n"
                f"sys.argv = [{str(entry_path)!r}]\n"
                f"runpy.run_path({str(entry_path)!r}, run_name='__main__')\n"
            )
        else:
            script_path = workdir / "runfile.py"

        if extra_env and extra_env.get("DRY_RUN") == "1":
            from .dry_run_guard import DRY_RUN_GUARD_CODE
            extra_env["DRY_RUN_TIMEOUT"] = str(max(timeout - 30, 60))
            code = DRY_RUN_GUARD_CODE + "\n" + code

        script_path.write_text(code, encoding="utf-8")

        phase_detector = PhaseDetector(self._wdcfg.phase_table)
        anomaly_detector = AnomalyDetector(self._wdcfg.anomaly_patterns)

        stdout_lines: list[str] = []
        stderr_lines: list[str] = []
        lock = threading.Lock()
        kill_reason: str | None = None

        def _reader(stream, buf: list[str], scan_anomaly: bool):
            for raw_line in stream:
                line = raw_line.rstrip("\n")
                with lock:
                    buf.append(line)
                    if self._wdcfg.enabled:
                        phase_detector.detect(line)
                        if scan_anomaly:
                            anomaly_detector.scan(line)

        env = build_execution_env(workdir, extra_env)
        # Real self-budget for the training script (85% of the actual kill
        # window). Consumed by generated scripts (see executor prompts) so their
        # calibration matches the true timeout rather than a prompt-baked guess.
        env["AR_TIME_BUDGET"] = str(int(timeout * 0.85))
        # Reduce fragmentation-driven CUDA OOM (the allocator can grow segments
        # instead of failing on a fragmented pool). Respect a caller-provided
        # value if one is already set.
        env.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
        _cudnn_lib = os.path.join(os.path.dirname(os.path.dirname(sys.executable)),
                                  "lib/python3.11/site-packages/nvidia/cudnn/lib")
        if os.path.isdir(_cudnn_lib):
            env["LD_LIBRARY_PATH"] = _cudnn_lib + ":" + env.get("LD_LIBRARY_PATH", "")

        # Auto-setup OpenCL ICD for LightGBM GPU (container environments often miss this)
        if not env.get("OCL_ICD_VENDORS"):
            _ocl_dir = Path("/tmp/ocl_vendors")
            _icd_file = _ocl_dir / "nvidia.icd"
            if not _icd_file.exists():
                try:
                    _ocl_dir.mkdir(parents=True, exist_ok=True)
                    _icd_file.write_text("libnvidia-opencl.so.1\n")
                except OSError:
                    pass
            if _icd_file.exists():
                env["OCL_ICD_VENDORS"] = str(_ocl_dir) + "/"

        start = time.monotonic()
        try:
            proc = subprocess.Popen(
                [sys.executable, str(script_path)],
                cwd=str(workdir),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=env,
                start_new_session=True,
            )
        except Exception as e:
            return ExecutionResult(
                stderr=f"[RUNNER ERROR] Failed to start process: {e}",
                exec_time=time.monotonic() - start,
                exit_code=-1,
            )

        t_out = threading.Thread(target=_reader, args=(proc.stdout, stdout_lines, True), daemon=True)
        t_err = threading.Thread(target=_reader, args=(proc.stderr, stderr_lines, True), daemon=True)
        t_out.start()
        t_err.start()

        gpu_peak_mb: list[int] = [0]
        gpu_monitor_stop = threading.Event()

        target_pgid: int | None = None
        try:
            target_pgid = os.getpgid(proc.pid)
        except (ProcessLookupError, OSError):
            pass

        def _gpu_monitor_pynvml():
            try:
                import pynvml
                pynvml.nvmlInit()
            except Exception:
                return
            try:
                device_count = pynvml.nvmlDeviceGetCount()
                while not gpu_monitor_stop.is_set():
                    group_used = 0
                    for di in range(device_count):
                        handle = pynvml.nvmlDeviceGetHandleByIndex(di)
                        try:
                            procs = pynvml.nvmlDeviceGetComputeRunningProcesses(handle)
                        except Exception:
                            continue
                        for p in procs:
                            try:
                                if os.getpgid(p.pid) == target_pgid:
                                    group_used += (p.usedGpuMemory or 0) // (1024 * 1024)
                            except (ProcessLookupError, OSError):
                                pass
                    if group_used > gpu_peak_mb[0]:
                        gpu_peak_mb[0] = group_used
                    gpu_monitor_stop.wait(timeout=5.0)
            finally:
                try:
                    pynvml.nvmlShutdown()
                except Exception:
                    pass

        def _gpu_monitor_smi():
            while not gpu_monitor_stop.is_set():
                try:
                    out = subprocess.check_output(
                        ["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"],
                        text=True, timeout=3,
                    )
                    for line in out.strip().split("\n"):
                        try:
                            used = int(line.strip())
                            if used > gpu_peak_mb[0]:
                                gpu_peak_mb[0] = used
                        except ValueError:
                            pass
                except Exception:
                    return
                gpu_monitor_stop.wait(timeout=5.0)

        t_gpu: threading.Thread | None = None
        if target_pgid is not None:
            try:
                import pynvml  # noqa: F401
                t_gpu = threading.Thread(target=_gpu_monitor_pynvml, daemon=True)
            except ImportError:
                if shutil.which("nvidia-smi") is not None:
                    t_gpu = threading.Thread(target=_gpu_monitor_smi, daemon=True)
        elif shutil.which("nvidia-smi") is not None:
            t_gpu = threading.Thread(target=_gpu_monitor_smi, daemon=True)
        if t_gpu is not None:
            t_gpu.start()

        poll_interval = self._wdcfg.poll_interval

        while True:
            ret = proc.poll()
            if ret is not None:
                break

            elapsed = time.monotonic() - start

            if elapsed >= timeout:
                kill_reason = "timeout"
                self._kill_process_group(proc)
                break

            if self._wdcfg.enabled and self._wdcfg.kill_on_anomaly and anomaly_detector.triggered:
                kill_reason = f"anomaly:{anomaly_detector.anomalies[0]}"
                self._kill_process_group(proc)
                break

            time.sleep(poll_interval)

        gpu_monitor_stop.set()
        if t_gpu is not None:
            t_gpu.join(timeout=5)

        t_out.join(timeout=5)
        t_err.join(timeout=5)

        elapsed = time.monotonic() - start
        exit_code = proc.returncode if proc.returncode is not None else -9

        stdout = "\n".join(stdout_lines)
        stderr = "\n".join(stderr_lines)

        if kill_reason:
            stderr += f"\n[WATCHDOG] Process killed: {kill_reason}"
            if exit_code == 0:
                exit_code = -9
            logger.warning("Watchdog killed process in %s: %s (%.1fs)", workdir, kill_reason, elapsed)

        stdout_path = stderr_path = None
        try:
            stdout_path, stderr_path = save_output_logs(workdir, "python", stdout, stderr)
        except (OSError, ValueError):
            logger.warning("Could not save complete Python output", exc_info=True)

        submission_dir = workdir / "submission"
        submission_csv = submission_dir / "submission.csv"
        submission_exists = submission_csv.exists()

        artifacts_dir = workdir / "artifacts"
        if not artifacts_dir.is_dir() or not any(artifacts_dir.glob("*.npy")):
            artifacts_dir = None

        try:
            from ..utils.diagnostics import parse_stdout_diagnostics
            stdout_diagnostics = parse_stdout_diagnostics(stdout)
        except Exception:
            stdout_diagnostics = {}

        if len(stdout) > 50_000:
            stdout = stdout[:25_000] + "\n...[TRUNCATED]...\n" + stdout[-25_000:]
        if len(stderr) > 20_000:
            stderr = stderr[:10_000] + "\n...[TRUNCATED]...\n" + stderr[-10_000:]

        phases_elapsed: dict[str, float] = {}
        for phase, entered_at in phase_detector.phases_entered.items():
            phases_elapsed[phase] = time.monotonic() - entered_at

        return ExecutionResult(
            stdout=stdout,
            stderr=stderr,
            exec_time=elapsed,
            exit_code=exit_code,
            submission_exists=submission_exists,
            submission_path=submission_csv if submission_exists else None,
            kill_reason=kill_reason,
            anomalies_detected=anomaly_detector.anomalies,
            phases_entered=phases_elapsed,
            artifacts_dir=artifacts_dir,
            gpu_peak_memory_mb=gpu_peak_mb[0] if gpu_peak_mb[0] > 0 else None,
            stdout_diagnostics=stdout_diagnostics,
            stdout_path=stdout_path,
            stderr_path=stderr_path,
        )

    def _kill_process_group(self, proc: subprocess.Popen) -> None:
        pgid = None
        try:
            pgid = os.getpgid(proc.pid)
        except (ProcessLookupError, OSError):
            pass

        try:
            if pgid:
                os.killpg(pgid, signal.SIGTERM)
            else:
                proc.terminate()
        except (ProcessLookupError, OSError):
            return

        try:
            proc.wait(timeout=self._wdcfg.term_grace_seconds)
        except subprocess.TimeoutExpired:
            try:
                if pgid:
                    os.killpg(pgid, signal.SIGKILL)
                else:
                    proc.kill()
            except (ProcessLookupError, OSError):
                pass
            proc.wait(timeout=2)
