"""Streaming watchdog: phase detection + anomaly early-stop.

Provides PhaseDetector (advance-only state machine) and AnomalyDetector
(regex-based kill triggers) for use with the streaming LocalRunner.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass


# ── Default anomaly patterns (kill triggers) ─────────────────────────────────

DEFAULT_ANOMALY_PATTERNS: list[tuple[str, str]] = [
    (r"loss\s*[:=]\s*(nan|inf)", "Loss diverged to NaN/Inf"),
    (r"\bnan\b.*loss|loss.*\bnan\b", "NaN in loss output"),
    (r"\bOOM\b|Out\s*of\s*[Mm]emory|CUDA out of memory", "OOM"),
    (r"CUDA\s*error|cudaMalloc\s*failed|cudaErrorMemoryAllocation", "CUDA error"),
    (r"NCCL\s*error|NCCL_ERROR", "NCCL error"),
    (r"RuntimeError:\s*CUDA", "CUDA RuntimeError"),
    (r"Killed\s+process|oom-killer|oom_reaper", "OS OOM killer"),
]


# ── Default phase tables ─────────────────────────────────────────────────────

DEFAULT_PHASE_TABLE: list[tuple[str, list[str]]] = [
    ("data_loading", ["loading data", "reading csv", "read_csv", "loading train", "pd.read"]),
    ("training", ["training", "epoch", "train_loss", "fitting", "fold ", "fold_"]),
    ("evaluation", ["evaluation", "val_loss", "val_score", "cv score", "cv_score", "__SCORE__"]),
    ("submission", ["submission", "saving predictions", "submission.csv", "to_csv"]),
]

GPU_PHASE_TABLE: list[tuple[str, list[str]]] = [
    ("compile", ["compiling", "model_params:", "world_size:", "torch.compile"]),
    ("training", ["train_loss:", "epoch", "step ", "lr:", "training"]),
    ("wrap_up", ["averaging", "stopping_early", "wallclock_cap", "ema:", "checkpoint"]),
    ("quantize", ["gptq", "quantiz", "compress", "pruning"]),
    ("evaluation", ["val_loss:", "val_bpb:", "eval", "__SCORE__", "validation"]),
    ("submission", ["submission size", "submission.csv", "saved", "to_csv"]),
]


# ── PhaseDetector ─────────────────────────────────────────────────────────────

class PhaseDetector:
    """Advance-only state machine for training phase detection.

    Configured with an ordered list of (phase_name, [keywords]).
    Phase transitions only advance forward — never backwards.
    """

    def __init__(self, phase_table: list[tuple[str, list[str]]] | None = None):
        self._table = phase_table or DEFAULT_PHASE_TABLE
        self._phase_order = ["init"] + [name for name, _ in self._table]
        self._current_idx = 0
        self._entered_at: dict[str, float] = {"init": time.monotonic()}

    @property
    def current_phase(self) -> str:
        return self._phase_order[self._current_idx]

    @property
    def phases_entered(self) -> dict[str, float]:
        """Returns {phase_name: monotonic_time_entered}."""
        return dict(self._entered_at)

    def detect(self, line: str) -> str:
        """Process a line, advance phase if keywords match. Returns current phase."""
        ll = line.lower()
        best_idx = self._current_idx

        for phase_name, keywords in self._table:
            try:
                idx = self._phase_order.index(phase_name)
            except ValueError:
                continue
            if idx <= self._current_idx:
                continue
            if any(kw in ll for kw in keywords):
                if idx > best_idx:
                    best_idx = idx

        if best_idx > self._current_idx:
            self._current_idx = best_idx
            phase = self._phase_order[best_idx]
            self._entered_at.setdefault(phase, time.monotonic())

        return self.current_phase


# ── AnomalyDetector ───────────────────────────────────────────────────────────

class AnomalyDetector:
    """Scans output lines for anomaly patterns that should trigger early stop."""

    def __init__(self, patterns: list[tuple[str, str]] | None = None):
        raw = patterns if patterns is not None else DEFAULT_ANOMALY_PATTERNS
        self._patterns: list[tuple[re.Pattern, str]] = [
            (re.compile(p, re.IGNORECASE), desc) for p, desc in raw
        ]
        self._detected: list[str] = []

    @property
    def anomalies(self) -> list[str]:
        return list(self._detected)

    @property
    def triggered(self) -> bool:
        return len(self._detected) > 0

    def scan(self, line: str) -> str | None:
        """Scan a line. Returns anomaly description if found, else None."""
        for pattern, description in self._patterns:
            if pattern.search(line):
                if description not in self._detected:
                    self._detected.append(description)
                return description
        return None


# ── WatchdogConfig ────────────────────────────────────────────────────────────

@dataclass
class WatchdogConfig:
    """Configuration for the streaming watchdog."""

    enabled: bool = True
    poll_interval: float = 0.5
    kill_on_anomaly: bool = True
    term_grace_seconds: float = 5.0
    phase_table: list[tuple[str, list[str]]] | None = None
    anomaly_patterns: list[tuple[str, str]] | None = None
