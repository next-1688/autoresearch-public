from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ExecutionResult:
    stdout: str = ""
    stderr: str = ""
    exec_time: float = 0.0
    exit_code: int = -1
    submission_exists: bool = False
    submission_path: Path | None = None
    kill_reason: str | None = None
    anomalies_detected: list[str] = field(default_factory=list)
    phases_entered: dict[str, float] = field(default_factory=dict)
    artifacts_dir: Path | None = None
    gpu_peak_memory_mb: int | None = None
    stdout_diagnostics: dict = field(default_factory=dict)
    stdout_path: Path | None = None
    stderr_path: Path | None = None


class BaseRunner(ABC):
    @abstractmethod
    def run(self, code: str, workdir: Path, timeout: int, extra_env: dict[str, str] | None = None) -> ExecutionResult:
        ...
