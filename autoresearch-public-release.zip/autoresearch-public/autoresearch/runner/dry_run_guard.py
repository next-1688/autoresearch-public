"""Runtime guard code prepended to scripts in DRY_RUN mode.

Monkey-patches expensive operations (large CSV reads, Optuna HPO, multi-fold CV)
to ensure dry-run completes within the timeout, regardless of what the
LLM-generated code does or doesn't truncate.
"""

DRY_RUN_GUARD_CODE = r'''
import os as _guard_os
if _guard_os.environ.get("DRY_RUN") == "1":
    import signal as _guard_signal

    _DRY_TIMEOUT = int(_guard_os.environ.get("DRY_RUN_TIMEOUT", "270"))

    def _dry_alarm_handler(signum, frame):
        raise TimeoutError(
            f"DRY_RUN hard timeout ({_DRY_TIMEOUT}s). "
            "The pipeline is too slow even with truncated data. "
            "Reduce model complexity, number of trials, or folds."
        )
    _guard_signal.signal(_guard_signal.SIGALRM, _dry_alarm_handler)
    _guard_signal.alarm(_DRY_TIMEOUT)

    _DRY_MAX_ROWS = int(_guard_os.environ.get("DRY_RUN_MAX_ROWS", "500"))

    # --- Truncate pd.read_csv ---
    try:
        import pandas as _guard_pd
        _guard_orig_read_csv = _guard_pd.read_csv

        def _guard_read_csv(*args, **kwargs):
            nrows = kwargs.get("nrows")
            if nrows is None or nrows > _DRY_MAX_ROWS:
                kwargs["nrows"] = _DRY_MAX_ROWS
            return _guard_orig_read_csv(*args, **kwargs)

        _guard_pd.read_csv = _guard_read_csv
    except ImportError:
        pass

    # --- Limit Optuna trials ---
    try:
        import optuna as _guard_optuna
        _guard_orig_optimize = _guard_optuna.study.Study.optimize

        def _guard_limited_optimize(self, func, n_trials=None, timeout=None, **kw):
            return _guard_orig_optimize(
                self, func,
                n_trials=min(n_trials or 2, 2),
                timeout=min(timeout or 120, 120),
                **kw,
            )

        _guard_optuna.study.Study.optimize = _guard_limited_optimize
    except ImportError:
        pass

    # --- Limit sklearn KFold / StratifiedKFold splits ---
    try:
        from sklearn.model_selection import KFold as _guard_KFold
        _guard_orig_kf_init = _guard_KFold.__init__

        def _guard_kf_init(self, n_splits=5, **kw):
            _guard_orig_kf_init(self, n_splits=min(n_splits, 2), **kw)

        _guard_KFold.__init__ = _guard_kf_init
    except ImportError:
        pass

    try:
        from sklearn.model_selection import StratifiedKFold as _guard_SKFold
        _guard_orig_skf_init = _guard_SKFold.__init__

        def _guard_skf_init(self, n_splits=5, **kw):
            _guard_orig_skf_init(self, n_splits=min(n_splits, 2), **kw)

        _guard_SKFold.__init__ = _guard_skf_init
    except ImportError:
        pass

    # --- Limit LightGBM boosting rounds for faster convergence ---
    try:
        import lightgbm as _guard_lgb
        _guard_orig_lgb_train = _guard_lgb.train

        def _guard_lgb_train(params, train_set, num_boost_round=100, valid_sets=None, **kw):
            return _guard_orig_lgb_train(
                params, train_set,
                num_boost_round=min(num_boost_round, 50),
                valid_sets=valid_sets,
                **kw,
            )

        _guard_lgb.train = _guard_lgb_train
    except ImportError:
        pass
'''
