"""Minimal environment for local task processes, not an OS sandbox.

Do not forward the parent's environment wholesale: it contains the LLM and
optional service credentials. Tasks should consume already-materialized data.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Mapping


_RUNTIME_VARIABLES = frozenset({
    "PATH", "LANG", "LANGUAGE", "LC_ALL", "LC_CTYPE", "LC_NUMERIC", "TZ",
    "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT",
    "LD_LIBRARY_PATH", "DYLD_LIBRARY_PATH", "DYLD_FALLBACK_LIBRARY_PATH",
    "CUDA_VISIBLE_DEVICES", "CUDA_DEVICE_ORDER", "CUDA_HOME", "CUDA_PATH",
    "NVIDIA_VISIBLE_DEVICES", "NVIDIA_DRIVER_CAPABILITIES",
    "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS",
    "PYTORCH_CUDA_ALLOC_CONF", "PYTORCH_ALLOC_CONF", "OCL_ICD_VENDORS",
    "TOKENIZERS_PARALLELISM", "HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE",
    "HF_ENDPOINT", "TF_CPP_MIN_LOG_LEVEL", "TF_NUM_INTRAOP_THREADS",
    "TF_NUM_INTEROP_THREADS", "CUBLAS_WORKSPACE_CONFIG",
})
_TASK_VARIABLES = frozenset({"DRY_RUN", "DRY_RUN_TIMEOUT", "AR_TIME_BUDGET"})


def build_execution_env(
    workdir: Path,
    extra_env: Mapping[str, str] | None = None,
    *,
    source: Mapping[str, str] | None = None,
) -> dict[str, str]:
    """Allow only runtime settings and give children their own home/cache.

The filesystem and network are still those of the current user. This prevents
implicit credential inheritance; it cannot confine arbitrary Python or shell.
"""
    source = os.environ if source is None else source
    env = {key: value for key, value in source.items() if key in _RUNTIME_VARIABLES}
    env.setdefault("PATH", os.defpath)
    if extra_env:
        unexpected = set(extra_env) - _RUNTIME_VARIABLES - _TASK_VARIABLES
        if unexpected:
            raise ValueError("Unsupported task environment variables: " + ", ".join(sorted(unexpected)))
        env.update(extra_env)

    root = workdir.resolve()
    # Do not allow an old workspace to redirect runtime directories outside it.
    runtime = root / ".runtime"
    for directory in (runtime, runtime / "home", runtime / "cache", runtime / "tmp"):
        if directory.is_symlink() or not directory.resolve().is_relative_to(root):
            raise ValueError("Task runtime directory must stay inside its workspace")
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    env.update({
        "HOME": str(runtime / "home"),
        "USERPROFILE": str(runtime / "home"),
        "XDG_CONFIG_HOME": str(runtime / "home" / ".config"),
        "XDG_CACHE_HOME": str(runtime / "cache"),
        "TMPDIR": str(runtime / "tmp"),
        "TMP": str(runtime / "tmp"),
        "TEMP": str(runtime / "tmp"),
        "PYTHONNOUSERSITE": "1",
        "PYTHONUNBUFFERED": "1",
    })
    return env
