"""The adapter any task gets by handing in one document and two scripts.

The whole idea is that the framework stops understanding the task. It runs a
command the task supplied, reads one number out of what that command printed,
and compares numbers. That is all. Nothing here opens a parquet file, a column
list, an image, or a waveform — which is exactly why a tabular task, a
segmentation task, and an ASR task can all use this class unchanged.

What the task hands over:

  task.md    the document. Objective, metric, data notes, constraints — injected
             whole into every agent's prompt. A handful of its lines are labelled
             (`指标:`, `训练数据:`, `评测命令:` …) and read by the framework; see
             `document.py` for why those are the same lines a human writes.
  train.py   the baseline. Every experiment starts as a copy of it.
  eval.py    the evaluation. Prints ``<metric>: <number>``, and is run by the
             framework from outside the agent's workspace and file-tool write scope.

The validation labels are the one thing no configuration mentions: they live inside
the evaluation script, outside the agent file tools' scope. Local shell/Python
execution is not sandboxed: strong label isolation requires a separate identity
or evaluation service, as described in the README.

The two things the framework guarantees are the two that searching needs: every
candidate is scored by the same command as the baseline, and the score comes from
that command's live output rather than from a file an experiment left behind.
Absolute correctness of the metric belongs to the task, which defined it.
"""

from __future__ import annotations

import json
import logging
import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any

from .base_task import BaseTaskAdapter
from ..utils.metric_extract import require_metric
from ..runner.environment import build_execution_env

logger = logging.getLogger(__name__)

#: The only split there is. The framework trains on what the document calls the
#: training data and scores on what it calls the validation data; the labels for
#: that scoring never leave the task's evaluation script. Kept as a named
#: constant because `evaluate()` and the eval tool still pass a split around, and a
#: bare "dev" string in six places is how a second split silently appears.
_SEARCH_SPLIT = "dev"


class GenericAdapter(BaseTaskAdapter):
    """Command-driven adapter: run a command, read one number, compare."""

    # ─── Metric ───

    @property
    def _evaluation(self) -> dict[str, Any]:
        return self._config.get("evaluation", {}) or {}

    @property
    def metric_name(self) -> str:
        metric = str(self._evaluation.get("metric", "")).strip()
        if not metric:
            raise ValueError(
                f"{self._config_path}: evaluation.metric is required — it is the "
                "name the framework looks for in your eval command's output."
            )
        return metric

    @property
    def metric_lower_is_better(self) -> bool:
        """Which way is better, already resolved when the document was read.

        The document may say 越小越好 or `minimize`; `parse_task_document` turns
        either into one of two words and refuses anything it cannot place, so there
        is no default to fall back on here. A default would be the wrong answer for
        half of all tasks and would show up as a regression being promoted.
        """
        return str(self._evaluation.get("direction", "")).strip().lower() == "minimize"

    # ─── Framework policy ───

    @property
    def allowed_eval_splits(self) -> set[str]:
        """Only dev. The test location never reaches the agent's environment."""
        return {_SEARCH_SPLIT}

    @property
    def wants_analysis_agents(self) -> bool:
        return bool(self._settings.get("analysis_agents", True))

    @property
    def protected_paths(self) -> list[str]:
        return ["input", ".labels", "task.md"]

    # ─── Data locations (passed through, never read) ───

    @property
    def _data(self) -> dict[str, Any]:
        return self._config.get("data", {}) or {}

    def _location(self, split: str) -> str:
        """Where a split lives, as the task wrote it.

        Returned as a string, not a Path: a remote URI is not a
        filesystem path and must survive untouched so the agent's own reader can
        use it directly instead of the framework pulling it local.
        """
        raw = self._data.get(split)
        if not raw:
            return ""
        text = str(raw)
        if self._is_remote(text):
            return text
        return str(self._resolve_task_path(text))

    @staticmethod
    def _is_remote(location: str) -> bool:
        return "://" in location

    @property
    def agent_visible_locations(self) -> dict[str, str]:
        """Every location the framework knows — which is every location it declares.

        There is no hidden entry here, because the thing that must stay hidden is not
        a location the framework holds: the validation labels are read by the
        task's evaluation script and named nowhere else. So the agent is told
        both of these, and telling it is correct — it has to train on one and predict
        the other.
        """
        visible = {}
        for split in ("train", "val"):
            location = self._location(split)
            if location:
                visible[split] = location
        return visible

    # ─── Workspace ───

    def setup_workspace(self, workspace_dir: Path) -> None:
        input_dir = workspace_dir / "input"
        for path in (
            input_dir,
            workspace_dir / "working",
            workspace_dir / "submission",
        ):
            path.mkdir(parents=True, exist_ok=True)

        self._workspace_input_dir = input_dir
        # The document is copied in verbatim. It is also injected into every role's
        # prompt, and having it on disk is what lets an agent re-read the part it
        # needs instead of relying on what its context still holds.
        (input_dir / "task.md").write_text(self.task_description, encoding="utf-8")
        self._write_data_locations(input_dir)

        # Deliberately does NOT run the baseline here. For a task whose evaluation
        # reports its own reference on every call, running it would be a full
        # training run whose result is never used; and `check()` runs it when the
        # point is to prove it runs at all.
        logger.info("generic workspace prepared at %s", workspace_dir)

    def _write_data_locations(self, input_dir: Path) -> None:
        """Tell the agent where the data is — not what is in it.

        The framework never opens these locations, so a directory of images and
        a remote dataset are handled identically: the path is data the agent's code
        consumes.
        """
        payload: dict[str, Any] = {
            "locations": self.agent_visible_locations,
            "note": (
                "Read these directly from your training code. Remote locations "
                "must be accessible using the task's configured reader."
            ),
        }
        (input_dir / "data_locations.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )

    # ─── Baseline: cached, or one run if not ───

    def _baseline_cache_path(self, workspace_dir: Path) -> Path:
        return workspace_dir / "working" / "baseline_value.json"

    def _ensure_baseline_value(self, workspace_dir: Path) -> float | None:
        """The framework's own reference number: this run's fixed baseline score.

        A supplied baseline is measured by running its command, at most once
        per workspace — a baseline is a fixed reference, so re-running it per
        experiment would only add cost and variance. A task that supplies no
        baseline gets its reference from the run itself (the round that
        generates one, or a continuation from a previous run's best), and
        that lands in the same cache — so the cache is consulted first and is
        the only source when there is no command.
        """
        cache = self._baseline_cache_path(workspace_dir)
        if cache.exists():
            cached = json.loads(cache.read_text(encoding="utf-8"))
            value = cached.get(self.metric_name)
            if self._is_finite_number(value):
                logger.info(
                    "reusing cached baseline %s=%s from %s",
                    self.metric_name,
                    value,
                    cache,
                )
                return float(value)

        if not self._baseline_command:
            return None

        value = self._run_baseline(workspace_dir)
        self.record_baseline_reference(workspace_dir, value, "baseline_command")
        return value

    def record_baseline_reference(
        self, workspace_dir: Path, value: float, source: str
    ) -> None:
        """Persist a run-established baseline score into the reference cache.

        With no supplied baseline there is no command to measure one with, so
        the reference comes from the round that established the initial
        incumbent (``baseline_generation``) or from continuing a previous
        run's best snapshot. Writing it here puts later rounds on the exact
        same code path a supplied baseline uses.
        """
        self._write_json_atomic(
            self._baseline_cache_path(workspace_dir),
            {
                "metric": self.metric_name,
                self.metric_name: value,
                "source": source,
            },
        )
        logger.info(
            "baseline reference %s=%s recorded (%s)",
            self.metric_name,
            value,
            source,
        )

    def _run_baseline(self, workspace_dir: Path) -> float:
        """Run the supplied baseline once and score it with the eval command."""
        command = self._baseline_command
        run_dir = workspace_dir / "baseline_run"
        submission = run_dir / self.submission_relpath
        submission.parent.mkdir(parents=True, exist_ok=True)
        # Stage the baseline through the same workspace preparation as candidates
        # so they receive the same inputs, entry script, and reference metadata.
        #
        # plan.md pins the mode: prepare_executor_workspace otherwise forks from
        # the incumbent when one exists, which would make "the baseline" mean the
        # current best model on any run started with --incumbent-from.
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir / "plan.md").write_text(
            "# baseline\n\nexperiment_mode: supplied_baseline_reproduction\n",
            encoding="utf-8",
        )
        script = self._supplied_train_path()
        if not script.exists():
            raise FileNotFoundError(f"baseline.script not found: {script}")
        self.prepare_executor_workspace(run_dir, workspace_dir)

        logger.info("running baseline command in %s", run_dir)
        self._run(
            command,
            cwd=run_dir,
            substitutions=self._substitutions(run_dir, submission, _SEARCH_SPLIT),
            log_prefix=run_dir / "baseline",
            timeout=self._timeout("baseline"),
        )
        value, _ = self._score_submission(submission, _SEARCH_SPLIT, run_dir)
        logger.info("baseline %s=%s", self.metric_name, value)
        return value

    # ─── Evaluation ───

    def evaluate(
        self,
        workspace_dir: Path,
        split: str = _SEARCH_SPLIT,
        execution_timeout: float | None = None,
    ) -> dict[str, Any]:
        """Score the experiment's submission with the task's own command."""
        submission = workspace_dir / self.submission_relpath
        if not submission.exists():
            return self._invalid_result(f"submission not found: {submission}")

        try:
            score, extra = self._score_submission(
                submission, split, workspace_dir, timeout=execution_timeout
            )
        except Exception as exc:
            return self._invalid_result(f"evaluation failed: {exc}")

        try:
            baseline_value = self._baseline_threshold(workspace_dir, extra)
        except Exception as exc:
            return self._invalid_result(f"baseline value unavailable: {exc}")
        if baseline_value is None:
            if self._read_experiment_mode(workspace_dir) == "baseline_generation":
                # The round that creates the baseline has nothing to be
                # measured against — its own score IS the reference, and it
                # is cached on acceptance so every later round reads it
                # through the normal path.
                baseline_value = score
            else:
                return self._invalid_result(
                    "no baseline to compare against: the evaluation reported no "
                    f"{self.baseline_metric_key}, and the document gives no training "
                    "command to measure one. A score with nothing to beat cannot "
                    "decide retention."
                )

        reference = f"baseline {baseline_value}"
        result = {
            "score": score,
            self.metric_name: score,
            self.baseline_metric_key: baseline_value,
            "valid": True,
            "details": (
                f"{self.metric_name}={score} ({reference}, "
                f"{'lower' if self.metric_lower_is_better else 'higher'} is better) "
                f"submission={submission}"
            ),
        }
        # The evaluator's diagnostics go in underneath, so the score, the
        # threshold, and validity stay the framework's to state.
        for key, value in extra.items():
            result.setdefault(key, value)
        return result

    def _baseline_threshold(
        self, workspace_dir: Path, extra: dict[str, Any]
    ) -> float | None:
        """The number a candidate has to beat, on the rows it was scored on.

        An evaluation that computes its own reference — a task-defined rule ranked over
        the same rows in the same pass — wins over a value the framework cached from
        a baseline run. It is measured on exactly the rows the candidate was measured
        on, whereas a cached number can outlive the data it came from.
        """
        reported = extra.get(self.baseline_metric_key)
        if self._is_finite_number(reported):
            return float(reported)
        return self._ensure_baseline_value(self._resolve_run_root(workspace_dir))

    def _score_submission(
        self,
        submission: Path,
        split: str,
        plan_dir: Path,
        *,
        timeout: float | None = None,
    ) -> tuple[float, dict[str, Any]]:
        """Run the eval command from outside the agent's workspace and read the score.

        ``cwd`` is the task's own directory, so the script the agent is
        graded by is not a file the agent can reach and edit. The score comes from
        the live stdout, not from a file the run left behind, so there is nothing
        on disk to forge either.

        Returns the score plus whatever the evaluator wrote to ``{metrics_out}``.
        Those extras are diagnostics for the agents to read — a per-segment
        breakdown, pool churn — and are recorded alongside the score; the score
        itself never comes from them.
        """
        command = str(self._evaluation.get("command", "")).strip()
        if not command:
            raise ValueError(
                f"{self._config_path}: evaluation.command is required — it is how "
                "the framework turns a submission into a number."
            )
        # Remove any previous file first: a stale one from an earlier evaluation
        # of this same directory would otherwise be read as this run's output.
        extra_path = self._extra_metrics_path(plan_dir)
        extra_path.unlink(missing_ok=True)

        evaluator_cwd = self._evaluator_cwd()
        completed = self._run(
            command,
            cwd=evaluator_cwd,
            substitutions=self._substitutions(plan_dir, submission, split),
            log_prefix=plan_dir / "eval",
            timeout=timeout if timeout is not None else self._timeout("evaluation"),
        )
        score = require_metric(
            completed.stdout + "\n" + completed.stderr,
            self.metric_name,
            source=f"eval command output ({split})",
        )
        return score, self._read_extra_metrics(extra_path)

    def _read_extra_metrics(self, path: Path) -> dict[str, Any]:
        """Diagnostics the evaluator chose to publish, or nothing.

        A task whose eval command only prints a number never creates this
        file, so the absence is the normal case and not a warning.
        """
        if not path.is_file():
            return {}
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("ignoring unreadable evaluator metrics at %s: %s", path, exc)
            return {}
        if not isinstance(payload, dict):
            logger.warning("ignoring evaluator metrics at %s: not a JSON object", path)
            return {}
        return payload

    def _evaluator_cwd(self) -> Path:
        """The task's own directory — where its document and scripts live.

        Not the experiment's directory, and not configurable. Running beside its
        own script lets evaluation find labels using relative paths. This separates
        workflow locations, not OS permissions; local arbitrary code is not sandboxed.
        """
        if self._config_path is not None:
            return self._config_path.parent
        return Path.cwd()

    # ─── Command plumbing ───

    def _substitutions(
        self, plan_dir: Path, submission: Path, split: str
    ) -> dict[str, str]:
        """Placeholders a document may use in its training / evaluation commands.

        ``{train}`` and ``{val}`` are the locations the document declared. There is
        deliberately no placeholder for the validation labels: an evaluation script
        knows where its own labels are, and a framework that could substitute that
        path would also be able to leak it — into a log line, an error message, or a
        prompt.

        ``{incumbent}`` and ``{metrics_out}`` are for evaluations that report more
        than a number: churn against the accepted model, a per-segment breakdown.
        Both are always substituted, so a command can name them unconditionally; when
        nothing is accepted yet, ``{incumbent}`` is a path that does not exist, which
        an evaluation reads as "nothing to compare against" rather than as an error.
        """
        return {
            "python": sys.executable,
            "submission": str(submission),
            "split": split,
            "plan_dir": str(plan_dir),
            "run_root": str(self._resolve_run_root(plan_dir)),
            "train": self._location("train"),
            "val": self._location("val"),
            "incumbent": str(self._incumbent_submission_path(plan_dir)),
            "metrics_out": str(self._extra_metrics_path(plan_dir)),
        }

    def _incumbent_submission_path(self, plan_dir: Path) -> Path:
        """Where the currently accepted model's submission lives, if any.

        Returns a deliberately nonexistent path when nothing is accepted yet,
        rather than an empty string: an empty substitution would collapse the
        evaluator's argument list and make the next flag look like its value.
        """
        run_root = self._resolve_run_root(plan_dir)
        try:
            state = self._load_incumbent_state(run_root)
        except ValueError:
            state = None
        if state:
            path = str(state.get("submission_path", "")).strip()
            if path:
                return Path(path)
        return run_root / ".no_incumbent"

    @staticmethod
    def _extra_metrics_path(plan_dir: Path) -> Path:
        return plan_dir / "eval_metrics.json"

    def _extra_candidate_issues(self, plan_dir: Path) -> list[str]:
        """Artifact problems the evaluator reported, if it reported any.

        A task whose deliverable has rules the framework cannot check — which
        raw columns a model is allowed to declare as inputs, what a reload proof
        must contain — states them in its own evaluator and lists the violations
        under ``artifact_issues``. They block promotion without becoming
        framework knowledge, and without invalidating a score that is otherwise
        real.
        """
        issues = self._read_extra_metrics(self._extra_metrics_path(plan_dir)).get(
            "artifact_issues"
        )
        if not isinstance(issues, list):
            return []
        return [str(issue) for issue in issues if str(issue).strip()]

    @staticmethod
    def _apply_substitutions(command: str, substitutions: dict[str, str]) -> str:
        """Replace ``{name}`` tokens without touching anything else.

        Deliberately not ``str.format``: a command containing a JSON literal or a
        shell brace expansion would otherwise raise KeyError, and the task author
        would have to learn to escape braces to run their own script.
        """
        for key, value in substitutions.items():
            command = command.replace("{" + key + "}", value)
        return command

    def _timeout(self, kind: str) -> float | None:
        """How long a framework-run command may take, from the run config.

        A timeout is a property of the machine and the schedule, not of the task, so
        it lives in the one config file an operator edits rather than in the
        task's document. ``None`` means no limit.
        """
        raw = self._settings.get(f"{kind}_timeout")
        return float(raw) if raw is not None else None

    def _run(
        self,
        command: str,
        *,
        cwd: Path,
        substitutions: dict[str, str],
        log_prefix: Path,
        timeout: float | None,
    ) -> subprocess.CompletedProcess[str]:
        resolved = self._apply_substitutions(command, substitutions)
        cwd.mkdir(parents=True, exist_ok=True)
        env = build_execution_env(log_prefix.parent)
        # The framework's own package must be importable from the task's cwd
        # so evaluation scripts can import the framework without vendoring it.
        repo_root = str(Path(__file__).resolve().parents[2])
        env["PYTHONPATH"] = (
            repo_root
            if not env.get("PYTHONPATH")
            else repo_root + os.pathsep + env["PYTHONPATH"]
        )

        logger.info("running: %s (cwd=%s)", resolved, cwd)
        try:
            completed = subprocess.run(
                shlex.split(resolved),
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=env,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise TimeoutError(
                f"command timed out after {timeout}s: {resolved}"
            ) from exc

        log_prefix.parent.mkdir(parents=True, exist_ok=True)
        log_prefix.with_suffix(".stdout.log").write_text(
            completed.stdout, encoding="utf-8"
        )
        log_prefix.with_suffix(".stderr.log").write_text(
            completed.stderr, encoding="utf-8"
        )
        if completed.returncode != 0:
            tail = (completed.stderr or completed.stdout or "").strip().splitlines()
            raise RuntimeError(
                f"command exited {completed.returncode}: {resolved}\n"
                + "\n".join(tail[-20:])
            )
        return completed

    # ─── Prompt context ───

    def get_task_context(self) -> dict[str, Any]:
        """What the agents are told.

        The document goes in whole. Its objective, metric definition, data notes,
        and constraints are already written there in the task's own words —
        re-expressing them as structured fields would mean maintaining the same
        statements twice and letting them drift apart.
        """
        locations = self.agent_visible_locations
        direction = "lower is better" if self.metric_lower_is_better else "higher is better"
        return {
            # `task_description` is the name every role's template reads. It was
            # published as `task_document` once, which nothing rendered: the
            # planner receives the document as an explicit constructor argument,
            # so only it had one, and executor / analysis / summarizer — who build
            # their context by splatting this dict — silently rendered no document
            # at all. A key nobody reads is indistinguishable from a missing one.
            "task_description": self.task_description,
            # `metric` and `metric_direction` in the codebase's own vocabulary:
            # every agent splats this dict into its template context, and the
            # prompts render `{{ metric }}` / `{{ metric_direction }}` with
            # `minimize|maximize` defaults. Publishing only `metric_name` here
            # left the prompts stating "Metric: unknown".
            "metric": self.metric_name,
            "metric_name": self.metric_name,
            "metric_direction": "minimize" if self.metric_lower_is_better else "maximize",
            # Whether the document supplies a baseline pair to reproduce. The
            # planner branches on it: with none, the first round generates a
            # baseline (and later runs continue from a previous run's best).
            "supplied_baseline": self.has_supplied_baseline,
            "data_locations": locations,
            "entry_script": self.entry_script_name,
            "submission_spec": {
                "path": "./" + self.submission_relpath,
                "metric": f"{self.metric_name} ({direction})",
                "note": (
                    "The framework scores this file with the task's own evaluation "
                    "command, run outside this workspace."
                ),
            },
            "evaluation_rule": (
                f"Your submission is written to ./{self.submission_relpath} and scored "
                f"by the task's own evaluation script, which reports `{self.metric_name}` "
                f"({direction}). The framework runs it outside this workspace. "
                "Do not read or change evaluation scripts or hidden validation labels. "
                "The same script scores the baseline and every "
                f"candidate, so scores are directly comparable. Your data is "
                f"{sorted(locations)}; there is nothing else to read."
            ),
            "data_summary": "\n".join(
                f"- {split}: {location}" for split, location in locations.items()
            )
            or "(no data locations declared)",
        }

    # ─── Self-check ───

    def check(
        self, workspace_dir: Path, submission: Path | None = None
    ) -> dict[str, Any]:
        """Prove the contract holds before spending a search on it.

        Verifies the three things everything else rests on: the baseline command
        runs, the eval command prints the metric the document named, and the same
        submission scores the same number twice. Without the third, every later
        delta is indistinguishable from noise.

        ``submission`` scores an existing file instead of training a baseline to
        produce one. For a task whose baseline is hours of GPU time, running it
        just to obtain something to score defeats the purpose of a pre-flight
        check — and the two things worth checking (the evaluator is a function of
        its input, and a threshold exists) need any valid submission, not
        specifically the baseline's.

        A task that supplies no baseline cannot check any of this here — the
        reference is established by the run's first ``baseline_generation``
        round — so the reduced check proves only that the document parses, the
        data exists, and the workspace prepares.
        """
        report: dict[str, Any] = {"ok": False, "steps": []}

        def step(name: str, ok: bool, detail: str = "") -> None:
            report["steps"].append({"step": name, "ok": ok, "detail": detail})

        try:
            metric = self.metric_name
            direction = "minimize" if self.metric_lower_is_better else "maximize"
            step("config", True, f"metric={metric} direction={direction}")
        except Exception as exc:
            step("config", False, str(exc))
            return report

        missing = [s for s in ("train", "val") if not self._location(s)]
        step(
            "data locations",
            not missing,
            f"missing: {missing}" if missing else str(self.agent_visible_locations),
        )
        if missing:
            return report

        try:
            self.setup_workspace(workspace_dir)
            step("workspace", True, f"prepared {workspace_dir}")
        except Exception as exc:
            step("workspace", False, str(exc))
            return report

        if submission is not None:
            if not submission.exists():
                step("supplied submission", False, f"not found: {submission}")
                return report
            step("supplied submission", True, f"{submission} (baseline not run)")
            score_dir = workspace_dir
        else:
            try:
                baseline = self._ensure_baseline_value(workspace_dir)
                if baseline is not None:
                    detail = f"{self.metric_name}={baseline}"
                elif not self.has_supplied_baseline:
                    detail = (
                        "no supplied baseline — the run's first "
                        "baseline_generation round establishes the reference"
                    )
                else:
                    detail = (
                        "nothing to run — the evaluator must report "
                        f"{self.baseline_metric_key} itself"
                    )
                step("baseline runs", True, detail)
            except Exception as exc:
                step("baseline runs", False, str(exc))
                return report
            score_dir = workspace_dir / "baseline_run"
            submission = score_dir / self.submission_relpath

        if not submission.exists():
            step(
                "evaluation is deterministic",
                True,
                "skipped: nothing produced a submission to re-score. Pass "
                "--check-submission to check the evaluator against an existing one.",
            )
            report["ok"] = True
            report["metric"] = self.metric_name
            report["direction"] = direction
            return report

        # The same submission scored twice. A difference means the evaluator is
        # not a function of its input, and no candidate-vs-baseline delta from it
        # can be trusted.
        try:
            first, extra = self._score_submission(submission, _SEARCH_SPLIT, score_dir)
            second, _ = self._score_submission(submission, _SEARCH_SPLIT, score_dir)
            same = first == second
            step(
                "evaluation is deterministic",
                same,
                f"{first} vs {second}" + ("" if same else "  <- differs"),
            )
            if not same:
                return report
            # Resolved against the workspace, not `score_dir`: score_dir may be
            # `<workspace>/baseline_run`, which has no `working/` above it, so the
            # cache lookup would miss and run the whole baseline a second time —
            # into `baseline_run/baseline_run`.
            threshold = self._baseline_threshold(workspace_dir, extra)
            step(
                "a threshold to beat exists",
                threshold is not None,
                f"{self.baseline_metric_key}={threshold}"
                if threshold is not None
                else "neither the evaluator nor the config supplied one",
            )
            if threshold is None:
                return report
        except Exception as exc:
            step("evaluation is deterministic", False, str(exc))
            return report

        report["ok"] = True
        report["metric"] = self.metric_name
        report["direction"] = direction
        return report
