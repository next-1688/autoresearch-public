"""Lazy benchmark loading; generic task documents keep their existing entry point."""

from __future__ import annotations

import importlib
from pathlib import Path

from .adapter import TaskAdapter

BENCH_REGISTRY = {"mlebench": "autoresearch.task.mlebench:MLEBenchAdapter"}


def create_adapter(
    bench_name: str, bench_dir: Path | None = None, **kwargs
) -> TaskAdapter:
    try:
        module_name, class_name = BENCH_REGISTRY[bench_name].split(":")
    except KeyError:
        raise ValueError(
            f"Unknown bench {bench_name!r}; available: {sorted(BENCH_REGISTRY)}"
        ) from None
    adapter_cls = getattr(importlib.import_module(module_name), class_name)
    return adapter_cls(bench_dir, **kwargs)
