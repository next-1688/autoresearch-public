"""Shared machinery for task adapters: config, incumbent, history, snapshots.

Everything here is task-agnostic. It knows how an experiment gets promoted, how
the incumbent is stored, and how a run's trajectory is recorded — but nothing
about columns, modalities, or how a score is computed. A subclass supplies four
things and inherits the rest:

  metric_name / metric_lower_is_better   what "better" means
  evaluate()                             produce the number
  setup_workspace()                      lay out the data
  get_task_context()                     what the agents are told

The promotion rule is the part worth reading twice. A candidate is accepted only
if it strictly beats the current incumbent, in the metric's own direction; a
valid supplied-baseline reproduction establishes the initial incumbent. The
task's baseline is recorded in the decision and history as evidence, but it is
not a second retention gate: a generic task may have no baseline, and once the
baseline is seeded as the incumbent, beating the incumbent already covers it.
``_promote_lock`` serializes the read-compare-write so parallel executors promote
against each other rather than last-writer-wins.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shutil
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..harness.telemetry import get_recorder
from .adapter import TaskAdapter
from .document import parse_task_document

logger = logging.getLogger(__name__)

#: The one file a task hands in. Everything the framework reads is a labelled
#: line inside it (see `document.py`); everything else in it is what the agents
#: read as the task narrative.
_DOCUMENT_NAME = "task.md"

#: Where an experiment leaves its predictions, relative to its own directory. A
#: fixed location rather than a declared one: it is the framework's own filing
#: convention, not a fact about the task, and the task's evaluation command
#: is handed the path anyway.
_SUBMISSION_RELPATH = "submission/submission.csv"


class BaseTaskAdapter(TaskAdapter):
    """Config loading, incumbent promotion, snapshotting, and run history."""

    def __init__(
        self,
        task_dir: Path | None = None,
        *,
        task_config: Path | None = None,
        task_settings: dict[str, Any] | None = None,
        **_: Any,
    ) -> None:
        # Operator settings from the run config (timeouts, whether diagnostic agents
        # are offered). They are deliberately not read from the task's document:
        # they describe the machine and the schedule this run has, and the same task
        # is run under different ones.
        self._settings: dict[str, Any] = dict(task_settings or {})
        self._task_dir = Path(task_dir).resolve() if task_dir is not None else None
        self._config_path = self._resolve_config_path(task_config)
        # A task hands in ONE document, and it goes to the agents whole. The
        # framework's own values are labelled lines inside that same prose, so there
        # is no second copy of them to drift, and nothing in the file has to be
        # withheld: the only location that must stay hidden is the validation
        # labels, and that one lives inside the task's evaluation script.
        self._embedded_description = ""
        if self._config_path is None:
            self._config = {}
        else:
            text = self._config_path.read_text(encoding="utf-8")
            self._config = parse_task_document(text, self._config_path)
            self._validate_baseline_contract()
            self._embedded_description = text.strip()
        self._workspace_input_dir: Path | None = None
        self._workspace_labels_dir: Path | None = None
        self._manifest_text = ""
        # Serializes the incumbent read-compare-write in sync_best_result so
        # parallel executor experiments can promote atomically without racing on
        # the shared incumbent state.
        self._promote_lock = threading.Lock()

    # ─── Config ───

    def _resolve_config_path(self, task_config: Path | None) -> Path | None:
        """The task's document. One name, because there is one file.

        A directory holding it resolves to it; a path to the file itself is taken
        as given, so a task can keep its document anywhere.
        """
        if task_config is not None:
            return Path(task_config).resolve()
        if self._task_dir is None:
            return None
        if self._task_dir.is_file():
            return self._task_dir
        candidate = self._task_dir / _DOCUMENT_NAME
        if candidate.exists():
            logger.info("task document: %s", candidate)
            return candidate.resolve()
        return None

    def _resolve_task_path(self, raw: str) -> Path:
        """Resolve a path the document wrote, relative to the task's own dir.

        A task writes ``eval.py`` meaning the one next to its document — not one
        relative to wherever the framework happens to be installed. Absolute paths
        and anything that does not exist under the task dir are returned as
        written, so the error names the path the document actually gave.
        """
        path = Path(raw).expanduser()
        if path.is_absolute():
            return path
        for base in (
            self._config_path.parent if self._config_path is not None else None,
            self._task_dir,
        ):
            if base is None:
                continue
            candidate = base / path
            if candidate.exists():
                return candidate.resolve()
        return path

    # ─── Task description ───

    @property
    def task_description(self) -> str:
        """The document, whole.

        There is no second source and no assembled summary. The labelled lines the
        framework reads stay in it: an agent benefits from knowing the metric and
        where the data is, and removing them would mean the prompt and the framework
        disagree about what the task said.
        """
        return self._embedded_description

    @property
    def data_dir(self) -> Path:
        if self._workspace_input_dir is not None:
            return self._workspace_input_dir
        if self._task_dir is not None:
            return self._task_dir
        return Path.cwd()

    # ─── Baseline contract ───

    @property
    def _baseline_script(self) -> str:
        """The document's baseline code path, "" when it supplies none."""
        return str(
            (self._config.get("baseline", {}) or {}).get("script") or ""
        ).strip()

    @property
    def _baseline_command(self) -> str:
        """The document's baseline training command, "" when it supplies none."""
        return str(
            (self._config.get("baseline", {}) or {}).get("command") or ""
        ).strip()

    def _validate_baseline_contract(self) -> None:
        """The supplied-baseline pair is all or nothing.

        A document naming baseline code but no training command (or the
        reverse) is a half-written contract: the framework can neither fork
        the script nor generate a baseline without contradicting something
        the document says. Omitting both is fine — the run's first experiment
        then generates a baseline.
        """
        if bool(self._baseline_script) != bool(self._baseline_command):
            missing = "训练命令" if self._baseline_script else "baseline 代码"
            raise ValueError(
                f"{self._config_path}: the baseline contract is half-written — "
                f"`{missing}` is missing. Supply both `baseline 代码` and "
                "`训练命令`, or omit both so the run's first experiment "
                "generates a baseline."
            )

    @property
    def has_supplied_baseline(self) -> bool:
        """Whether the document supplies a baseline pair to reproduce.

        When it does not, the run's first experiment generates a baseline —
        or, on later runs of the same task, continues from the best snapshot
        a previous run left behind.
        """
        return bool(self._baseline_script and self._baseline_command)

    @property
    def entry_script_name(self) -> str:
        """What that script is called once it is staged into an experiment.

        Taken from the baseline code's filename rather than declared separately: an
        experiment starts as a copy of that exact file, so its lineage is a chain of
        real files rather than a diff the agent has to reconstruct. Deriving it also
        removes the way the two could disagree — a declared entry name that does not
        match the file being copied leaves every experiment looking for a script the
        framework never wrote.
        """
        raw = self._baseline_script
        return Path(raw).name if raw else "train.py"

    @property
    def _supplied_baseline_contract(self) -> dict[str, Any]:
        """Conditions the baseline reproduction runs under, recorded per experiment.

        Framework policy, not task configuration: whatever a task's own rules
        are, they are written in its document, which every role reads. What is left
        here is the part the framework itself guarantees — the evaluation's labels
        are never visible to training, and the evaluation split is used for
        inference only.
        """
        return {
            "eval_labels_visible_to_training": False,
            "eval_usage": "feature_only_inference",
        }

    def _supplied_train_path(self) -> Path:
        """The script an experiment forks from — the code the document points at."""
        raw = self._baseline_script
        if not raw:
            raise ValueError(
                f"{self._config_path}: no supplied baseline code to fork from. "
                "Either declare `baseline 代码` and `训练命令` (both), or omit "
                "both so the run's first experiment generates a baseline."
            )
        return self._resolve_task_path(raw)

    # ─── Submission location ───

    @property
    def submission_relpath(self) -> str:
        """Where an experiment leaves its predictions, relative to its own dir.

        A relative path rather than a filename because a segmentation task submits a
        directory of masks and a ranking task submits one CSV; both are just "the
        thing the evaluation reads". Anything under ``submission/`` is snapshotted
        either way.
        """
        return _SUBMISSION_RELPATH

    # ─── Workspace layering ───

    @staticmethod
    def _link_plan_input(plan_dir: Path, workspace_dir: Path) -> None:
        """Create the plan dir and link the shared read-only input/ into it.

        This is the only workspace setup a diagnostic analysis agent needs; the
        executor's experiment machinery (train script / incumbent /
        reference.json) is layered on top separately.
        """
        plan_dir.mkdir(parents=True, exist_ok=True)
        input_link = plan_dir / "input"
        target = workspace_dir / "input"
        # is_symlink() first so a dangling symlink (exists()==False) is still
        # detected and not silently left broken / re-created into an error.
        if input_link.is_symlink() or input_link.exists():
            return
        os.symlink(str(target.resolve()), str(input_link))

    def prepare_analysis_workspace(self, plan_dir: Path, workspace_dir: Path) -> None:
        """Lightweight setup for diagnostic agents: link input/ only.

        Deliberately skips experiment-mode detection, script copying, and
        incumbent resolution so diagnostics never fail the way executors would
        (e.g. candidate_improvement before an incumbent exists).
        """
        self._link_plan_input(plan_dir, workspace_dir)

    def prepare_executor_workspace(self, plan_dir: Path, workspace_dir: Path) -> None:
        self._link_plan_input(plan_dir, workspace_dir)

        script_path = plan_dir / self.entry_script_name
        if script_path.exists():
            return

        mode = self._read_experiment_mode(plan_dir)
        incumbent = self._load_incumbent_state(workspace_dir)
        if mode == "baseline_generation":
            # No code to fork from: the executor writes the entry script from
            # scratch. reference.json still records the mode so the executor
            # can verify it against plan.md like every other round does.
            self._write_json_atomic(
                plan_dir / "reference.json",
                {
                    "experiment_mode": mode,
                    "reference_type": "none",
                    "source_path": "",
                    "source_sha256": "",
                    "supplied_baseline_contract": self._supplied_baseline_contract,
                    self.metric_name: None,
                },
            )
            return
        if mode == "supplied_baseline_reproduction":
            source = self._supplied_train_path()
            reference_type = "supplied_baseline"
            reference_score = None
        elif mode == "candidate_improvement":
            if incumbent is None:
                raise RuntimeError(
                    "candidate_improvement requires an accepted incumbent; "
                    "reproduce the supplied baseline first"
                )
            source = Path(str(incumbent["snapshot_path"])) / self.entry_script_name
            reference_type = "incumbent"
            reference_score = incumbent.get(self.metric_name)
        elif incumbent is not None:
            source = Path(str(incumbent["snapshot_path"])) / self.entry_script_name
            reference_type = "incumbent"
            reference_score = incumbent.get(self.metric_name)
        else:
            source = self._supplied_train_path()
            reference_type = "supplied_baseline"
            reference_score = None

        if not source.exists() or not source.is_file():
            raise FileNotFoundError(
                f"reference {self.entry_script_name} not found: {source}"
            )
        shutil.copy2(source, script_path)
        self._write_json_atomic(
            plan_dir / "reference.json",
            {
                "experiment_mode": mode,
                "reference_type": reference_type,
                "source_path": str(source.resolve()),
                "source_sha256": self._file_sha256(source),
                "supplied_baseline_contract": self._supplied_baseline_contract,
                self.metric_name: reference_score,
            },
        )

    # ─── Promotion ───

    def record_baseline_reference(
        self, workspace_dir: Path, value: float, source: str
    ) -> None:
        """Record this run's fixed baseline reference when nothing supplies one.

        A task without a supplied baseline still needs a reference number for
        every later candidate to be judged against: it is established either
        by the round that generates a baseline or by continuing from a
        previous run's best snapshot. Adapters that keep such a cache
        override this; the base class stores nothing.
        """
        del workspace_dir, value, source

    def sync_best_result(self, plan_dir: Path, workspace_dir: Path) -> None:
        """Accept valid results and persist an immutable incumbent snapshot.

        Serialized across threads by ``_promote_lock``: several executor
        experiments run concurrently and each calls this from its own thread. The
        lock makes the read-compare-write on the shared
        incumbent state atomic, so a promoted candidate is visible to the next
        one — B re-reads A as the incumbent and must strictly beat it. This is
        stronger than a plain last-writer-wins promotion.
        """
        with self._promote_lock:
            self._sync_best_result_locked(plan_dir, workspace_dir)

    def _sync_best_result_locked(self, plan_dir: Path, workspace_dir: Path) -> None:
        metrics_path = plan_dir / "metrics.json"
        decision_path = plan_dir / "decision.json"
        if not metrics_path.exists():
            self._write_json_atomic(
                decision_path,
                {"accepted": False, "reason": "metrics.json not found"},
            )
            return

        try:
            metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        except Exception as exc:
            self._write_json_atomic(
                decision_path,
                {"accepted": False, "reason": f"invalid metrics.json: {exc}"},
            )
            return

        mode = self._read_experiment_mode(plan_dir)
        incumbent = self._load_incumbent_state(workspace_dir)
        score = metrics.get(self.metric_name, metrics.get("score"))
        baseline_score = metrics.get(self.baseline_metric_key)
        metric_valid = (
            bool(metrics.get("valid"))
            and metrics.get("metric") == self.metric_name
            and self._is_finite_number(score)
        )
        artifact_issues = self._candidate_output_issues(plan_dir)

        accepted = False
        reason = ""
        previous_score = incumbent.get(self.metric_name) if incumbent else None
        if not metric_valid:
            reason = f"protected {self.metric_name} evaluation is missing or invalid"
        elif artifact_issues:
            reason = "candidate outputs invalid: " + "; ".join(artifact_issues)
        elif mode == "supplied_baseline_reproduction":
            if incumbent is None:
                accepted = True
                reason = (
                    "valid supplied-baseline reproduction established the initial "
                    "incumbent"
                )
            else:
                reason = (
                    "an incumbent already exists; supplied-baseline reproduction "
                    "cannot replace it"
                )
        elif mode == "baseline_generation":
            if self.has_supplied_baseline:
                reason = (
                    "the document supplies a baseline; reproduce it with "
                    "supplied_baseline_reproduction instead"
                )
            elif incumbent is None:
                accepted = True
                reason = (
                    "valid generated baseline established the initial incumbent"
                )
            else:
                reason = (
                    "an incumbent already exists; a generated baseline "
                    "cannot replace it"
                )
        elif mode == "ambiguous":
            reason = (
                "plan.md's Experiment Mode section names more than one mode; "
                "declare exactly one"
            )
        elif mode != "candidate_improvement":
            reason = f"unknown experiment mode: {mode}"
        elif incumbent is None or not self._is_finite_number(previous_score):
            reason = "candidate has no valid incumbent reference"
        elif not self.is_strictly_better(score, previous_score):
            reason = "candidate did not strictly beat the incumbent"
        else:
            accepted = True
            reason = "candidate strictly beat the incumbent"

        decision = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "experiment_dir": plan_dir.name,
            "experiment_mode": mode,
            "metric": self.metric_name,
            "valid": metric_valid and not artifact_issues,
            "accepted": accepted,
            "reason": reason,
            self.candidate_metric_key: (
                float(score) if self._is_finite_number(score) else None
            ),
            self.baseline_metric_key: (
                float(baseline_score) if self._is_finite_number(baseline_score) else None
            ),
            self.previous_incumbent_metric_key: (
                float(previous_score) if self._is_finite_number(previous_score) else None
            ),
            "artifact_issues": artifact_issues,
        }
        self._write_json_atomic(decision_path, decision)
        metrics["retention_decision"] = decision
        self._write_json_atomic(metrics_path, metrics)

        if not accepted:
            recorder = get_recorder(plan_dir)
            if recorder:
                recorder.event("decision", accepted=False, valid=decision["valid"])
            # Rejected runs are appended too: the iteration chart needs the whole
            # trajectory, and "this direction was tried and failed" is exactly the
            # signal that stops it being retried.
            self._append_history(workspace_dir, plan_dir, decision, metrics, None)
            logger.info("candidate %s rejected: %s", plan_dir.name, reason)
            return

        snapshot_path = self._snapshot_accepted_result(plan_dir, workspace_dir)
        state = {
            "timestamp": decision["timestamp"],
            "experiment_dir": plan_dir.name,
            "experiment_mode": mode,
            "metric": self.metric_name,
            self.metric_name: float(score),
            self.baseline_metric_key: (
                float(baseline_score) if self._is_finite_number(baseline_score) else None
            ),
            "snapshot_path": str(snapshot_path.resolve()),
            "submission_path": str((snapshot_path / self.submission_relpath).resolve()),
            "metrics_path": str((snapshot_path / "metrics.json").resolve()),
        }
        self._write_json_atomic(self._incumbent_state_path(workspace_dir), state)
        recorder = get_recorder(plan_dir)
        if recorder:
            recorder.event("decision", accepted=True, valid=decision["valid"])
        if mode == "baseline_generation":
            # The generated round IS this run's baseline: its score becomes
            # the fixed reference every later candidate is judged against.
            self.record_baseline_reference(workspace_dir, float(score), mode)
        self._append_history(workspace_dir, plan_dir, decision, metrics, snapshot_path)
        logger.info(
            "incumbent promoted from %s with %s=%s",
            plan_dir.name,
            self.metric_name,
            score,
        )

    def seed_incumbent_from(
        self,
        snapshot_dir: Path,
        workspace_dir: Path,
        mode_label: str = "supplied_baseline_reproduction",
    ) -> dict[str, Any]:
        """Adopt a pre-computed baseline snapshot as this run's initial incumbent.

        Without this, every new run must spend a full training slot reproducing
        the supplied baseline before it can open a `candidate_improvement`, because
        the incumbent lives under the timestamped run workspace and starts empty.

        The snapshot is held to exactly the same bar a live candidate faces — the
        artifact set is checked with ``_candidate_output_issues`` and the metric
        with the same validity rules as ``sync_best_result`` — so a half-built or
        stale anchor is refused here rather than silently becoming the reference
        every later candidate forks from.

        Refuses to overwrite an existing incumbent: re-seeding mid-run would
        discard whatever the run already promoted.
        """
        snapshot_dir = Path(snapshot_dir).expanduser().resolve()
        if not snapshot_dir.is_dir():
            raise FileNotFoundError(
                f"incumbent snapshot directory not found: {snapshot_dir}"
            )

        existing = self._load_incumbent_state(workspace_dir)
        if existing is not None:
            raise RuntimeError(
                "refusing to seed an incumbent: one already exists at "
                f"{self._incumbent_state_path(workspace_dir)} "
                f"({self.metric_name}={existing.get(self.metric_name)})"
            )

        issues = self._candidate_output_issues(snapshot_dir)
        if issues:
            raise ValueError(
                f"incumbent snapshot {snapshot_dir} is incomplete: " + "; ".join(issues)
            )

        metrics_path = snapshot_dir / "metrics.json"
        if not metrics_path.exists():
            raise ValueError(
                f"incumbent snapshot is missing metrics.json: {snapshot_dir}"
            )
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        score = metrics.get(self.metric_name, metrics.get("score"))
        baseline_score = metrics.get(self.baseline_metric_key)
        if not (
            bool(metrics.get("valid"))
            and metrics.get("metric") == self.metric_name
            and self._is_finite_number(score)
        ):
            raise ValueError(
                f"incumbent snapshot {snapshot_dir} has no valid "
                f"{self.metric_name} metric"
            )

        comparability = self._seed_comparability_issues(metrics)
        if comparability:
            raise ValueError(
                f"incumbent snapshot {snapshot_dir} is not comparable to this run: "
                + "; ".join(comparability)
            )

        accepted_root = workspace_dir / "accepted"
        accepted_root.mkdir(parents=True, exist_ok=True)
        destination = accepted_root / snapshot_dir.name
        if destination.exists():
            raise RuntimeError(f"snapshot destination already exists: {destination}")
        shutil.copytree(snapshot_dir, destination)

        state = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "experiment_dir": snapshot_dir.name,
            "experiment_mode": mode_label,
            "metric": self.metric_name,
            self.metric_name: float(score),
            self.baseline_metric_key: (
                float(baseline_score) if self._is_finite_number(baseline_score) else None
            ),
            "snapshot_path": str(destination.resolve()),
            "submission_path": str((destination / self.submission_relpath).resolve()),
            "metrics_path": str((destination / "metrics.json").resolve()),
            "seeded_from": str(snapshot_dir),
        }
        self._write_json_atomic(self._incumbent_state_path(workspace_dir), state)
        logger.info(
            "incumbent seeded from %s with %s=%s",
            snapshot_dir,
            self.metric_name,
            score,
        )
        return state

    def _seed_comparability_issues(self, metrics: dict[str, Any]) -> list[str]:
        """Reasons a supplied snapshot is not measured on this run's terms.

        A snapshot scored under different evaluation settings is not comparable
        to anything this run will produce, and adopting it silently would make
        every later "strictly beat the incumbent" comparison meaningless. The
        base class has no evaluation settings to check, so tasks that do (a
        selection quota, a scoring window) override this.
        """
        del metrics
        return []

    # ─── Incumbent state ───

    @staticmethod
    def _incumbent_state_path(workspace_dir: Path) -> Path:
        return workspace_dir / "working" / "incumbent.json"

    def _load_incumbent_state(self, workspace_dir: Path) -> dict[str, Any] | None:
        path = self._incumbent_state_path(workspace_dir)
        if not path.exists():
            return None
        try:
            state = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise ValueError(f"invalid incumbent state at {path}: {exc}") from exc
        snapshot = Path(str(state.get("snapshot_path", "")))
        if not snapshot.exists() or not snapshot.is_dir():
            raise ValueError(f"incumbent snapshot is missing: {snapshot}")
        return state

    def _snapshot_accepted_result(self, plan_dir: Path, workspace_dir: Path) -> Path:
        accepted_root = workspace_dir / "accepted"
        accepted_root.mkdir(parents=True, exist_ok=True)
        snapshot_path = accepted_root / plan_dir.name
        if snapshot_path.exists():
            suffix = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
            snapshot_path = accepted_root / f"{plan_dir.name}_{suffix}"
        snapshot_path.mkdir(parents=True, exist_ok=False)

        for filename in (
            "plan.md",
            "reference.json",
            self.entry_script_name,
            "runfile.py",
            "metrics.json",
            "decision.json",
            "stdout.log",
            "stderr.log",
        ):
            source = plan_dir / filename
            if source.exists() and source.is_file():
                shutil.copy2(source, snapshot_path / filename)
        for dirname in ("submission", "artifacts"):
            source_dir = plan_dir / dirname
            if source_dir.exists() and source_dir.is_dir():
                shutil.copytree(source_dir, snapshot_path / dirname)
        return snapshot_path

    # ─── Candidate artifact policy ───

    def _candidate_output_issues(self, plan_dir: Path) -> list[str]:
        """Why this experiment's output cannot be promoted, if it cannot.

        The framework checks only the two things it can name without knowing the
        task: the code it staged is still there, and something was submitted.
        What a deliverable has to contain — a reloadable model, an inference entry
        point, a declared feature list — is the task's own rule, so its
        evaluation reports those under ``artifact_issues`` and they arrive through
        ``_extra_candidate_issues``. A framework-side list of required filenames
        would have to be told what a deployable model looks like for every modality
        it might ever run.
        """
        issues: list[str] = []
        for path in (
            plan_dir / self.entry_script_name,
            plan_dir / self.submission_relpath,
        ):
            if path.is_dir():
                # A directory submission (masks, audio clips) is judged by having
                # content at all; what is in it is the evaluation's concern.
                if not any(path.iterdir()):
                    issues.append(f"empty {path.relative_to(plan_dir)}/")
            elif not path.exists() or not path.is_file():
                issues.append(f"missing {path.relative_to(plan_dir)}")
            elif path.stat().st_size <= 0:
                issues.append(f"empty {path.relative_to(plan_dir)}")

        issues.extend(self._extra_candidate_issues(plan_dir))
        return issues

    def _extra_candidate_issues(self, plan_dir: Path) -> list[str]:
        """Deliverable problems the task's evaluation reported, if any.

        Overridden by the adapter that knows where the evaluation writes them.
        """
        del plan_dir
        return []

    # ─── History ───

    @staticmethod
    def _history_path(workspace_dir: Path) -> Path:
        return workspace_dir / "history.jsonl"

    @staticmethod
    def _scalar_entries(block: Any) -> dict[str, Any] | None:
        """The flat numeric/boolean part of a task's diagnostics block.

        Keeps the history line narrow without the framework having to know which
        of the task's diagnostics matter: a scalar is plottable and a nested
        structure is not, so the shape decides rather than a name list.
        """
        if not isinstance(block, dict):
            return None
        picked = {
            str(key): value
            for key, value in block.items()
            if isinstance(value, (int, float, bool)) and not isinstance(value, complex)
        }
        return picked or None

    def _append_history(
        self,
        workspace_dir: Path,
        plan_dir: Path,
        decision: dict[str, Any],
        metrics: dict[str, Any],
        snapshot_path: Path | None,
    ) -> None:
        """Append one compact, chart-ready line per experiment.

        ``metrics.jsonl`` (written by tools/eval.py on every evaluation) already
        keeps the full record, but each line can be tens of KB of the evaluator's
        own nested breakdown and it predates the retention decision. This file is
        the narrow projection an iteration chart actually plots: one line per
        experiment, the score, both reference scores, the per-segment scores, and
        the evaluator's scalar diagnostics.

        Two slots carry everything task-specific, and the framework interprets
        neither:

        ``segments``     ``{name: {"score": ..., ...}}`` — whatever the task
                         breaks its metric down by. Channels, languages, classes,
                         time buckets; the framework only reads ``score``.
        ``diagnostics``  the evaluator's own numbers. Only the scalar entries are
                         projected here — a nested breakdown belongs in
                         metrics.json, which already has it, and copying it would
                         make this file as wide as the thing it summarizes.

        Every slot is presence-gated, so a task reporting only a single number
        still gets a valid history line with the extra columns null.

        Called only from ``sync_best_result``, which holds ``_promote_lock``, so
        concurrent executors cannot interleave partial lines. Failures here are
        logged and swallowed: losing a chart row must never fail an experiment
        that the retention logic already decided on.
        """
        segments = metrics.get("segments")
        diagnostics = metrics.get("diagnostics")

        record = {
            "ts": decision["timestamp"],
            "exp": plan_dir.name,
            "mode": decision["experiment_mode"],
            "accepted": decision["accepted"],
            "valid": decision["valid"],
            "reason": decision["reason"],
            "metric": decision["metric"],
            "score": decision[self.candidate_metric_key],
            "baseline": decision[self.baseline_metric_key],
            "prev_incumbent": decision[self.previous_incumbent_metric_key],
            "segments": segments if isinstance(segments, dict) and segments else None,
            "diagnostics": self._scalar_entries(diagnostics),
            "artifact_issues": decision.get("artifact_issues") or [],
            "snapshot": str(snapshot_path.resolve())
            if snapshot_path is not None
            else None,
        }

        path = self._history_path(workspace_dir)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as handle:
                handle.write(
                    json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n"
                )
        except Exception:
            logger.exception("failed to append history row for %s", plan_dir.name)

    # ─── Finalization ───

    def select_final_snapshot(self, workspace_dir: Path) -> Path | None:
        """The accepted incumbent's whole snapshot — this run's deliverable.

        Everything the experiment produced is already in here: ``submission/``,
        ``artifacts/``, ``metrics.json``, the training script, the logs. The
        directory is returned rather than one file picked out of it because the
        framework cannot pick: what a deliverable has to contain is the
        task's own rule, the same one ``artifact_issues`` carries. A model is
        a `.joblib` for one task and a checkpoint directory for another, and
        naming either here would put a modality back into a framework whose
        whole point is not to hold one.

        Gated on the submission still validating, because that is what ties the
        recorded number to these files: a snapshot whose predictions cannot be
        re-scored is not evidence for the score attached to it.
        """
        incumbent = self._load_incumbent_state(workspace_dir)
        if incumbent is None:
            return None
        if self.select_final_submission(workspace_dir) is None:
            return None
        return Path(str(incumbent["snapshot_path"]))

    def select_final_submission(self, workspace_dir: Path) -> Path | None:
        """Return only the accepted incumbent submission for finalization."""
        incumbent = self._load_incumbent_state(workspace_dir)
        if incumbent is None:
            return None
        submission_path = Path(str(incumbent.get("submission_path", "")))
        if not submission_path.exists():
            logger.warning("incumbent submission missing: %s", submission_path)
            return None
        validation = self.validate_submission(submission_path)
        if not validation.get("valid"):
            logger.warning(
                "incumbent submission is invalid: %s",
                validation.get("message", "unknown validation error"),
            )
            return None
        return submission_path

    def validate_submission(self, submission_path: Path) -> dict[str, Any]:
        """Accept any submission unless the task declares a format contract.

        The generic path cannot check a format it was never told about — an
        image-mask directory and a ranking CSV have nothing in common. Tasks with
        a declared submission schema override this and enforce it.
        """
        del submission_path
        return {"valid": True, "message": ""}

    # ─── Result helpers ───

    def _invalid_result(self, details: str, **extra: Any) -> dict[str, Any]:
        """A well-formed "this did not produce a score" result.

        Carries the metric keys with null values so downstream readers see the
        same shape whether the evaluation succeeded or not.
        """
        result: dict[str, Any] = {
            "score": None,
            self.metric_name: None,
            self.baseline_metric_key: None,
            "valid": False,
            "details": details,
        }
        result.update(extra)
        return result

    # ─── Small utilities ───

    @staticmethod
    def _read_experiment_mode(plan_dir: Path) -> str:
        """The mode the plan declares in its ``## Experiment Mode`` section.

        Read from that section rather than by scanning the whole document. A plan
        that quotes the template line (``supplied_baseline_reproduction``,
        ``baseline_generation`` *or* ``candidate_improvement``), or that names
        the baseline while arguing for a candidate, otherwise resolves to
        whichever name happens to be checked first — and a candidate judged as
        a baseline round is refused for a reason that has nothing to do with
        it. Naming more than one is ``ambiguous``.
        """
        plan_path = plan_dir / "plan.md"
        if not plan_path.exists():
            return "unknown"
        text = plan_path.read_text(encoding="utf-8", errors="replace").lower()

        section = next(
            (
                block
                for block in re.split(r"^#{1,6}\s+", text, flags=re.MULTILINE)
                if block.startswith("experiment mode")
            ),
            None,
        )
        scope = text if section is None else section

        modes = (
            "supplied_baseline_reproduction",
            "candidate_improvement",
            "baseline_generation",
        )
        named = [mode for mode in modes if mode in scope]
        if len(named) == 1:
            return named[0]
        if len(named) > 1:
            return "ambiguous"
        if "type: `incumbent`" in scope or "type: incumbent" in scope:
            return "candidate_improvement"
        return "unknown"

    @staticmethod
    def _file_sha256(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as file_obj:
            for chunk in iter(lambda: file_obj.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _is_finite_number(value: Any) -> bool:
        try:
            number = float(value)
        except (TypeError, ValueError):
            return False
        return number == number and number not in (float("inf"), float("-inf"))

    @staticmethod
    def _write_json_atomic(path: Path, value: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = path.with_name(f".{path.name}.tmp")
        temp_path.write_text(
            json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
            encoding="utf-8",
        )
        os.replace(temp_path, path)

    @staticmethod
    def _resolve_run_root(path: Path) -> Path:
        """Walk up to the run root (the parent of ``working/``).

        An experiment runs inside ``<run>/working/<exp>/`` but shared artifacts
        (input/, submission/) live at the run root, so both need resolving from
        wherever the caller happens to be.
        """
        resolved = Path(path).resolve()
        for parent in (resolved, *resolved.parents):
            if parent.name == "working":
                return parent.parent
        return resolved
