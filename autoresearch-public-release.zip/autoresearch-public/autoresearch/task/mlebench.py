"""Legacy competition-ID adapter, using the current incumbent and telemetry flow.

Compatibility protocol: search receives scores from MLE-bench's private answers.
These are explicitly labelled test feedback, never independent held-out results.
Only prepared public data is linked into agent workspaces. Local shell execution
is not a security sandbox; private files require OS/service isolation if needed.
"""

from __future__ import annotations

import json
import logging
import math
import os
import re
import tempfile
import zipfile
from functools import cached_property
from pathlib import Path
from typing import Any

from .base_task import BaseTaskAdapter

logger = logging.getLogger(__name__)
_PROMPTS_DIR = Path(__file__).resolve().parents[1] / "prompts" / "mlebench"
_LOWER_KEYWORDS = {
    "error",
    "loss",
    "rmse",
    "rmsle",
    "mae",
    "mse",
    "msle",
    "mape",
    "sse",
    "rae",
    "rse",
}


class MLEBenchAdapter(BaseTaskAdapter):
    def __init__(
        self,
        data_dir: Path | None = None,
        *,
        competition_id: str = "",
        task_settings: dict[str, Any] | None = None,
    ) -> None:
        if not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_-]*", competition_id):
            raise ValueError(
                "MLE-bench requires a valid --competition-id (Kaggle competition slug)"
            )
        super().__init__(task_settings=task_settings)
        try:
            from mlebench.registry import Registry
        except ModuleNotFoundError as exc:
            if exc.name not in {"mlebench", "mlebench.registry"}:
                raise
            raise ValueError(
                "MLE-bench is not installed in this Python environment. Install "
                "the official checkout: `uv pip install -e /path/to/mle-bench`. Use "
                "`uv run --no-sync autoresearch ...`. See README.md."
            ) from exc
        location = data_dir or os.environ.get("MLEBENCH_DATA_DIR")
        registry = (
            Registry(Path(location).expanduser().resolve()) if location else Registry()
        )
        self._data_dir = registry.get_data_dir()
        try:
            self._competition = registry.get_competition(competition_id)
        except (AssertionError, FileNotFoundError) as exc:
            raise ValueError(
                f"Cannot load MLE-bench competition {competition_id!r}: {exc}"
            ) from exc
        self.competition_id = competition_id

    @property
    def task_description(self) -> str:
        return self._competition.description

    @property
    def data_dir(self) -> Path:
        return self._workspace_input_dir or self._competition.public_dir

    @property
    def metric_name(self) -> str:
        return self._competition.grader.name

    @cached_property
    def metric_lower_is_better(self) -> bool:
        try:
            import pandas as pd

            leaderboard = pd.read_csv(self._competition.leaderboard)
            if len(leaderboard) >= 2 and "score" in leaderboard.columns:
                if leaderboard["score"].iloc[0] != leaderboard["score"].iloc[-1]:
                    return bool(self._competition.grader.is_lower_better(leaderboard))
        except (OSError, ValueError, KeyError):
            logger.warning(
                "Leaderboard unavailable; inferring direction from metric %s",
                self.metric_name,
            )
        return bool(
            set(re.split(r"[\s_-]+", self.metric_name.lower())) & _LOWER_KEYWORDS
        )

    @property
    def allowed_eval_splits(self) -> set[str]:
        return {"test"}

    @property
    def search_eval_split(self) -> str:
        return "test"

    @property
    def score_split(self) -> str:
        return "test"

    @property
    def evaluation_protocol(self) -> str:
        return "mlebench_legacy_test_feedback"

    @property
    def evaluation_note(self) -> str:
        return (
            "Legacy MLE-bench compatibility: private-answer test scores were "
            "returned during search and used for candidate selection. "
            "This is search feedback, not an "
            "independent held-out test result."
        )

    @property
    def wants_analysis_agents(self) -> bool:
        return bool(self._settings.get("analysis_agents", True))

    @property
    def protected_paths(self) -> list[str]:
        return ["input", ".labels"]

    @property
    def agent_visible_locations(self) -> dict[str, str]:
        return {"public": str(self.data_dir.resolve())}

    def get_prompts_dir(self) -> Path:
        return _PROMPTS_DIR

    def get_task_context(self) -> dict[str, Any]:
        return {
            "category": "mle",
            "benchmark": "mlebench",
            "competition_id": self.competition_id,
            "task_type": f"mlebench/{self.competition_id}",
            "paradigm": "ml_competition",
            "task_description": self.task_description,
            "supplied_baseline": False,
            "entry_point": "train.py",
            "metric": self.metric_name,
            "metric_direction": "minimize"
            if self.metric_lower_is_better
            else "maximize",
            "evaluation_rule": (
                "Write ./submission/submission.csv for the public test inputs "
                "and call eval(split='test'). "
                "The framework runs the competition grader. " + self.evaluation_note
            ),
            "evaluation_protocol": self.evaluation_protocol,
            "data_summary": self._manifest_text,
        }

    def evaluate_submission(self, submission_path: Path) -> dict[str, Any]:
        try:
            from mlebench.utils import load_answers, read_csv

            if not submission_path.is_file():
                raise ValueError("submission/submission.csv not found")
            score = self._competition.grader(
                read_csv(submission_path),
                load_answers(self._competition.answers),
            )
            if score is None or not math.isfinite(float(score)):
                raise ValueError(
                    "Competition grader returned an invalid or non-finite score"
                )
            return {
                "score": float(score),
                "valid": True,
                "details": "",
                "evaluation_protocol": self.evaluation_protocol,
                "score_split": "test",
                "competition_id": self.competition_id,
            }
        except Exception as exc:
            logger.warning(
                "MLE-bench grading failed for %s: %s", self.competition_id, exc
            )
            return {
                "score": None,
                "valid": False,
                "details": str(exc),
                "evaluation_protocol": self.evaluation_protocol,
            }

    def evaluate(
        self,
        workspace_dir: Path,
        split: str = "test",
        execution_timeout: float | None = None,
    ) -> dict[str, Any]:
        if split not in self.allowed_eval_splits:
            return {
                "score": None,
                "valid": False,
                "details": f"Unsupported split: {split}; use test",
            }
        result = self.evaluate_submission(workspace_dir / self.submission_relpath)
        root = self._resolve_run_root(workspace_dir)
        reference = root / "baseline_reference.json"
        if reference.is_file():
            result[self.baseline_metric_key] = json.loads(
                reference.read_text(encoding="utf-8")
            )["score"]
        elif (
            self._read_experiment_mode(workspace_dir) == "baseline_generation"
            and result["valid"]
        ):
            result[self.baseline_metric_key] = result["score"]
        return result

    def record_baseline_reference(
        self, workspace_dir: Path, value: float, source: str
    ) -> None:
        self._write_json_atomic(
            workspace_dir / "baseline_reference.json",
            {
                "score": value,
                "source": source,
                "competition_id": self.competition_id,
                "evaluation_protocol": self.evaluation_protocol,
            },
        )

    def validate_submission(self, submission_path: Path) -> dict[str, Any]:
        from mlebench.grade import validate_submission

        try:
            valid, message = validate_submission(submission_path, self._competition)
            return {"valid": valid, "message": message}
        except Exception as exc:
            return {"valid": False, "message": str(exc)}

    def _seed_comparability_issues(self, metrics: dict[str, Any]) -> list[str]:
        issues = super()._seed_comparability_issues(metrics)
        if metrics.get("competition_id") != self.competition_id:
            issues.append("incumbent belongs to a different or unspecified competition")
        if metrics.get("evaluation_protocol") != self.evaluation_protocol:
            issues.append(
                "incumbent uses a different or unspecified evaluation protocol"
            )
        return issues

    def setup_workspace(self, workspace_dir: Path) -> None:
        self._ensure_prepared()
        input_dir = workspace_dir / "input"
        for directory in (
            input_dir,
            workspace_dir / "working",
            workspace_dir / "submission",
        ):
            directory.mkdir(parents=True, exist_ok=True)
        for source in self._competition.public_dir.iterdir():
            if source.name == "MANIFEST.txt":
                continue
            target = input_dir / source.name
            if not target.exists() and not target.is_symlink():
                target.symlink_to(source.resolve())
        self._extract_archives(input_dir)
        description = input_dir / "description.md"
        if not description.exists():
            description.write_text(self.task_description, encoding="utf-8")
        self._workspace_input_dir = input_dir.resolve()
        lines = [
            "# Prepared public data (read-only inputs)",
            "# Archives already extracted where listed.",
        ]
        for item in sorted(input_dir.iterdir()):
            if item.name != "MANIFEST.txt":
                lines.append(item.name + ("/" if item.is_dir() else ""))
        self._manifest_text = "\n".join(lines) + "\n"
        manifest = input_dir / "MANIFEST.txt"
        if manifest.is_symlink():
            manifest.unlink()
        manifest.write_text(self._manifest_text, encoding="utf-8")
        logger.info(
            "MLE-bench competition=%s protocol=%s",
            self.competition_id,
            self.evaluation_protocol,
        )

    def _ensure_prepared(self) -> None:
        from mlebench.data import is_dataset_prepared

        if is_dataset_prepared(self._competition):
            return
        comp = self._competition
        archive = comp.raw_dir.parent / f"{self.competition_id}.zip"
        if archive.is_file():
            comp.raw_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(archive) as zf:
                self._safe_extract(zf, comp.raw_dir, missing_only=True)
            comp.public_dir.mkdir(parents=True, exist_ok=True)
            comp.private_dir.mkdir(parents=True, exist_ok=True)
            comp.prepare_fn(
                raw=comp.raw_dir, public=comp.public_dir, private=comp.private_dir
            )
            (comp.public_dir / "description.md").write_text(
                self.task_description, encoding="utf-8"
            )
            if is_dataset_prepared(comp):
                return
        raise ValueError(
            f"Competition {self.competition_id!r} is not prepared. Run: "
            f"mlebench prepare -c {self.competition_id} --data-dir {self._data_dir}"
        )

    @staticmethod
    def _safe_extract(
        zf: zipfile.ZipFile, target: Path, *, missing_only: bool = False
    ) -> None:
        root = target.resolve()
        for member in zf.infolist():
            destination = (root / member.filename).resolve()
            if (
                not destination.is_relative_to(root)
                or (member.external_attr >> 16) & 0o170000 == 0o120000
            ):
                raise ValueError(f"Unsafe archive member: {member.filename}")
            if not missing_only or not destination.exists():
                zf.extract(member, root)

    @classmethod
    def _extract_archives(cls, input_dir: Path) -> None:
        for archive in list(input_dir.glob("*.zip")):
            destination = input_dir / archive.stem
            if not destination.exists():
                # Publish completed extractions so an interrupted run can retry.
                with tempfile.TemporaryDirectory(
                    prefix=".extract-", dir=input_dir
                ) as temporary:
                    staging = Path(temporary)
                    with zipfile.ZipFile(archive) as zf:
                        cls._safe_extract(zf, staging)
                    children = list(staging.iterdir())
                    source = (
                        children[0]
                        if len(children) == 1
                        and children[0].is_dir()
                        and children[0].name == archive.stem
                        else staging
                    )
                    source.rename(destination)
            archive.unlink()  # Only the workspace link; keep the prepared source.

    def check(
        self, workspace_dir: Path, submission: Path | None = None
    ) -> dict[str, Any]:
        steps = []
        try:
            self.setup_workspace(workspace_dir)
            steps.append(
                {"step": "prepared public data and private grader inputs", "ok": True}
            )
            if submission is not None:
                first, second = (self.evaluate_submission(submission) for _ in range(2))
                ok = (
                    first["valid"]
                    and second["valid"]
                    and first["score"] == second["score"]
                )
                steps.append(
                    {
                        "step": "submission scoring is valid and repeatable",
                        "ok": ok,
                        "detail": str(first),
                    }
                )
            else:
                steps.append(
                    {
                        "step": "no supplied baseline; first run generates train.py",
                        "ok": True,
                    }
                )
        except Exception as exc:
            steps.append(
                {"step": "MLE-bench preparation", "ok": False, "detail": str(exc)}
            )
        return {
            "ok": all(step["ok"] for step in steps),
            "steps": steps,
            "metric": self.metric_name,
            "direction": "minimize" if self.metric_lower_is_better else "maximize",
        }
