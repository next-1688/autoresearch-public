from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any


class TaskAdapter(ABC):
    """Abstract base class for all task adapters.

    Subclasses implement task-specific logic: evaluation, prompts, workspace
    setup, file policies, and tool configuration. The framework orchestrates
    execution by calling these interfaces without knowing the task type.
    """

    # ─── Task description ───

    @property
    @abstractmethod
    def task_description(self) -> str: ...

    @property
    @abstractmethod
    def data_dir(self) -> Path: ...

    # ─── Evaluation ───

    @property
    @abstractmethod
    def metric_name(self) -> str: ...

    @property
    @abstractmethod
    def metric_lower_is_better(self) -> bool: ...

    @property
    def baseline_metric_key(self) -> str:
        """Key holding the baseline's score in metrics.json.

        Derived from ``metric_name`` so no adapter has to hardcode it, and so
        the framework can read it back without knowing the task. The baseline is
        whatever the task says a model has to beat to be worth deploying — a rule
        the task runs today, a published number, a supplied script.
        """
        return f"baseline_{self.metric_name}"

    @property
    def candidate_metric_key(self) -> str:
        """Key holding the candidate's score in decision.json."""
        return f"candidate_{self.metric_name}"

    @property
    def previous_incumbent_metric_key(self) -> str:
        """Key holding the outgoing incumbent's score in decision.json."""
        return f"previous_incumbent_{self.metric_name}"

    def is_strictly_better(self, candidate: Any, reference: Any) -> bool:
        """Strict improvement in this metric's own direction.

        Promotion ladders must go through here rather than writing ``>``:
        a lower-is-better metric (loss, rmse) would otherwise silently promote
        regressions.
        """
        if self.metric_lower_is_better:
            return float(candidate) < float(reference)
        return float(candidate) > float(reference)

    @abstractmethod
    def evaluate(
        self, workspace_dir: Path, split: str = "dev",
        execution_timeout: float | None = None,
    ) -> dict[str, Any]:
        """Evaluate current workspace output on the given split.
        Returns {"score": float, "valid": bool, "details": str}.
        """
        ...

    @property
    def allowed_eval_splits(self) -> set[str]:
        """Splits the optimization loop may evaluate. The eval tool enforces it.

        A task hands in training data and validation data, so there is one split to
        score on and this exists to keep an agent from inventing a second one — an
        `eval` call naming some other split is a request the framework refuses
        rather than silently maps onto the split it does have.
        """
        return {"dev"}

    @property
    def search_eval_split(self) -> str:
        return "dev"

    @property
    def score_split(self) -> str:
        return "validation"

    @property
    def evaluation_protocol(self) -> str:
        return "validation"

    @property
    def evaluation_note(self) -> str:
        return (
            "This is the score the search optimized against, on the validation data the "
            "task declared. It is not an independent verdict."
        )

    def get_prompts_dir(self) -> Path | None:
        """Optional task-specific role templates, with framework fallback."""
        return None

    @property
    def wants_analysis_agents(self) -> bool:
        """Whether to expose the 'analysis' sub-agent type.

        Default False: the planner's task_spawn only offers executor/summarizer/
        knowledge_manager (unchanged for existing benches). Set True to add the
        'analysis' agent (multi-direction diagnostics, dispatchable in parallel).
        """
        return False

    # ─── File policy ───

    @property
    def editable_paths(self) -> list[str]:
        """Editable files/dirs (relative to workspace). Empty = unrestricted."""
        return []

    @property
    def protected_paths(self) -> list[str]:
        """Protected files/dirs that must not be modified. Empty = unrestricted."""
        return []

    # ─── Prompts and context ───

    @abstractmethod
    def get_task_context(self) -> dict[str, Any]:
        """Return task-specific variables injected into prompt templates.
        ML competition: {"submission_spec": ..., "data_summary": ..., ...}
        BrowseComp: {"editable_files": [...], "eval_command_dev": ..., ...}
        """
        ...

    # ─── Workspace ───

    @abstractmethod
    def setup_workspace(self, workspace_dir: Path) -> None:
        """Prepare the main workspace (called once at start)."""
        ...

    def prepare_executor_workspace(self, plan_dir: Path, workspace_dir: Path) -> None:
        """Prepare an isolated workspace for each executor.
        Default: no-op (ML competitions share input/).
        Harness optimization tasks should copy the task into plan_dir
        so parallel executors don't conflict.
        """
        pass

    def prepare_analysis_workspace(self, plan_dir: Path, workspace_dir: Path) -> None:
        """Prepare an isolated workspace for a diagnostic 'analysis' sub-agent.

        Default delegates to prepare_executor_workspace for backward
        compatibility. Tasks whose executor setup runs experiment-only logic
        (copying train.py, resolving an incumbent, etc.) should override this
        with a lighter preparation so diagnostic agents don't inherit that
        machinery.
        """
        self.prepare_executor_workspace(plan_dir, workspace_dir)

    # ─── Environment ───

    def get_env_requirements(self) -> dict[str, str]:
        """Declare required environment variables for evaluation.
        Returns {VAR_NAME: description}. Framework checks before eval.
        """
        return {}

    def validate_workspace_changes(self, workspace_dir: Path) -> dict[str, Any]:
        """Validate task-specific file policy before evaluation.

        Returns {"valid": bool, "details": str}. The default accepts all
        changes for unrestricted tasks such as ML competitions.
        """
        return {"valid": True, "details": ""}

    def cleanup_plan_artifacts(self, plan_dir: Path) -> None:
        """Reclaim intermediate files an experiment left behind.

        Called after every experiment on every outcome — success, failure, or
        interruption — so a crashed plan cannot leak its intermediates and
        exhaust the disk for later ones. Whatever this deletes must not be
        anything the evaluation or the snapshot needs.

        The default does nothing, which is right for a task whose experiments
        write megabytes. A task whose training leaves multi-gigabyte optimizer
        states or checkpoint shards overrides it and removes them.
        """
        del plan_dir

    # ─── Backward compatibility (MLE-bench legacy, non-abstract) ───

    def validate_submission(self, submission_path: Path) -> dict[str, Any]:
        raise NotImplementedError("Use evaluate() for generic tasks")
