"""Read the framework's few machine-readable values out of a task's document.

A task hands in prose organized into five mandatory sections: 任务定义,
优化指标, 数据, 代码位置, 人工先验. A handful of the lines in that prose are
also read by the framework: what the metric is called and which direction is
better, where the data is, which script an experiment forks from, how to run it,
how to score it. Each of those lines must live in the section that states it —
the metric in 优化指标, the data paths in 数据, the code in 代码位置 — so a
misplaced field is a reportable mismatch instead of a silent misread.

They are not a configuration appendix. They are the lines a human writes anyway
when documenting a task, and the framework reads *those* lines rather than a
second copy of them. The predecessor of this module parsed a fenced ``yaml`` block
at the end of the document, which meant every one of these facts was stated twice
— once in the section where a reader looks for it and once in the block the
framework reads. Two statements of one fact drift, and nothing tells you which one
the run used.

Nothing here is derived by a model. The fields are found by pattern, and a field
that cannot be found is an error that names what the document did contain — the
same contract the rest of the framework holds itself to: report the mismatch,
never guess.

The document is returned whole. There is nothing in it to withhold from the
agents: the one location that must stay hidden is the validation labels, and that
location lives inside the task's own evaluation script, outside the file tools'
allowed paths. Arbitrary local code is not sandboxed; see the README boundaries.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

#: Field name → the labels a document may use for it. A task writes in its own
#: language; the framework does not get to impose one. Matching ignores case,
#: spaces, and the underscore/space distinction, so `baseline 代码`,
#: `baseline代码` and `baseline_script` are one label.
_LABELS: dict[str, tuple[str, ...]] = {
    "metric": ("指标", "指标名", "metric", "metric_name"),
    "direction": ("方向", "优化方向", "direction"),
    "train": ("训练数据", "训练集", "train", "train_data"),
    "val": ("验证数据", "验证集", "val", "val_data"),
    "baseline_script": ("baseline代码", "baseline_script", "基线代码"),
    "train_command": ("训练命令", "train_command"),
    "eval_command": ("评测命令", "eval_command"),
    # Recognized so it can be ignored quietly: the framework always runs the
    # supplied baseline once at the start of a run and measures the score
    # itself, so a declared one is redundant rather than wrong. Refusing the
    # document over a harmless extra line only teaches people to fear the
    # parser.
    "baseline_score": ("baseline分数", "baseline_score", "基线分数"),
}

#: Every field the framework needs, except the supplied baseline pair. A task
#: may omit ``baseline_script`` and ``train_command`` together: the run's first
#: experiment then generates a baseline instead of reproducing one. Supplying
#: only one of the pair is a contract error caught in the adapter.
#: ``baseline_score`` is exempt because it is a label the framework ignores.
_BASELINE_OPTIONAL = ("baseline_script", "train_command")
_REQUIRED = tuple(
    name
    for name in _LABELS
    if name != "baseline_score" and name not in _BASELINE_OPTIONAL
)

#: Reverse index, built once. Normalized label → field name.
_LABEL_TO_FIELD: dict[str, str] = {}

#: A labelled line: an optional list bullet or ordered marker, an optional bold
#: wrapper, the label, a colon in either width, then the value. The label length is
#: bounded so an ordinary sentence that happens to contain a colon cannot look like
#: a field — and an unrecognized label is ignored anyway.
_LINE = re.compile(
    r"""^[ \t]*                     # indent
        (?:[-*+][ \t]+|\d+[.)][ \t]+)?   # bullet / ordered marker
        \*{0,2}[ \t]*                    # opening bold
        (?P<label>[^:：\n]{1,24}?)       # the label
        [ \t]*\*{0,2}[ \t]*              # closing bold
        [:：][ \t]*                      # colon, half or full width
        (?P<value>\S.*?)[ \t]*$          # the value
    """,
    re.VERBOSE,
)

#: A fence opens or closes a code block. Lines inside one are never fields: a
#: document shows example output (`rmse: 0.42`) and example commands in fences, and
#: reading those as the contract would take an illustration for a declaration.
#: Fenced lines are also not section headings — code comments routinely look like
#: them (`# 数据` as a shell comment).
_FENCE = re.compile(r"^[ \t]*(```|~~~)")

#: The five mandatory sections, in order, with the headings a document may use for
#: each. The numbering a task puts on a heading is free (`## 2. 优化指标` and
#: `## 优化指标` are the same section); the section *identity* is fixed.
_SECTIONS: dict[str, tuple[str, ...]] = {
    "任务定义": ("任务定义", "任务说明", "task definition"),
    "优化指标": ("优化指标", "评估指标", "指标", "优化目标", "metric", "optimization metric"),
    "数据": ("数据", "数据集", "data"),
    "代码位置": ("代码位置", "代码", "代码与命令", "code"),
    "人工先验": ("人工先验", "先验", "人工经验", "已知经验", "经验", "prior"),
}

#: Which machine-read fields each section must hold. Keys are section names,
#: values are field names from `_LABELS`.
_SECTION_FIELDS: dict[str, tuple[str, ...]] = {
    "优化指标": ("metric", "direction"),
    "数据": ("train", "val"),
    "代码位置": ("baseline_script", "train_command", "eval_command"),
}

_SECTION_ORDER = tuple(_SECTIONS)

_MINIMIZE_WORDS = ("越小越好", "越低越好", "minimize", "lower_is_better", "lower", "min")
_MAXIMIZE_WORDS = ("越大越好", "越高越好", "maximize", "higher_is_better", "higher", "max")


def _normalize_header(text: str) -> str:
    """A heading line reduced to a comparable key.

    ``## 2. 优化指标``, ``### 优化指标`` and ``## Optimization Metric`` reduce
    to the same key, so a document's own numbering and language stay free while
    the section identity is fixed.
    """
    text = text.strip()
    text = re.sub(r"^#{1,6}[ \t]*", "", text)
    text = re.sub(r"^[0-9]+[ \t]*[.)、．。:：\-]*[ \t]*", "", text)
    text = re.sub(r"[\s_　]+", "", text)
    return text.rstrip(":：.。").lower()


_SECTION_ALIASES: dict[str, str] = {}
for _section, _aliases in _SECTIONS.items():
    for _alias in _aliases:
        _SECTION_ALIASES[_normalize_header(_alias)] = _section


def _normalize(label: str) -> str:
    return re.sub(r"[\s_　]+", "", label).strip().lower()


for _field, _aliases in _LABELS.items():
    for _alias in _aliases:
        _LABEL_TO_FIELD[_normalize(_alias)] = _field


def _found_labels(text: str) -> dict[str, list[tuple[int, str]]]:
    """Every recognized field in the document, with line numbers.

    Line numbers are kept because they are what makes a duplicate reportable: a
    document stating the metric twice must be fixed by a human who needs to know
    where both statements are.
    """
    found: dict[str, list[tuple[int, str]]] = {}
    in_fence = False
    for number, line in enumerate(text.splitlines(), start=1):
        if _FENCE.match(line):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        match = _LINE.match(line)
        if match is None:
            continue
        field = _LABEL_TO_FIELD.get(_normalize(match.group("label")))
        if field is None:
            continue
        found.setdefault(field, []).append((number, _clean(match.group("value"))))
    return found


def _section_headers(text: str) -> dict[str, list[int]]:
    """Section name → heading line numbers, for the five mandatory sections.

    Fences are skipped: code comments routinely look like headings. A heading
    line that matches no mandatory section is ignored — subsections inside a
    section are the task's own affair.
    """
    found: dict[str, list[int]] = {}
    in_fence = False
    for number, line in enumerate(text.splitlines(), start=1):
        if _FENCE.match(line):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        stripped = line.strip()
        if not stripped.startswith("#"):
            continue
        section = _SECTION_ALIASES.get(_normalize_header(stripped))
        if section is None:
            continue
        found.setdefault(section, []).append(number)
    return found


def _section_span(line: int, headers: dict[str, list[int]]) -> str:
    """Which mandatory section a line falls inside, or where it falls outside."""
    for index, name in enumerate(_SECTION_ORDER):
        start = headers[name][0]
        end = (
            headers[_SECTION_ORDER[index + 1]][0]
            if index + 1 < len(_SECTION_ORDER)
            else None
        )
        if start <= line and (end is None or line < end):
            return name
    return "no section (before the first heading)"


def _validate_sections(
    source: str, found: dict[str, list[tuple[int, str]]], headers: dict[str, list[int]]
) -> None:
    """The five sections exist, are unique, are in order, and hold their fields.

    Called before label lookup so a structural error is reported first: a
    document with no sections is broken in a different way than one with a
    missing label, and the fixes are different.
    """
    missing = [name for name in _SECTION_ORDER if name not in headers]
    if missing:
        raise ValueError(
            f"{source} must be organized into five sections in this order: "
            + ", ".join(f"`{name}`" for name in _SECTION_ORDER)
            + f". Missing: {', '.join(missing)}. Write each as a markdown "
            "heading, e.g. `## 2. 优化指标`; the numbering is free."
        )

    for name in _SECTION_ORDER:
        lines = headers[name]
        if len(lines) > 1:
            raise ValueError(
                f"{source}: section `{name}` is headed {len(lines)} times "
                f"(lines {', '.join(str(n) for n in lines)}). Exactly one heading "
                "is the section boundary, and it will not guess which."
            )

    positions = [headers[name][0] for name in _SECTION_ORDER]
    if positions != sorted(positions):
        raise ValueError(
            f"{source}: sections are out of order. Required order: "
            + " → ".join(_SECTION_ORDER) + "."
        )

    for section, fields in _SECTION_FIELDS.items():
        for field in fields:
            for line, _value in found.get(field, []):
                where = _section_span(line, headers)
                if where != section:
                    raise ValueError(
                        f"{source}: `{_LABELS[field][0]}` is on line {line}, "
                        f"inside section `{where}`; it must be in the `{section}` "
                        "section."
                    )


def _clean(value: str) -> str:
    """Strip the markup a human puts around a value, not the value itself.

    Backticks and quotes are how a path or a command gets typeset in prose; a
    trailing comment after ``#`` is how the writer explains it to the next reader.
    """
    value = re.sub(r"\s+#.*$", "", value).strip()
    return value.strip("`\"'").strip()


def _one(found: dict[str, list[tuple[int, str]]], field: str, source: str) -> str | None:
    entries = found.get(field)
    if not entries:
        return None
    if len(entries) > 1:
        lines = ", ".join(str(number) for number, _ in entries)
        raise ValueError(
            f"{source}: `{_LABELS[field][0]}` is stated {len(entries)} times "
            f"(lines {lines}). Exactly one of them is the one the framework should "
            "use, and it will not guess which."
        )
    return entries[0][1]


def _direction_is_minimize(value: str, source: str) -> bool:
    lowered = value.lower()
    if any(word in lowered for word in _MINIMIZE_WORDS):
        return True
    if any(word in lowered for word in _MAXIMIZE_WORDS):
        return False
    raise ValueError(
        f"{source}: `{_LABELS['direction'][0]}: {value}` does not say which way is "
        "better. Write 越大越好 / 越小越好 (or maximize / minimize) — the promotion "
        "ladder compares in this direction, and assuming one silently promotes "
        "regressions for half of all tasks."
    )


def parse_task_document(text: str, source: str | Path = "task document") -> dict[str, Any]:
    """The framework's view of a task document.

    Returns the same shape the adapters already consume, so what changed with the
    removal of the yaml block is where these values come from — not how the rest of
    the framework reads them.
    """
    source = str(source)
    found = _found_labels(text)
    headers = _section_headers(text)
    _validate_sections(source, found, headers)

    values = {field: _one(found, field, source) for field in _LABELS}
    if values["baseline_score"]:
        logger.info(
            "%s: `%s: %s` is ignored — the framework runs the supplied baseline "
            "once at the start of a run and measures its score itself.",
            source,
            _LABELS["baseline_score"][0],
            values["baseline_score"],
        )
    missing = [field for field in _REQUIRED if not values.get(field)]
    if missing:
        labels = ", ".join(f"`{_LABELS[field][0]}`" for field in missing)
        seen = (
            ", ".join(f"`{_LABELS[f][0]}`" for f in found)
            if found
            else "none of the labels the framework reads"
        )
        raise ValueError(
            f"{source} is missing {labels}. The document declares: {seen}. Each is "
            "one labelled line in the section that states it — `指标`/`方向` in "
            "`优化指标`, `训练数据`/`验证数据` in `数据`, `baseline 代码`/"
            "`训练命令`/`评测命令` in `代码位置`."
        )

    config: dict[str, Any] = {
        "evaluation": {
            "metric": values["metric"],
            "direction": "minimize"
            if _direction_is_minimize(values["direction"], source)
            else "maximize",
            "command": values["eval_command"],
        },
        "data": {"train": values["train"], "val": values["val"]},
        # Missing labels parse to None; normalize to "" so the baseline accessors
        # (base_task.py) see absence instead of the string "None".
        "baseline": {
            "script": values["baseline_script"] or "",
            "command": values["train_command"] or "",
        },
    }
    return config
