import json
from pathlib import Path
import shlex
import sys
import time
from types import SimpleNamespace

import pytest

from autoresearch.config.settings import ExecutorContextConfig, load_config
from autoresearch.harness.types import ToolContext
from autoresearch.runner.base import ExecutionResult
from autoresearch.tools.bash import BashTool
from autoresearch.tools.file import FileReadTool, FileTreeTool
from autoresearch.tools.python_run import PythonRunTool
from autoresearch.utils.tool_output import output_preview


@pytest.fixture
def ctx(tmp_path):
    return ToolContext(tmp_path, "executor", 0, 120, execution_timeout=40)


def test_file_reads_are_paginated_and_explicit_ranges_still_work(ctx):
    source = "".join(f"line {i}\n" for i in range(1000))
    (ctx.working_dir / "source.py").write_text(source)
    first = FileReadTool().execute({"path": "source.py"}, ctx)
    assert first.success and "line 199\n" in first.output
    assert "line 200\n" not in first.output and "offset=200" in first.output
    part = FileReadTool().execute({"path": "source.py", "offset": 400, "limit": 3}, ctx)
    assert part.output.startswith("line 400\nline 401\nline 402\n")
    full = FileReadTool().execute({"path": "source.py", "limit": 1000}, ctx)
    assert full.output == source
    assert FileReadTool().execute({"path": "source.py", "limit": None}, ctx).output == source


def test_short_file_output_remains_compatible(ctx):
    (ctx.working_dir / "plan.md").write_text("brief plan")
    assert FileReadTool().execute({"path": "plan.md"}, ctx).output == "brief plan"


def test_tree_does_not_expand_every_execution_log_by_default(ctx):
    log = ctx.working_dir / "tool_logs" / "python_example" / "stdout.log"
    log.parent.mkdir(parents=True)
    log.write_text("full log")
    overview = FileTreeTool().execute({}, ctx)
    assert "tool_logs/" in overview.output and "stdout.log" not in overview.output
    explicit = FileTreeTool().execute({"path": "tool_logs"}, ctx)
    assert "stdout.log" in explicit.output


@pytest.mark.parametrize("args", [
    {"path": "../outside.py"}, {"path": ".env"}, {"path": "missing.py"},
    {"path": ""}, {"path": "train.py", "code": "print(1)"},
])
def test_path_execution_rejects_invalid_inputs_before_running(ctx, args):
    (ctx.working_dir.parent / "outside.py").write_text("raise RuntimeError('must not execute')")
    assert not PythonRunTool().execute(args, ctx).success


def test_path_execution_cannot_follow_an_external_symlink(ctx, tmp_path):
    external = tmp_path.parent / "external-script.py"
    external.write_text("raise RuntimeError('must not execute')")
    (ctx.working_dir / "alias.py").symlink_to(external)
    assert not PythonRunTool().execute({"path": "alias.py"}, ctx).success


@pytest.mark.parametrize("filename", ["train.py", "runfile.py", "nested/entry.py"])
def test_saved_script_runs_dry_and_full_with_source_file_and_imports_intact(ctx, filename):
    entry = ctx.working_dir / filename
    entry.parent.mkdir(parents=True, exist_ok=True)
    (entry.parent / "sibling.py").write_text("VALUE = 7\n")
    source = '''from __future__ import annotations
import json, os, sys
from pathlib import Path
from sibling import VALUE
with open("executions.jsonl", "a") as f:
    f.write(json.dumps({"mode": os.getenv("DRY_RUN", "0"), "file": __file__, "argv": sys.argv[0], "value": VALUE}) + "\\n")
print("score=0.8")
'''
    entry.write_text(source)
    result = PythonRunTool().execute({"path": filename, "timeout": 36}, ctx)
    assert result.success, result.output
    rows = [json.loads(line) for line in (ctx.working_dir / "executions.jsonl").read_text().splitlines()]
    assert [r["mode"] for r in rows] == ["1", "0"]
    assert all(Path(r["file"]) == entry.resolve() and Path(r["argv"]) == entry.resolve() and r["value"] == 7 for r in rows)
    assert entry.read_text() == source
    assert "full stdout:" in result.output


def test_dry_run_failure_stops_full_execution_and_retains_error_log(ctx):
    (ctx.working_dir / "train.py").write_text(
        'import os\nfrom pathlib import Path\n'
        'if os.getenv("DRY_RUN") == "1": raise RuntimeError("dry_only_failure")\n'
        'Path("full_started").touch()\n'
    )
    result = PythonRunTool().execute({"path": "train.py", "timeout": 36}, ctx)
    assert not result.success and "DRY-RUN FAILED" in result.output
    assert "dry_only_failure" in result.output and not (ctx.working_dir / "full_started").exists()
    logs = list((ctx.working_dir / "tool_logs").glob("python_*/stderr.log"))
    assert any("dry_only_failure" in path.read_text() for path in logs)


def test_legacy_inline_code_is_still_supported(ctx):
    result = PythonRunTool().execute({"code": 'print("legacy_ok")', "skip_dry_run": True, "timeout": 10}, ctx)
    assert result.success and "legacy_ok" in result.output


def test_large_python_output_is_bounded_and_full_middle_is_saved(ctx):
    (ctx.working_dir / "train.py").write_text('print("start")\nprint("x" * 100000)\nprint("MIDDLE_PROOF")\nprint("y" * 100000)\nprint("score=0.8")\n')
    result = PythonRunTool().execute({"path": "train.py", "skip_dry_run": True, "timeout": 10}, ctx)
    assert result.success and len(result.output) < 8000
    assert "start" in result.output and "score=0.8" in result.output
    logs = list((ctx.working_dir / "tool_logs").glob("python_*/stdout.log"))
    assert len(logs) == 1 and "MIDDLE_PROOF" in logs[0].read_text()
    assert len(logs[0].read_text()) > 200000


def test_bash_keeps_complete_logs_and_latest_failure(ctx):
    code = 'import sys; print("A" * 20000); print("MIDDLE_PROOF"); print("B" * 20000); sys.stderr.write("C" * 20000 + "\\nFINAL_ERROR\\n"); sys.exit(1)'
    result = BashTool().execute({"command": shlex.join([sys.executable, "-c", code]), "timeout": 10}, ctx)
    assert not result.success and len(result.output) < 13000
    assert "FINAL_ERROR" in result.output and "exit_code: 1" in result.output
    assert any("MIDDLE_PROOF" in path.read_text() for path in (ctx.working_dir / "tool_logs").glob("bash_*/stdout.log"))


def test_preview_is_bounded_and_preserves_error_tail():
    text = "startup\n" + "x" * 20000 + "\nTraceback: FINAL_ERROR"
    preview = output_preview(text)
    assert len(preview) <= 6000 and "startup" in preview and "FINAL_ERROR" in preview


def test_path_mode_keeps_per_run_timeout_and_dry_run_limits(ctx, monkeypatch):
    (ctx.working_dir / "train.py").write_text('print("saved script")')
    calls = []
    def run(self, code, workdir, timeout, extra_env=None, **kwargs):
        calls.append((code, timeout, extra_env, kwargs))
        return ExecutionResult(stdout="ok", exit_code=0)
    monkeypatch.setattr("autoresearch.runner.local.LocalRunner.run", run)
    result = PythonRunTool().execute({"path": "train.py", "timeout": 1000}, ctx)
    assert result.success and len(calls) == 2
    assert calls[0][1] == 13 and calls[1][1] == 40
    assert calls[0][2] == {"DRY_RUN": "1"}
    assert calls[0][0] == calls[1][0] == ""
    assert calls[0][3]["entry_path"] == ctx.working_dir / "train.py"


def test_bash_timeout_keeps_captured_output(ctx, monkeypatch):
    import subprocess
    def timeout(*args, **kwargs):
        raise subprocess.TimeoutExpired("fake", 1, output=b"partial_stdout", stderr=b"partial_error")
    monkeypatch.setattr("autoresearch.tools.bash.subprocess.run", timeout)
    result = BashTool().execute({"command": "fake", "timeout": 1}, ctx)
    assert not result.success and result.error == "timeout"
    assert "partial_stdout" in result.output and "partial_error" in result.output
    assert any(path.read_text() == "partial_error" for path in (ctx.working_dir / "tool_logs").glob("bash_*/stderr.log"))


def test_context_setting_is_opt_in_and_validated(tmp_path):
    assert ExecutorContextConfig().soft_limit_tokens is None
    config_path = tmp_path / "config.yaml"
    config_path.write_text('models: {test: {model_name: test}}\nroles: {code_generator: test}\nexecutor_context: {soft_limit_tokens: 32000}\n')
    config = load_config(config_path)
    assert config.executor_context.soft_limit_tokens == 32000
    with pytest.raises(ValueError):
        ExecutorContextConfig(soft_limit_tokens=10000, target_tokens=16000)


def test_executor_factory_applies_optional_budget(tmp_path, monkeypatch):
    monkeypatch.setenv("HF_ENDPOINT", "https://huggingface.co")
    from autoresearch.react_main import make_executor_factory
    class Task:
        def prepare_executor_workspace(self, *args):
            pass
        def evaluate(self, *args, **kwargs):
            return {"valid": True, "score": 0.8}
    registry = SimpleNamespace(get=lambda role: SimpleNamespace())
    factory = make_executor_factory(
        registry, {}, "", 100, time.time(), 1000, tmp_path, Task(),
        executor_context=ExecutorContextConfig(soft_limit_tokens=32000),
    )
    executor = factory(str(tmp_path))
    assert executor.context_manager._threshold_tokens == 32000
    assert executor.context_manager._tail_tokens == 8000
