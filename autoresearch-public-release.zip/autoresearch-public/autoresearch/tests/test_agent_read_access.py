from pathlib import Path

from autoresearch.agents.planner import PlannerAgent
from autoresearch.harness.types import ToolContext
from autoresearch.task.generic import GenericAdapter


def test_framework_grants_only_shared_input_and_declared_data(tmp_path, monkeypatch):
    monkeypatch.setenv("HF_ENDPOINT", "https://huggingface.co")
    from autoresearch.react_main import make_analysis_factory, make_executor_factory, _link_technique_cards

    task_dir = Path(__file__).resolve().parents[1] / "tasks" / "example_rmse"
    task = GenericAdapter(task_dir)
    workspace = tmp_path / "run"
    task.setup_workspace(workspace)
    _link_technique_cards(workspace)

    class Registry:
        def get(self, role):
            return object()

        def has(self, role):
            return True

    for factory_builder in (make_executor_factory, make_analysis_factory):
        kwargs = dict(
            llm_registry=Registry(), task_profile=task.get_task_context(), runner_timeout=10,
            budget_start_time=0, budget_total_seconds=30, workspace_dir=workspace, task=task,
            protected_paths=task.protected_paths,
        )
        if factory_builder is make_executor_factory:
            kwargs["hardware_constraint"] = ""
        plan = workspace / "working" / factory_builder.__name__
        agent = factory_builder(**kwargs)(str(plan))
        ctx = ToolContext(plan, "test", 0, 30)
        tool = agent.tool_registry
        import json
        assert tool.execute("file_read", json.dumps({"path": "input/task.md"}), ctx).success
        assert tool.execute("file_read", json.dumps({"path": str(task_dir / "data/train.csv"), "limit": 1}), ctx).success
        assert not tool.execute("file_read", json.dumps({"path": str(task_dir / "eval.py")}), ctx).success
        assert not tool.execute("file_write", json.dumps({"path": "input/task.md", "content": "changed"}), ctx).success

    planner = PlannerAgent(llm=object(), working_dir=workspace / "working", task_description="test", task_profile={})
    result = planner.tool_registry.execute(
        "file_read", '{"path":"../knowledge/INDEX.md","limit":1}',
        ToolContext(workspace / "working", "test", 0, 30),
    )
    assert result.success
