import json
from types import SimpleNamespace

import pytest

from autoresearch.harness.context import ContextManager, SUMMARY_PREFIX


class SummaryLLM:
    def __init__(self, fail=False):
        self.fail = fail
        self.prompts = []

    def chat_with_retry(self, messages, **kwargs):
        self.prompts.append(messages[0]["content"])
        if self.fail:
            raise RuntimeError("offline summary service")
        return SimpleNamespace(content="Plan: improve train.py. Score=0.8. Latest error: FIX_ME. Reopen saved files as needed.")


def history(count, *, code_chars=0, output_chars=0):
    messages = [{"role": "system", "content": "Follow the experiment plan."},
                {"role": "user", "content": "Read plan.md; implement train.py."}]
    for i in range(count):
        if i == count - 1:
            messages.append({"role": "user", "content": "[Time & Budget] 1000s left."})
        arguments = json.dumps({"path": "train.py", "content": "x" * code_chars})
        messages.append({"role": "assistant", "content": "", "tool_calls": [
            {"id": str(i), "type": "function", "function": {"name": "file_write", "arguments": arguments}},
        ]})
        messages.append({"role": "tool", "tool_call_id": str(i), "name": "file_write",
                         "content": "x" * output_chars + f"\nScore=0.8; latest error FIX_ME; log=tool_logs/{i}/stderr.log"})
    return messages


def assert_complete_pairs(messages):
    calls = {tc["id"] for m in messages for tc in m.get("tool_calls", [])}
    results = {m["tool_call_id"] for m in messages if m["role"] == "tool"}
    assert calls == results


@pytest.mark.parametrize("code_chars,output_chars,count", [(70000, 0, 8), (0, 30000, 16)])
def test_regression_code_arguments_and_consecutive_tool_results_compress(code_chars, output_chars, count):
    cm = ContextManager()
    messages = history(count, code_chars=code_chars, output_chars=output_chars)
    before = cm.estimate_tokens(messages)
    assert cm.should_compress(messages)
    llm = SummaryLLM()
    compressed = cm.compress(messages, llm)
    assert len(llm.prompts) == 1
    assert cm.estimate_tokens(compressed) < before
    assert cm.estimate_tokens(compressed) <= cm._target_tokens
    assert compressed[:2] == messages[:2]
    assert any(m.get("content", "").startswith(SUMMARY_PREFIX) for m in compressed)
    assert_complete_pairs(compressed)


def test_boundary_preserves_assistant_and_all_results_in_a_multi_call_turn():
    cm = ContextManager()
    messages = history(2)
    assistant = next(i for i, m in enumerate(messages) if m.get("tool_calls"))
    messages[assistant]["tool_calls"].append({
        "id": "extra", "type": "function", "function": {"name": "file_read", "arguments": "{}"},
    })
    messages.insert(assistant + 2, {"role": "tool", "tool_call_id": "extra", "content": "ok"})
    assert cm._snap_to_tool_boundary(messages, assistant, 2) == assistant
    assert cm._snap_to_tool_boundary(messages, assistant + 2, 2) == assistant
    assert cm._snap_to_tool_boundary(messages, len(messages), 2) == len(messages)


def test_failed_summary_uses_recent_tool_paths_and_is_not_permanently_disabled():
    cm = ContextManager()
    llm = SummaryLLM(fail=True)
    first = cm.compress(history(8, code_chars=70000), llm)
    assert any("FIX_ME" in m.get("content", "") for m in first)
    assert any("train.py" in m.get("content", "") for m in first)
    second = first + history(8, code_chars=70000)[2:]
    assert cm.should_compress(second)
    after = cm.compress(second, llm)
    assert len(llm.prompts) == 2
    assert cm.estimate_tokens(after) < cm.estimate_tokens(second)
    assert_complete_pairs(after)


def test_oversized_latest_group_can_be_compacted_without_orphaned_calls():
    cm = ContextManager()
    messages = history(1, code_chars=500000)
    assert cm.should_compress(messages)
    result = cm.compress(messages, SummaryLLM())
    assert cm.estimate_tokens(result) < cm._threshold_tokens
    assert_complete_pairs(result)


def test_soft_budget_keeps_model_window_and_reduces_context_below_target():
    cm = ContextManager(soft_limit_tokens=32000, target_tokens=16000, tail_tokens=8000, summary_tokens=2000)
    messages = history(16, code_chars=9000)
    assert cm.model_context_length == 200000
    assert cm.should_compress(messages)
    result = cm.compress(messages, SummaryLLM())
    assert cm.estimate_tokens(result) <= 16000
    assert_complete_pairs(result)


def test_calibration_converges_to_provider_usage_instead_of_square_root():
    cm = ContextManager()
    messages = [{"role": "user", "content": "x" * 3000}]
    for _ in range(100):
        cm.calibrate(cm.estimate_tokens(messages), 2000)
    assert abs(cm.estimate_tokens(messages) - 2000) <= 2


def test_oversized_fixed_instructions_are_preserved_and_retried_after_growth():
    cm = ContextManager(soft_limit_tokens=8000, target_tokens=4000, tail_tokens=1000, summary_tokens=256)
    messages = [{"role": "system", "content": "x" * 30000}, {"role": "user", "content": "plan"},
                {"role": "assistant", "content": "done"}]
    for _ in range(2):
        result = cm.compress(messages, SummaryLLM())
        assert result[:2] == messages[:2]
    grown = messages + [{"role": "user", "content": "new evidence " * 1000}]
    assert cm.should_compress(grown)


def test_summary_format_preserves_recent_error_instead_of_only_oldest_messages():
    cm = ContextManager()
    messages = [{"role": "user", "content": f"old-{i}: " + "x" * 3000} for i in range(40)]
    messages.append({"role": "tool", "name": "python_run", "content": "Latest: FINAL_ERROR /tool_logs/final.log"})
    text = cm._format_messages_for_summary(messages)
    assert "old-0" in text and "FINAL_ERROR" in text
    assert len(text) <= 30000


def test_long_executor_history_keeps_compressing_with_large_system_prompt():
    cm = ContextManager(soft_limit_tokens=32000, target_tokens=16000, tail_tokens=8000, summary_tokens=2000)
    llm = SummaryLLM()
    messages = [{"role": "system", "content": "s" * 36000}, {"role": "user", "content": "Implement plan.md"}]
    for i in range(200):
        if cm.should_compress(messages):
            messages = cm.compress(messages, llm)
        assert cm.estimate_tokens(messages) <= 32000
        messages.extend([
            {"role": "assistant", "content": "", "tool_calls": [{"id": str(i), "type": "function", "function": {"name": "file_edit", "arguments": json.dumps({"path": "train.py", "new_string": "x" * 6000})}}]},
            {"role": "tool", "tool_call_id": str(i), "name": "file_edit", "content": "y" * 2000},
        ])
    assert len(llm.prompts) > 2
    assert messages[0]["content"] == "s" * 36000
    assert_complete_pairs(messages)
