import json
import os
from pathlib import Path
import shlex
import sys

import pytest

from autoresearch.harness.types import ToolContext
from autoresearch.runner.environment import build_execution_env
from autoresearch.runner.local import LocalRunner
from autoresearch.runner.watchdog import WatchdogConfig
from autoresearch.task.generic import GenericAdapter
from autoresearch.tools.bash import BashTool


_SECRET_NAMES = ("LLM_API_KEY", "HF_TOKEN", "SERVICE_CLIENT_SECRET",
                 "WEB_SEARCH_API_KEY", "AWS_SESSION_TOKEN", "CUSTOM_SERVICE_SECRET", "HTTPS_PROXY")


def test_environment_is_an_allowlist_with_private_home(tmp_path):
    parent = {key: "synthetic-secret" for key in _SECRET_NAMES}
    parent.update({"PATH": os.defpath, "CUDA_VISIBLE_DEVICES": "0", "OMP_NUM_THREADS": "2",
                   "HOME": "/host-home", "PYTHONPATH": "/host-imports", "BASH_ENV": "/host-script"})
    env = build_execution_env(tmp_path, {"DRY_RUN": "1"}, source=parent)
    assert not set(_SECRET_NAMES) & env.keys()
    assert "PYTHONPATH" not in env and "BASH_ENV" not in env
    assert env["CUDA_VISIBLE_DEVICES"] == "0" and env["OMP_NUM_THREADS"] == "2"
    assert env["DRY_RUN"] == "1" and env["PYTHONNOUSERSITE"] == "1"
    assert Path(env["HOME"]).is_dir() and Path(env["HOME"]).is_relative_to(tmp_path)
    assert parent["HOME"] == "/host-home"


def test_extra_env_cannot_reintroduce_service_keys(tmp_path):
    with pytest.raises(ValueError, match="Unsupported task environment"):
        build_execution_env(tmp_path, {"LLM_API_KEY": "synthetic-secret"})


def test_runtime_directory_cannot_be_redirected(tmp_path):
    work = tmp_path / "work"
    work.mkdir()
    (work / ".runtime").symlink_to(tmp_path, target_is_directory=True)
    with pytest.raises(ValueError, match="runtime directory"):
        build_execution_env(work)


@pytest.mark.parametrize("executor", ["bash", "python", "task_command"])
def test_real_children_do_not_inherit_credentials(tmp_path, monkeypatch, executor):
    for key in _SECRET_NAMES:
        monkeypatch.setenv(key, "synthetic-secret")
    monkeypatch.setenv("AUTORESEARCH_RANDOM_CUSTOM_VALUE", "also-not-runtime")
    code = "import os, json; print(json.dumps(dict(os.environ)))"
    if executor == "bash":
        result = BashTool().execute(
            {"command": shlex.quote(sys.executable) + " -c " + shlex.quote(code), "timeout": 10},
            ToolContext(tmp_path, "test", 0, 30),
        )
        assert result.success, result.output
        env = json.loads(result.output.splitlines()[0])
    elif executor == "python":
        result = LocalRunner(WatchdogConfig(enabled=False)).run(code, tmp_path, 10)
        assert result.exit_code == 0, result.stderr
        env = json.loads(result.stdout)
    else:
        task = GenericAdapter.__new__(GenericAdapter)
        result = task._run(
            shlex.join([sys.executable, "-c", code]), cwd=tmp_path,
            substitutions={}, log_prefix=tmp_path / "logs" / "command", timeout=10,
        )
        env = json.loads(result.stdout)
    assert not set(_SECRET_NAMES) & env.keys()
    assert "AUTORESEARCH_RANDOM_CUSTOM_VALUE" not in env
    assert "synthetic-secret" not in str(env)
    assert Path(env["HOME"]).is_relative_to(tmp_path)


def test_shell_does_not_automatically_load_host_startup_file(tmp_path, monkeypatch):
    startup = tmp_path / "startup"
    marker = tmp_path / "executed"
    startup.write_text("touch " + shlex.quote(str(marker)))
    monkeypatch.setenv("BASH_ENV", str(startup))
    result = BashTool().execute({"command": "bash -c 'echo ok'", "timeout": 10}, ToolContext(tmp_path, "test", 0, 30))
    assert result.success and not marker.exists()
