from pathlib import Path

import pytest

from autoresearch.harness.types import ToolContext
from autoresearch.tools.file import FileEditTool, FileReadTool, FileTreeTool, FileWriteTool
from autoresearch.tools.plan import PlanEditTool, PlanReadTool, PlanWriteTool
from autoresearch.tools.task import TaskSpawnTool, _confine_summary_path


@pytest.fixture
def ctx(tmp_path):
    work = tmp_path / "working"
    work.mkdir()
    return ToolContext(work, "test", 0, 30)


@pytest.mark.parametrize("kind", ["relative", "absolute", "symlink", "parent_symlink"])
def test_read_write_and_edit_cannot_escape(ctx, tmp_path, kind):
    outside = tmp_path / "outside.txt"
    outside.write_text("original")
    if kind == "relative":
        path = "../outside.txt"
    elif kind == "absolute":
        path = str(outside)
    elif kind == "symlink":
        (ctx.working_dir / "alias").symlink_to(outside)
        path = "alias"
    else:
        (ctx.working_dir / "alias").symlink_to(tmp_path, target_is_directory=True)
        path = "alias/outside.txt"
    assert not FileReadTool().execute({"path": path}, ctx).success
    assert not FileWriteTool().execute({"path": path, "content": "changed"}, ctx).success
    assert not FileEditTool().execute({"path": path, "old_string": "original", "new_string": "changed"}, ctx).success
    assert outside.read_text() == "original"


def test_cannot_create_file_through_external_directory_link(ctx, tmp_path):
    (ctx.working_dir / "alias").symlink_to(tmp_path, target_is_directory=True)
    result = FileWriteTool().execute({"path": "alias/new.txt", "content": "changed"}, ctx)
    assert not result.success
    assert not (tmp_path / "new.txt").exists()


def test_writes_with_symlinked_workspace_keep_the_same_policy(ctx, tmp_path):
    alias = tmp_path / "work_alias"
    alias.symlink_to(ctx.working_dir, target_is_directory=True)
    alias_ctx = ToolContext(alias, "test", 0, 30)
    writer = FileWriteTool(protected_paths=["input"])
    assert writer.execute({"path": "relative.txt", "content": "ok"}, alias_ctx).success
    assert writer.execute({"path": str(alias / "absolute.txt"), "content": "ok"}, alias_ctx).success
    assert not writer.execute({"path": str(alias / "input/task.md"), "content": "blocked"}, alias_ctx).success


@pytest.mark.parametrize("private", [".labels/truth.csv", ".env", ".env.production", ".runtime/home/token", ".git/config"])
def test_private_files_and_their_aliases_are_denied(ctx, private):
    target = ctx.working_dir / private
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("synthetic private data")
    (ctx.working_dir / "alias").symlink_to(target)
    for path in (private, "alias"):
        assert not FileReadTool().execute({"path": path}, ctx).success
        assert not FileWriteTool().execute({"path": path, "content": "changed"}, ctx).success
    tree = FileTreeTool().execute({}, ctx)
    assert tree.success and "alias" not in tree.output
    assert private.split("/")[0] not in tree.output


def test_explicit_shared_input_is_readable_but_not_writable(ctx, tmp_path):
    shared = tmp_path / "shared"
    shared.mkdir()
    (shared / "task.md").write_text("shared task")
    (ctx.working_dir / "input").symlink_to(shared, target_is_directory=True)
    reader = FileReadTool(allowed_read_paths=(shared,))
    assert reader.execute({"path": "input/task.md"}, ctx).output == "shared task"
    assert "task.md" in FileTreeTool(allowed_read_paths=(shared,)).execute({}, ctx).output
    assert not FileWriteTool().execute({"path": "input/task.md", "content": "changed"}, ctx).success
    # An explicit grant is captured independently of the workspace's symlink.
    (ctx.working_dir / "input").unlink()
    (ctx.working_dir / "input").symlink_to(tmp_path, target_is_directory=True)
    (tmp_path / "task.md").write_text("outside")
    assert not reader.execute({"path": "input/task.md"}, ctx).success


def test_grant_to_one_data_file_does_not_grant_its_siblings(ctx, tmp_path):
    train = tmp_path / "train.csv"
    truth = tmp_path / "truth.csv"
    train.write_text("training")
    truth.write_text("hidden")
    reader = FileReadTool(allowed_read_paths=(train,))
    assert reader.execute({"path": str(train)}, ctx).success
    assert not reader.execute({"path": str(truth)}, ctx).success


def test_protected_alias_and_editable_policy(ctx):
    real = ctx.working_dir / "real"
    real.mkdir()
    target = real / "data.txt"
    target.write_text("original")
    (ctx.working_dir / "input").symlink_to(real, target_is_directory=True)
    writer = FileWriteTool(protected_paths=["input"])
    assert not writer.execute({"path": "real/data.txt", "content": "changed"}, ctx).success
    assert not writer.execute({"path": "input/data.txt", "content": "changed"}, ctx).success
    writer = FileWriteTool(editable_paths=["outputs"])
    assert writer.execute({"path": "outputs/result.txt", "content": "first"}, ctx).success
    editor = FileEditTool(editable_paths=["outputs"])
    assert editor.execute({"path": "outputs/result.txt", "old_string": "first", "new_string": "second"}, ctx).success
    assert (ctx.working_dir / "outputs/result.txt").read_text() == "second"
    assert not writer.execute({"path": "other.txt", "content": "changed"}, ctx).success


def test_tree_never_traverses_external_links_and_handles_cycles(ctx, tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "private.txt").write_text("private")
    (ctx.working_dir / "external").symlink_to(outside, target_is_directory=True)
    (ctx.working_dir / "loop").symlink_to(ctx.working_dir, target_is_directory=True)
    (ctx.working_dir / "public.txt").write_text("public")
    result = FileTreeTool().execute({"max_depth": 20}, ctx)
    assert result.success and "public.txt" in result.output
    assert "private.txt" not in result.output and "external" not in result.output
    assert len(result.output) < 500


def test_plan_tools_and_summary_paths_cannot_escape(ctx, tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    plan = outside / "plan.md"
    plan.write_text("original")
    (ctx.working_dir / "alias").symlink_to(outside, target_is_directory=True)
    for path in (str(outside), "../outside", "alias"):
        assert not PlanReadTool().execute({"plan_dir": path}, ctx).success
        assert not PlanEditTool().execute({"plan_dir": path, "old_string": "original", "new_string": "changed"}, ctx).success
        assert _confine_summary_path(str(Path(path) / "plan.md"), ctx.working_dir) is None
    assert plan.read_text() == "original"
    assert PlanWriteTool().execute({"plan_dir": "test", "content": "new plan"}, ctx).success
    assert PlanReadTool().execute({"plan_dir": "exp001_test"}, ctx).output == "new plan"


def test_subtasks_cannot_change_the_workspace_root(ctx, tmp_path):
    # Exercise validation before any agent or LLM is dispatched.
    tool = TaskSpawnTool.__new__(TaskSpawnTool)
    tool._factories = {"executor": lambda path: None}
    (ctx.working_dir / "alias").symlink_to(tmp_path, target_is_directory=True)
    for path in (str(tmp_path), "..", "alias"):
        specs, error = tool._build_specs("executor", {"plan_dirs": [path]}, ctx)
        assert specs is None and error is not None and not error.success
