import json
import os
import sys
import threading
import time
import zipfile
from concurrent.futures import ThreadPoolExecutor
from itertools import product
from pathlib import Path
from types import ModuleType, SimpleNamespace

import pytest

os.environ.setdefault("HF_ENDPOINT", "https://huggingface.co")

from autoresearch import react_main
from autoresearch.agents.executor import ExecutorAgent
from autoresearch.config.settings import AblationConfig, AutoResearchConfig, load_config
from autoresearch.harness.subagent import SubAgentManager, SubAgentSpec
from autoresearch.harness.telemetry import set_recorder
from autoresearch.harness.types import AgentResult, ToolContext
from autoresearch.task.mlebench import MLEBenchAdapter
from autoresearch.tests.test_usage_accounting import ScriptedLLM, response
from autoresearch.tools.eval import TaskEvalTool
from autoresearch.utils.hardware import HardwareInfo
from autoresearch.utils.summarize_usage import export_reports

PROJECT = Path(__file__).resolve().parents[1]


@pytest.fixture
def competition(tmp_path, monkeypatch):
    """Exercise the real adapter against the documented MLE-bench API boundary."""
    data = tmp_path / "data"
    public = data / "fake-competition" / "prepared" / "public"
    private = public.parent / "private"
    public.mkdir(parents=True)
    private.mkdir()
    (public / "description.md").write_text(
        "Synthetic competition. Predict y from public training data."
    )
    (public / "train.csv").write_text("id,y\n0,1\n")
    (public / "test.csv").write_text("id\n1\n")
    (public / "sample_submission.csv").write_text("id,y\n1,0\n")
    answers = private / "answers.csv"
    answers.write_text("private answers must not be linked to the workspace")

    class Grader:
        name = "accuracy"

        def __call__(self, submission, labels):
            assert labels == answers.read_text()
            return float(submission.strip().splitlines()[-1].split(",")[-1])

    comp = SimpleNamespace(
        id="fake-competition",
        description=(public / "description.md").read_text(),
        public_dir=public,
        private_dir=private,
        answers=answers,
        raw_dir=public.parents[1] / "raw",
        leaderboard=data / "leaderboard.csv",
        grader=Grader(),
        sample_submission=public / "sample_submission.csv",
    )

    class Registry:
        last_data_dir = None

        def __init__(self, data_dir=data):
            self.root = Path(data_dir)
            Registry.last_data_dir = self.root

        def get_competition(self, competition_id):
            if competition_id != comp.id:
                raise FileNotFoundError(competition_id)
            return comp

        def get_data_dir(self):
            return self.root

    def module(name, **attrs):
        result = ModuleType(name)
        result.__dict__.update(attrs)
        monkeypatch.setitem(sys.modules, name, result)

    def no_leaderboard(path):
        raise FileNotFoundError(path)

    module("pandas", read_csv=no_leaderboard)
    module("mlebench")
    module("mlebench.registry", Registry=Registry)
    module(
        "mlebench.utils",
        read_csv=lambda p: Path(p).read_text(),
        load_answers=lambda p: Path(p).read_text(),
    )
    module(
        "mlebench.data",
        is_dataset_prepared=lambda c: c.answers.exists() and c.public_dir.exists(),
    )
    module("mlebench.grade", validate_submission=lambda p, c: (p.is_file(), "checked"))
    return SimpleNamespace(comp=comp, data=data, Registry=Registry)


def test_adapter_data_setup_grading_and_split_policy(competition, tmp_path):
    adapter = MLEBenchAdapter(competition.data, competition_id=competition.comp.id)
    root = tmp_path / "run"
    report = adapter.check(root)
    assert report["ok"]
    assert not adapter.has_supplied_baseline
    assert adapter.wants_analysis_agents
    assert (
        (root / "input" / "train.csv")
        .resolve()
        .is_relative_to(competition.comp.public_dir)
    )
    assert not (root / "input" / "answers.csv").exists()
    assert not (root / "input" / "private").exists()
    plan = root / "working" / "exp001"
    plan.mkdir()
    (plan / "plan.md").write_text("## Experiment Mode\nbaseline_generation")
    adapter.prepare_executor_workspace(plan, root)
    assert not (plan / "train.py").exists()
    submission = plan / "submission" / "submission.csv"
    submission.parent.mkdir()
    submission.write_text("id,y\n1,0.75\n")
    context = ToolContext(
        working_dir=plan,
        agent_name="executor",
        iteration=0,
        budget_remaining_seconds=100,
    )
    tool = TaskEvalTool(adapter)
    assert tool.parameters_schema["properties"]["split"]["enum"] == ["test"]
    assert tool.execute({}, context).success  # Default must select test, not dev.
    metric = json.loads((plan / "metrics.json").read_text())
    assert metric["score"] == 0.75
    assert metric["split"] == "test"
    assert metric["evaluation_protocol"] == "mlebench_legacy_test_feedback"
    assert metric["competition_id"] == competition.comp.id
    assert not tool.execute({"split": "dev"}, context).success
    for bad_value in ("nan", "inf", "invalid"):
        submission.write_text(f"id,y\n1,{bad_value}\n")
        assert not adapter.evaluate(plan)["valid"]


def test_data_dir_precedence_and_invalid_ids(competition, tmp_path, monkeypatch):
    monkeypatch.setenv("MLEBENCH_DATA_DIR", str(tmp_path / "env-data"))
    MLEBenchAdapter(competition_id=competition.comp.id)
    assert competition.Registry.last_data_dir == tmp_path / "env-data"
    MLEBenchAdapter(competition.data, competition_id=competition.comp.id)
    assert competition.Registry.last_data_dir == competition.data
    with pytest.raises(ValueError, match="Cannot load MLE-bench competition"):
        MLEBenchAdapter(competition.data, competition_id="unknown-competition")
    for invalid in ("", "../../other", "/tmp/task", "a/b"):
        with pytest.raises(ValueError, match="competition-id"):
            MLEBenchAdapter(competition.data, competition_id=invalid)


def test_missing_dependency_has_install_instructions(monkeypatch):
    monkeypatch.setitem(sys.modules, "mlebench", None)
    with pytest.raises(ValueError, match="MLE-bench is not installed"):
        MLEBenchAdapter(competition_id="leaf-classification")


def test_archives_are_extracted_locally_and_reject_path_escape(tmp_path):
    public = tmp_path / "public"
    public.mkdir()
    source = public / "train.zip"
    with zipfile.ZipFile(source, "w") as archive:
        archive.writestr("train/image.png", b"pixels")
    inputs = tmp_path / "input"
    inputs.mkdir()
    (inputs / "train.zip").symlink_to(source)
    MLEBenchAdapter._extract_archives(inputs)
    assert (inputs / "train" / "image.png").read_bytes() == b"pixels"
    assert source.exists()
    assert not (inputs / "train.zip").exists()
    with zipfile.ZipFile(inputs / "escape.zip", "w") as archive:
        archive.writestr("../../escape.txt", b"bad")
    with pytest.raises(ValueError, match="Unsafe archive"):
        MLEBenchAdapter._extract_archives(inputs)
    assert not (tmp_path / "escape.txt").exists()
    assert not (inputs / "escape").exists()


@pytest.mark.parametrize(
    "single,solutions,no_memory", list(product((False, True), repeat=3))
)
def test_complete_mlebench_run_and_all_ablation_combinations(
    competition,
    tmp_path,
    monkeypatch,
    single,
    solutions,
    no_memory,
):
    abl = AblationConfig(
        single_executor=single, solution_only=solutions, no_knowledge_mgmt=no_memory
    )

    def tool(name, **args):
        result = response()
        result.content = ""
        result.tool_calls = [
            {"id": name, "function": {"name": name, "arguments": json.dumps(args)}}
        ]
        return result

    planner_calls = []
    if not solutions:
        planner_calls += [
            tool(
                "plan_write",
                plan_dir="diag_data",
                content="Describe public training data",
            ),
            tool("task_spawn", agent_type="analysis", plan_dirs=["diag_data"]),
        ]
    for name, mode in (
        ("exp001_baseline", "baseline_generation"),
        ("exp002_candidate", "candidate_improvement"),
    ):
        planner_calls += [
            tool("plan_write", plan_dir=name, content=f"## Experiment Mode\n{mode}"),
            tool("task_spawn", agent_type="executor", plan_dirs=[name]),
        ]
    if not no_memory:
        planner_calls += [
            tool("task_spawn", agent_type="summarizer", plan_dirs=["exp002_candidate"]),
            tool(
                "task_spawn",
                agent_type="knowledge_manager",
                input_text="synthetic findings",
            ),
        ]
    planner_calls += [tool("finish", result="done")]
    claim = {
        "insight": "Synthetic finding",
        "confidence": 0.6,
        "evidence": ["exp001_baseline", "exp002_candidate"],
    }
    models = {
        "planner": ScriptedLLM(*planner_calls),
        "code_generator": ScriptedLLM(response(), response()),
        "analysis": ScriptedLLM(tool("finish", result="data evidence")),
        "evaluator": ScriptedLLM(tool("finish", result="summary")),
        "distiller": ScriptedLLM(
            tool("knowledge_add", **claim), tool("finish", result="saved")
        ),
        "promoter": ScriptedLLM(
            tool("knowledge_add", **claim), tool("finish", result="promoted")
        ),
    }
    config = AutoResearchConfig(
        llm={role: model.config for role, model in models.items()}, ablation=abl
    )
    monkeypatch.setattr(react_main, "load_config", lambda p: config)
    monkeypatch.setattr(
        react_main,
        "LLMRegistry",
        lambda _: SimpleNamespace(get=lambda r: models[r], has=lambda r: r in models),
    )
    monkeypatch.setattr(react_main, "detect_hardware", lambda: HardwareInfo())

    captured = {}
    original_run = react_main.PlannerAgent.run

    def inspect_planner(agent):
        captured["schema"] = agent.tool_registry.get("task_spawn").parameters_schema
        captured["prompt"] = agent.get_system_prompt()
        captured["concurrency"] = agent._subagent_manager.max_workers
        captured["knowledge_list"] = agent.tool_registry.get("knowledge_list")
        return original_run(agent)

    monkeypatch.setattr(react_main.PlannerAgent, "run", inspect_planner)

    def fake_training(agent):
        agent.llm.chat([])
        path = agent.working_dir
        if "baseline" in path.name:
            assert not (path / "train.py").exists()
            (path / "train.py").write_text("# generated baseline\n")
        else:
            assert (path / "train.py").read_text() == "# generated baseline\n"
        (path / "artifacts").mkdir()
        (path / "artifacts" / "model.bin").write_bytes(b"model")
        (path / "submission").mkdir()
        (path / "submission" / "submission.csv").write_text(
            "id,y\n1," + ("0.5" if "baseline" in path.name else "0.8") + "\n"
        )
        captured["executor_prompt"] = agent.get_system_prompt()
        return AgentResult(success=True, final_response="trained", iterations_used=1)

    monkeypatch.setattr(ExecutorAgent, "run", fake_training)
    root = tmp_path / "workspace" / "mlebench" / competition.comp.id / "run"
    if no_memory:
        root.mkdir(parents=True)
        (root / "knowledge.json").write_text("must not be loaded or overwritten")
        (root.parent / "task_knowledge.json").write_text(
            "must not be loaded or overwritten"
        )
    try:
        task = MLEBenchAdapter(competition.data, competition_id=competition.comp.id)
        assert react_main.run(tmp_path / "config.yaml", root, task).success
        summary = json.loads((root / "api_usage_summary.json").read_text())
        assert summary["measurement_complete"]
        assert summary["metadata"]["ablation"] == abl.model_dump()
        assert summary["metadata"]["method_label"] == abl.method_label
        assert summary["metadata"]["best_score"] == 0.8
        assert summary["metadata"]["effective_executor_concurrency"] == (
            1 if single else 2
        )
        assert summary["metadata"]["analysis_enabled"] == (not solutions)
        assert summary["metadata"]["knowledge_enabled"] == (not no_memory)
        assert summary["experiments"]["completed"] == 1
        assert summary["baselines"]["completed"] == 1
        assert summary["diagnostics"]["completed"] == (0 if solutions else 1)
        available = captured["schema"]["properties"]["agent_type"]["enum"]
        assert ("analysis" in available) == (not solutions)
        assert ("summarizer" in available) == (not no_memory)
        assert ("knowledge_manager" in available) == (not no_memory)
        assert ("AnalysisAgent" in captured["prompt"]) == (not solutions)
        assert ("Dispatch the summarizer" in captured["prompt"]) == (not no_memory)
        assert ("ONE Executor at a time" in captured["prompt"]) == single
        assert "no task.md" in captured["executor_prompt"]
        assert "Create a reproducible local validation split" in captured["prompt"]
        assert ("knowledge_promoter" in summary["by_agent"]) == (not no_memory)
        if no_memory:
            assert captured["knowledge_list"] is None
            assert (
                root / "knowledge.json"
            ).read_text() == "must not be loaded or overwritten"
            assert (
                root.parent / "task_knowledge.json"
            ).read_text() == "must not be loaded or overwritten"
        else:
            assert (root.parent / "task_knowledge.json").is_file()
        report = json.loads((root / "final_report.json").read_text())
        assert report["score"] == 0.8
        assert report["score_split"] == "test"
        assert report["evaluation_protocol"] == "mlebench_legacy_test_feedback"
        assert (root / "final" / "artifacts" / "model.bin").is_file()
        output = tmp_path / "tables"
        assert export_reports([root], output)["runs.csv"] == 1
        assert "mlebench_legacy_test_feedback" in (output / "runs.csv").read_text(
            encoding="utf-8-sig"
        )
    finally:
        set_recorder(None)


@pytest.mark.parametrize("workers", [1, 2])
def test_concurrency_limit_is_shared_by_background_batches(tmp_path, workers):
    manager = SubAgentManager(max_workers=workers, timeout_per_agent=3)
    lock = threading.Lock()
    counts = {"active": 0, "peak": 0}

    class Agent:
        name = "executor"

        def __init__(self, index):
            self.working_dir = tmp_path / f"exp{index}"

        def run(self):
            with lock:
                counts["active"] += 1
                counts["peak"] = max(counts["peak"], counts["active"])
            time.sleep(0.03)
            with lock:
                counts["active"] -= 1
            return AgentResult(success=True, final_response="done", iterations_used=1)

    with ThreadPoolExecutor(max_workers=2) as pool:
        jobs = [
            pool.submit(
                manager.spawn_parallel,
                [SubAgentSpec(lambda i=i: Agent(i)) for i in indexes],
            )
            for indexes in ((1, 2), (3, 4))
        ]
        assert all(result.success for job in jobs for result in job.result())
    assert counts == {"active": 0, "peak": workers}


def test_ablation_yaml_extends_default():
    for name in ("1_single_executor", "2_solution_only", "3_no_knowledge_mgmt"):
        config = load_config(PROJECT / "config" / f"ablation_{name}.yaml")
        flag = name[2:]
        assert config.ablation.model_dump() == {
            key: key == flag for key in AblationConfig.model_fields
        }
        assert config.budget.max_concurrent == 2


def test_cli_routes_competition_id_without_task_directory(
    competition, tmp_path, monkeypatch
):
    captured = {}

    def fake_run(**kwargs):
        captured.update(kwargs)
        return AgentResult(success=True, final_response="done", iterations_used=0)

    monkeypatch.setattr(react_main, "run", fake_run)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "autoresearch",
            "--bench",
            "mlebench",
            "--competition-id",
            competition.comp.id,
            "--bench-dir",
            str(competition.data),
            "--workspace",
            str(tmp_path / "runs"),
        ],
    )
    react_main.main()
    assert isinstance(captured["task"], MLEBenchAdapter)
    assert (
        captured["workspace_dir"].parent
        == tmp_path / "runs" / "mlebench" / competition.comp.id
    )


@pytest.mark.parametrize(
    "args",
    [
        ["--bench", "mlebench"],
        ["--task-dir", "task", "--competition-id", "leaf-classification"],
        ["--bench", "mlebench", "--task-dir", "task"],
    ],
)
def test_cli_rejects_inconsistent_task_arguments(monkeypatch, args):
    monkeypatch.setattr(sys, "argv", ["autoresearch", *args])
    with pytest.raises(SystemExit) as exc:
        react_main.main()
    assert exc.value.code == 2
