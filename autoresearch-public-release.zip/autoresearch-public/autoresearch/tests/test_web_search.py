from types import SimpleNamespace

import pytest
import requests

from autoresearch.tools import web


@pytest.fixture
def isolated_search(monkeypatch):
    monkeypatch.setattr(web, "_cache_get", lambda *args: None)
    monkeypatch.setattr(web, "_cache_put", lambda *args: None)
    monkeypatch.setattr(web.time, "sleep", lambda _: None)


def test_search_uses_configured_json_endpoint(monkeypatch, isolated_search):
    calls = []

    def post(url, **kwargs):
        calls.append((url, kwargs))
        return SimpleNamespace(
            status_code=200, raise_for_status=lambda: None,
            json=lambda: {"results": [{"title": "Result", "url": "https://example.com/paper",
                                      "snippet": "A research result."}]},
        )

    monkeypatch.setattr(web.requests, "post", post)
    output = web._run_web_search(["research"], {
        "url": "https://search.example.com/query", "api_key": "synthetic-test-token", "max_results": 3,
    })
    assert "https://example.com/paper" in output
    assert "A research result." in output
    assert calls == [("https://search.example.com/query", {
        "json": {"query": "research", "max_results": 3},
        "headers": {"Authorization": "Bearer synthetic-test-token", "Content-Type": "application/json"},
        "timeout": (5, 30),
    })]
    assert "synthetic-test-token" not in output


@pytest.mark.parametrize("config", [{}, {"url": "https://search.example.com"}, {"api_key": "synthetic-test-token"}])
def test_unconfigured_search_does_not_call_network(monkeypatch, config):
    def unexpected_call(*args, **kwargs):
        pytest.fail("Unconfigured search must not call the network")

    monkeypatch.setattr(web.requests, "post", unexpected_call)
    assert "not configured" in web._run_web_search(["research"], config)


def test_search_auth_failure_is_not_retried_or_disclosed(monkeypatch, isolated_search):
    calls = []

    def fail():
        raise requests.exceptions.HTTPError("401 Authorization: Bearer synthetic-test-token")

    def post(*args, **kwargs):
        calls.append(True)
        return SimpleNamespace(status_code=401, raise_for_status=fail)

    monkeypatch.setattr(web.requests, "post", post)
    output = web._run_web_search(["research"], {
        "url": "https://search.example.com", "api_key": "synthetic-test-token",
    })
    assert len(calls) == 1
    assert "HTTPError" in output
    assert "synthetic-test-token" not in output
