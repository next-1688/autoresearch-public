from types import SimpleNamespace

import pytest

from autoresearch.config.settings import LLMRoleConfig
from autoresearch.harness.telemetry import get_recorder, read_jsonl, set_recorder
from autoresearch.llm.base import BaseLLM, LLMAPIError
from autoresearch.llm.openai_llm import OpenAILLM, OpenAIResponsesLLM


@pytest.fixture
def recorder(tmp_path):
    BaseLLM.set_cost_log_path(tmp_path / "api_costs.jsonl")
    yield get_recorder()
    set_recorder(None)


def usage():
    return SimpleNamespace(
        prompt_tokens=100,
        completion_tokens=20,
        total_tokens=120,
        prompt_tokens_details=SimpleNamespace(cached_tokens=40),
        completion_tokens_details=SimpleNamespace(reasoning_tokens=8),
    )


def provider(create, *, responses=False, include_stream_usage=True):
    cls = OpenAIResponsesLLM if responses else OpenAILLM
    llm = cls.__new__(cls)
    BaseLLM.__init__(llm)
    llm.config = LLMRoleConfig(model="test", include_stream_usage=include_stream_usage)
    llm._primary_consecutive_failures = 0
    llm._fallback_client = None
    if responses:
        llm._client = SimpleNamespace(responses=SimpleNamespace(create=create))
        llm._cache_key = None
    else:
        llm._client = SimpleNamespace(
            chat=SimpleNamespace(completions=SimpleNamespace(create=create))
        )
    return llm


class Stream:
    def __init__(self, chunks, error=None):
        self.chunks = chunks
        self.error = error
        self.closed = False

    def __iter__(self):
        yield from self.chunks
        if self.error:
            raise self.error

    def close(self):
        self.closed = True


def chunk(text=None, tokens=None):
    return SimpleNamespace(
        usage=tokens,
        choices=[
            SimpleNamespace(delta=SimpleNamespace(content=text), finish_reason=None)
        ]
        if text is not None
        else [],
    )


def test_stream_requests_usage_and_does_not_sum_cumulative_chunks(recorder):
    stream = Stream([chunk("hello"), chunk(tokens=usage()), chunk(tokens=usage())])
    requests = []

    def create(**kwargs):
        requests.append(kwargs)
        return stream

    result = provider(create).chat([])
    assert requests[0]["stream_options"] == {"include_usage": True}
    assert result.usage["total_tokens"] == 120
    assert result.usage["cache_read_input_tokens"] == 40
    assert result.usage["reasoning_tokens"] == 8
    assert recorder.summary()["total_tokens"] == 120
    assert stream.closed


def test_stream_usage_can_be_disabled_for_compatible_gateways(recorder):
    requests = []

    def create(**kwargs):
        requests.append(kwargs)
        return Stream([chunk("hello")])

    provider(create, include_stream_usage=False).chat([])
    assert "stream_options" not in requests[0]
    assert recorder.summary()["usage_missing_calls"] == 1


@pytest.mark.parametrize("reported", [False, True])
def test_interrupted_stream_retains_known_usage_and_original_error(recorder, reported):
    chunks = [chunk("partial")]
    if reported:
        chunks.append(chunk(tokens=usage()))
    stream = Stream(chunks, error=RuntimeError("disconnected"))
    with pytest.raises(RuntimeError, match="disconnected"):
        provider(lambda **kwargs: stream).chat([])
    summary = recorder.summary()
    assert summary["failed_calls"] == 1
    assert summary["total_tokens"] == (120 if reported else 0)
    assert summary["usage_missing_calls"] == (0 if reported else 1)
    assert stream.closed


def test_nonstream_tool_calls_extract_usage(recorder):
    requests = []

    def create(**kwargs):
        requests.append(kwargs)
        return SimpleNamespace(
            usage=usage(),
            choices=[
                SimpleNamespace(
                    message=SimpleNamespace(
                        content=None,
                        tool_calls=[
                            SimpleNamespace(
                                id="tool-id",
                                function=SimpleNamespace(name="finish", arguments="{}"),
                            )
                        ],
                    )
                )
            ],
        )

    result = provider(create).chat(
        [], tools=[{"type": "function", "function": {"name": "finish"}}]
    )
    assert not requests[0]["stream"]
    assert "stream_options" not in requests[0]
    assert result.tool_calls[0]["function"]["name"] == "finish"
    assert recorder.summary()["reasoning_tokens"] == 8


def test_responses_content_validation_does_not_lose_billable_usage(recorder):
    resp = SimpleNamespace(
        usage=SimpleNamespace(
            input_tokens=100,
            output_tokens=20,
            total_tokens=120,
            input_tokens_details=SimpleNamespace(cached_tokens=40),
            output_tokens_details=SimpleNamespace(reasoning_tokens=8),
        ),
        output=[],
        status="incomplete",
        incomplete_details="limit",
    )
    with pytest.raises(LLMAPIError, match="no content"):
        provider(lambda **kwargs: resp, responses=True).chat([])
    saved = read_jsonl(recorder.root / "api_costs.jsonl")[0]
    assert saved["status"] == "failed"
    assert saved["total_tokens"] == 120
    assert saved["reasoning_tokens"] == 8
    assert saved["cache_read_tokens"] == 40
