import email
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import zipfile

import pytest


PROJECT = Path(__file__).resolve().parents[1]
PRIVATE_CANARY = "-".join(("synthetic", "secret", "not", "for", "release")).encode()
PRIVATE_FILES = (
    "config/.env.production", "config/settings.local.yaml", "config/.runtime/token",
    "config/settings.local.yml", "config/notes.local.md", "config/EXPERIMENT_TRACKER.md",
    "config/workspace_full_r1/run.json", "config/workspace-full-r1/run.json",
    "config/api_costs.jsonl", "config/api_usage_summary.json", "config/run_metadata.json",
    "config/llm_conversations.jsonl", "config/activity_events.jsonl", "config/metrics.jsonl",
    "config/run.log",
)


def test_license_copies_match():
    repository_license = PROJECT.parent / "LICENSE"
    if repository_license.is_file():
        assert repository_license.read_bytes() == (PROJECT / "LICENSE").read_bytes()


@pytest.fixture(scope="module")
def release_artifacts(tmp_path_factory):
    uv = shutil.which("uv")
    if uv is None:
        pytest.skip("Packaging checks require uv")
    root = tmp_path_factory.mktemp("release")
    project = root / "autoresearch"
    shutil.copytree(PROJECT, project, ignore=shutil.ignore_patterns(
        ".venv", "__pycache__", ".pytest_cache", ".runtime", "workspace", "dist", "build", ".env",
    ))
    # Release selection must remain safe even without Git or .gitignore files.
    for path in project.rglob(".gitignore"):
        path.unlink()
    for name in PRIVATE_FILES:
        target = project / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(PRIVATE_CANARY)
    output = root / "dist"
    result = subprocess.run(
        [uv, "build", "--out-dir", str(output)], cwd=project,
        text=True, capture_output=True, timeout=120,
    )
    assert result.returncode == 0, result.stderr
    return root, next(output.glob("*.whl")), next(output.glob("*.tar.gz"))


@pytest.mark.packaging
def test_wheel_from_sdist_contains_package_resources_and_license(release_artifacts):
    _, wheel, sdist = release_artifacts
    with zipfile.ZipFile(wheel) as archive:
        names = archive.namelist()
        for expected in ("__init__.py", "__main__.py", "react_main.py", "prompts/planner.j2",
                         "task/mlebench.py", "task/registry.py", "prompts/mlebench/planner.j2",
                         "prompts/mlebench/executor.j2", "config/ablation_1_single_executor.yaml",
                         "config/ablation_2_solution_only.yaml", "config/ablation_3_no_knowledge_mgmt.yaml",
                         "scripts/mlebench_prepare_ablation.sh",
                         "harness/telemetry.py", "utils/summarize_usage.py", "utils/tool_output.py",
                         "config/default_config.yaml", "knowledge/INDEX.md", "tasks/example_rmse/task.md",
                         "tasks/example_rmse/data/train.csv", "tasks/example_rmse/.labels/val_truth.csv"):
            assert "autoresearch/" + expected in names
        assert all(n.startswith("autoresearch/") or ".dist-info/" in n for n in names)
        metadata = email.message_from_bytes(archive.read(next(n for n in names if n.endswith(".dist-info/METADATA"))))
        assert metadata["License-Expression"] == "MIT"
        assert metadata.get_all("License-File") == ["LICENSE"]
        license_file = next(n for n in names if n.endswith(".dist-info/licenses/LICENSE"))
        assert archive.read(license_file) == (PROJECT / "LICENSE").read_bytes()
        assert any(d.lower().startswith("jinja2") for d in metadata.get_all("Requires-Dist"))
        assert any(d.lower().startswith("requests") for d in metadata.get_all("Requires-Dist"))
        assert not any("tests/" in n or ".runtime/" in n for n in names)
        assert not any(n.endswith("/" + private) for n in names for private in PRIVATE_FILES)
        assert not any(PRIVATE_CANARY in archive.read(n) for n in names if not n.endswith("/"))
    with tarfile.open(sdist) as archive:
        names = archive.getnames()
        prefix = names[0].split("/")[0] + "/"
        assert archive.extractfile(prefix + "LICENSE").read() == (PROJECT / "LICENSE").read_bytes()
        assert prefix + ".env.example" in names
        assert prefix + "tests/test_file_boundaries.py" in names
        assert not any(".runtime/" in n for n in names)
        assert not any(n.endswith("/" + private) for n in names for private in PRIVATE_FILES)
        assert not any(PRIVATE_CANARY in archive.extractfile(n).read()
                       for n in names if archive.getmember(n).isfile())


@pytest.mark.packaging
@pytest.mark.parametrize("entry_name, help_flag", [("autoresearch", "--task-dir"), ("autoresearch-usage", "--output")])
def test_wheel_import_and_console_entry_outside_checkout(release_artifacts, entry_name, help_flag):
    root, wheel, _ = release_artifacts
    installed = root / "installed"
    with zipfile.ZipFile(wheel) as archive:
        archive.extractall(installed)
    code = (
        "import sys; from pathlib import Path; from importlib.metadata import distribution; "
        f"sys.path.insert(0, {str(installed)!r}); "
        "import autoresearch; "
        f"assert Path(autoresearch.__file__).is_relative_to({str(installed)!r}); "
        "from autoresearch.harness.prompt import PromptRenderer; "
        "PromptRenderer()._env.get_template('planner.j2'); "
        f"entry = next(e for e in distribution('autoresearch').entry_points if e.name == {entry_name!r}); "
        "entry.load()()"
    )
    env = dict(os.environ, HF_ENDPOINT="https://huggingface.co", PYTHONDONTWRITEBYTECODE="1")
    result = subprocess.run(
        [sys.executable, "-I", "-c", code, "--help"], cwd=root, env=env,
        text=True, capture_output=True, timeout=30,
    )
    assert result.returncode == 0, result.stderr
    assert help_flag in result.stdout
