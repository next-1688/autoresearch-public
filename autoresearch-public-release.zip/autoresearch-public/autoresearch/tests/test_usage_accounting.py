import csv
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace

import pytest

from autoresearch.config.settings import AutoResearchConfig, LLMRoleConfig
from autoresearch.harness.telemetry import (
    agent_activity,
    current_context,
    get_recorder,
    read_jsonl,
    scheduling_wait,
    set_recorder,
)
from autoresearch.harness.types import AgentResult
from autoresearch.llm.base import BaseLLM, LLMAPIError, LLMResponse
from autoresearch.tools.eval import write_metrics_record
from autoresearch.utils.summarize_usage import export_reports


class ScriptedLLM(BaseLLM):
    def __init__(self, *responses, pricing=None):
        super().__init__()
        self.responses = iter(responses)
        self.config = LLMRoleConfig(model="test-model", pricing=pricing)

    def _chat_impl(self, messages, tools=None, tool_choice=None):
        result = next(self.responses)
        if isinstance(result, BaseException):
            raise result
        return result


def response(tokens=10):
    return LLMResponse(
        content="ok",
        usage={
            "prompt_tokens": tokens,
            "completion_tokens": 2,
            "total_tokens": tokens + 2,
        },
    )


@pytest.fixture
def recorder(tmp_path):
    BaseLLM.set_cost_log_path(tmp_path / "api_costs.jsonl")
    yield get_recorder()
    set_recorder(None)


def evaluate(path, score=1.0, valid=True):
    task = SimpleNamespace(metric_name="rmse", baseline_metric_key="baseline_rmse")
    return write_metrics_record(task, path, "dev", {"score": score, "valid": valid})


def test_success_failure_missing_zero_and_partial_usage_are_all_counted(recorder):
    llm = ScriptedLLM(
        response(),
        LLMResponse(content="no usage"),
        LLMResponse(content="zero", usage={"prompt_tokens": 0, "completion_tokens": 0}),
        LLMAPIError("bad response", usage={"prompt_tokens": 7, "completion_tokens": 3}),
        LLMResponse(content="partial", usage={"prompt_tokens": 4}),
    )
    for _ in range(3):
        llm.chat([])
    with pytest.raises(LLMAPIError, match="bad response"):
        llm.chat([])
    llm.chat([])
    summary = recorder.summary()
    assert summary["calls"] == 5
    assert summary["successful_calls"] == 4
    assert summary["failed_calls"] == 1
    assert summary["usage_missing_calls"] == 2
    assert summary["input_tokens"] == 21
    assert summary["output_tokens"] == 5
    assert summary["total_tokens"] == 26
    assert not summary["tokens_complete"]
    assert summary["total_cost"] is None
    costs = read_jsonl(recorder.root / "api_costs.jsonl")
    conversations = read_jsonl(recorder.root / "llm_conversations.jsonl")
    assert len(costs) == len(conversations) == 5
    assert [row["call_id"] for row in costs] == [
        row["call_id"] for row in conversations
    ]
    assert costs[1]["input_tokens"] is None
    assert costs[2]["input_tokens"] == 0
    assert costs[3]["input_tokens"] == 7


def test_framework_retries_are_counted_without_extra_calls(recorder, monkeypatch):
    monkeypatch.setattr("autoresearch.llm.base.time.sleep", lambda delay: None)
    llm = ScriptedLLM(TimeoutError("timeout"), response())
    llm.chat_with_retry([], max_retries=2)
    summary = BaseLLM.get_cost_summary()
    assert summary["calls"] == 2
    assert summary["failed_calls"] == summary["successful_calls"] == 1
    assert summary["usage_missing_calls"] == 1


def test_parallel_attribution_repeated_evaluation_and_later_summary(recorder):
    def worker(index):
        path = recorder.root / "working" / f"exp{index:03d}"
        with agent_activity("executor", path, "candidate_improvement") as outcome:
            llm = ScriptedLLM(response(index + 1))
            llm.chat([])
            evaluate(path)
            evaluate(path)  # Two eval calls, one experiment attempt.
            recorder.event("decision", accepted=index == 0)
            outcome["success"] = True

    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(worker, range(8)))
    path = recorder.root / "working" / "exp000"
    with agent_activity("summarizer", path) as outcome:
        ScriptedLLM(response(30)).chat([])
        outcome["success"] = True
    # Reusing a directory starts a new attempt, not a new evaluation of old files.
    with agent_activity("executor", path, "candidate_improvement"):
        ScriptedLLM(response()).chat([])
    summary = recorder.summary()
    assert summary["calls"] == 10
    assert summary["experiments"] == {
        "started": 9,
        "completed": 8,
        "failed": 1,
        "in_progress": 0,
        "accepted": 1,
        "execution_failed": 1,
    }
    assert (
        len({r["call_id"] for r in read_jsonl(recorder.root / "api_costs.jsonl")}) == 10
    )
    saved = json.loads((path / "api_usage.json").read_text())
    assert saved["calls"] == 3
    assert saved["by_agent"]["summarizer"]["calls"] == 1
    assert saved["by_agent"]["executor"]["calls"] == 2
    assert all(
        a["evaluation_count"] == 2
        for a in summary["activities"]
        if a["agent"] == "executor" and a["completed"]
    )
    assert current_context().agent == "unknown"


def test_nested_scopes_restore_planner_and_pause_wait_time(recorder, monkeypatch):
    clock = [100.0]
    monkeypatch.setattr("autoresearch.harness.telemetry.time.time", lambda: clock[0])
    monkeypatch.setattr(
        "autoresearch.harness.telemetry.time.perf_counter", lambda: clock[0]
    )
    with agent_activity("planner", recorder.root / "working") as planner:
        ScriptedLLM(response()).chat([])
        clock[0] = 110
        with (
            scheduling_wait(True),
            agent_activity(
                "analysis", recorder.root / "working" / "diag001"
            ) as analysis,
        ):
            ScriptedLLM(response()).chat([])
            clock[0] = 130
            analysis["success"] = True
        assert current_context().agent == "planner"
        ScriptedLLM(response()).chat([])
        clock[0] = 135
        planner["success"] = True
    summary = recorder.summary()
    assert summary["by_phase"]["planning"]["active_seconds"] == 15
    assert summary["by_phase"]["epistemic_actions"]["active_seconds"] == 20
    assert summary["public_overhead"]["calls"] == 2
    assert summary["diagnostics"]["completed"] == 1
    assert sum(p["call_share"] for p in summary["by_phase"].values()) == pytest.approx(
        1
    )
    assert sum(
        p["activity_time_share"] for p in summary["by_phase"].values()
    ) == pytest.approx(1)


def test_baseline_is_separate_and_inflight_call_is_visible(recorder):
    path = recorder.root / "working" / "exp001_baseline"
    with agent_activity("executor", path, "supplied_baseline_reproduction") as outcome:
        evaluate(path)
        outcome["success"] = True
    recorder.event("llm_call_started", call_id="inflight")
    recorder.finish("interrupted")
    summary = json.loads((recorder.root / "api_usage_summary.json").read_text())
    assert summary["experiments"]["completed"] == 0
    assert summary["baselines"]["completed"] == 1
    assert summary["completed_experiments_including_baseline"] == 1
    assert summary["in_progress_calls"] == 1
    assert summary["usage_missing_calls"] == 1


def test_configured_cost_and_token_breakdowns_do_not_double_count(recorder):
    llm = ScriptedLLM(
        LLMResponse(
            content="ok",
            usage={
                "prompt_tokens": 100,
                "completion_tokens": 20,
                "total_tokens": 120,
                "cache_read_input_tokens": 40,
                "reasoning_tokens": 8,
            },
        ),
        pricing={
            "input_per_million": 2,
            "output_per_million": 6,
            "cache_read_per_million": 1,
        },
    )
    llm.chat([])
    summary = recorder.summary()
    assert summary["total_tokens"] == 120
    assert summary["reasoning_tokens"] == 8
    assert summary["cache_read_tokens"] == 40
    assert summary["total_cost"] == pytest.approx(0.00028)


def test_run_failure_still_saves_metadata_without_credentials(tmp_path, monkeypatch):
    monkeypatch.setenv("HF_ENDPOINT", "https://huggingface.co")
    from autoresearch import react_main

    config = AutoResearchConfig(
        llm={"planner": LLMRoleConfig(model="test", api_key="DO_NOT_SAVE")}
    )
    monkeypatch.setattr(react_main, "load_config", lambda path: config)

    def fail(*args):
        ScriptedLLM(response()).chat([])
        raise RuntimeError("failure")

    monkeypatch.setattr(react_main, "_run", fail)
    task = SimpleNamespace(metric_name="rmse", metric_lower_is_better=True)
    root = tmp_path / "task" / "run"
    with pytest.raises(RuntimeError, match="failure"):
        react_main.run(tmp_path / "config.yaml", root, task, method_label="no_l3")
    summary = json.loads((root / "api_usage_summary.json").read_text())
    assert summary["metadata"]["status"] == "failed"
    assert summary["metadata"]["method_label"] == "no_l3"
    assert summary["calls"] == 1
    assert "DO_NOT_SAVE" not in (root / "run_metadata.json").read_text()
    set_recorder(None)


def test_executor_auto_evaluation_counts_even_if_agent_reports_failure(
    recorder, monkeypatch
):
    monkeypatch.setenv("HF_ENDPOINT", "https://huggingface.co")
    from autoresearch.agents.executor import ExecutorAgent
    from autoresearch.react_main import make_executor_factory

    def fake_run(agent):
        submission = agent.working_dir / "submission" / "submission.csv"
        submission.parent.mkdir(parents=True)
        submission.write_text("prediction")
        return AgentResult(
            success=False, final_response="budget exhausted", iterations_used=1
        )

    monkeypatch.setattr(ExecutorAgent, "run", fake_run)
    task = SimpleNamespace(
        metric_name="rmse",
        baseline_metric_key="baseline_rmse",
        agent_visible_locations={},
        prepare_executor_workspace=lambda path, root: path.mkdir(parents=True),
        cleanup_plan_artifacts=lambda path: None,
        _read_experiment_mode=lambda path: "candidate_improvement",
        evaluate=lambda *args, **kwargs: {"score": 1.0, "valid": True},
    )
    factory = make_executor_factory(
        SimpleNamespace(get=lambda role: object()),
        {},
        "",
        300,
        0,
        100,
        recorder.root,
        task,
    )
    result = factory(str(recorder.root / "working" / "exp_auto")).run()
    assert not result.success
    assert recorder.summary()["experiments"]["completed"] == 1
    assert recorder.summary()["experiments"]["execution_failed"] == 1


def test_export_multiple_runs_preserves_method_and_deduplicates_paths(
    recorder, tmp_path
):
    recorder.update_metadata(task_name="task", method_label="full")
    with agent_activity(
        "executor", recorder.root / "working" / "exp001", "candidate_improvement"
    ) as outcome:
        ScriptedLLM(response()).chat([])
        evaluate(recorder.root / "working" / "exp001")
        outcome["success"] = True
    recorder.finish("succeeded")
    from autoresearch.harness.telemetry import UsageRecorder

    other = UsageRecorder(
        tmp_path / "ablation", {"method_label": "no_l3", "task_name": "task"}
    )
    other.finish("succeeded")
    output = tmp_path / "tables"
    counts = export_reports([tmp_path, recorder.root], output)
    assert counts["runs.csv"] == 2
    with (output / "runs.csv").open(encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    assert {row["method"] for row in rows} == {"full", "no_l3"}
    full = next(row for row in rows if row["method"] == "full")
    assert full["calls"] == full["experiments_completed"] == "1"
    assert full["estimated_cost_usd"] == ""
    assert counts["experiments.csv"] == 1


def test_export_replays_events_when_summary_is_stale(recorder, tmp_path):
    # A crash can occur after the JSONL write but before the JSON view refresh.
    recorder.event("llm_call_started", call_id="unfinished")
    summary_path = recorder.root / "api_usage_summary.json"
    summary_path.write_text("{}")
    output = tmp_path / "export"
    export_reports([recorder.root], output)
    with (output / "runs.csv").open(encoding="utf-8-sig") as handle:
        row = next(csv.DictReader(handle))
    assert row["calls"] == row["in_progress_calls"] == "1"
    assert row["measurement_complete"] == "False"


def test_logging_failure_does_not_replace_model_result_or_error(recorder, monkeypatch):
    def fail(*args):
        raise OSError("disk full")

    monkeypatch.setattr(recorder, "_append", fail)
    llm = ScriptedLLM(response(), RuntimeError("provider error"))
    assert llm.chat([]).content == "ok"
    with pytest.raises(RuntimeError, match="provider error"):
        llm.chat([])


def test_optional_subprocess_usage_is_persisted_and_not_double_counted(recorder):
    path = recorder.root / "subprocess_tokens.jsonl"
    path.write_text(
        json.dumps(
            {
                "agent": "grader",
                "experiment": "exp001",
                "input_tokens": 7,
                "output_tokens": 3,
            }
        )
        + "\n"
    )
    for _ in range(2):
        summary = BaseLLM.get_cost_summary(extra_paths=[path])
        assert summary["calls"] == 1
        assert summary["total_tokens"] == 10
        assert summary["externally_reported_calls"] == 1
    recorder.finish("succeeded")
    from autoresearch.harness.telemetry import load_run_summary

    assert load_run_summary(recorder.root)["calls"] == 1
    assert len(read_jsonl(recorder.root / "api_costs.jsonl")) == 1


def test_complete_run_accounts_for_candidates_summaries_and_l3(tmp_path, monkeypatch):
    """Exercise actual planner/tools/factories/retention/finalization without training."""
    monkeypatch.setenv("HF_ENDPOINT", "https://huggingface.co")
    from autoresearch import react_main
    from autoresearch.agents.executor import ExecutorAgent
    from autoresearch.task.generic import GenericAdapter
    from autoresearch.utils.hardware import HardwareInfo

    def tool(name, **args):
        return LLMResponse(
            content="",
            usage=response().usage,
            tool_calls=[
                {
                    "id": name,
                    "function": {"name": name, "arguments": json.dumps(args)},
                }
            ],
        )

    claim = {
        "insight": "Synthetic test finding",
        "confidence": 0.6,
        "evidence": ["exp001_baseline", "exp002_candidate"],
    }
    models = {
        "planner": ScriptedLLM(
            tool(
                "plan_write",
                plan_dir="exp001_baseline",
                content="## Experiment Mode\nsupplied_baseline_reproduction",
            ),
            tool("task_spawn", agent_type="executor", plan_dirs=["exp001_baseline"]),
            tool(
                "plan_write",
                plan_dir="exp002_candidate",
                content="## Experiment Mode\ncandidate_improvement",
            ),
            tool("task_spawn", agent_type="executor", plan_dirs=["exp002_candidate"]),
            tool("task_spawn", agent_type="summarizer", plan_dirs=["exp002_candidate"]),
            tool(
                "task_spawn",
                agent_type="knowledge_manager",
                input_text="synthetic evidence",
            ),
            tool("finish", result="done"),
        ),
        "code_generator": ScriptedLLM(response(), response()),
        "evaluator": ScriptedLLM(tool("finish", result="summary")),
        "distiller": ScriptedLLM(
            tool("knowledge_add", **claim), tool("finish", result="saved")
        ),
        "promoter": ScriptedLLM(
            tool("knowledge_add", **claim), tool("finish", result="promoted")
        ),
    }
    config = AutoResearchConfig(
        llm={role: model.config for role, model in models.items()}
    )
    monkeypatch.setattr(react_main, "load_config", lambda path: config)
    monkeypatch.setattr(
        react_main,
        "LLMRegistry",
        lambda settings: SimpleNamespace(
            get=lambda role: models[role], has=lambda role: role in models
        ),
    )
    monkeypatch.setattr(react_main, "detect_hardware", lambda: HardwareInfo())


    def fake_train(agent):
        agent.llm.chat([])
        path = agent.working_dir / "submission" / "submission.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("id,y_pred\n0,1\n")
        score = 10.0 if "baseline" in agent.working_dir.name else 5.0
        write_metrics_record(
            agent._task,
            agent.working_dir,
            "dev",
            {
                "valid": True,
                "score": score,
                "baseline_rmse": 10.0,
            },
        )
        return AgentResult(success=True, final_response="trained", iterations_used=1)

    monkeypatch.setattr(ExecutorAgent, "run", fake_train)
    task_dir = Path(__file__).resolve().parents[1] / "tasks" / "example_rmse"
    task = GenericAdapter(task_dir)
    root = tmp_path / "task" / "run"
    try:
        result = react_main.run(tmp_path / "config.yaml", root, task)
        assert result.success
        summary = json.loads((root / "api_usage_summary.json").read_text())
        assert summary["calls"] == 14
        assert summary["experiments"]["completed"] == 1
        assert summary["baselines"]["completed"] == 1
        assert summary["experiments"]["accepted"] == 1
        assert summary["by_phase"]["revision"]["calls"] == 4
        assert summary["by_agent"]["knowledge_promoter"]["calls"] == 2
        assert summary["metadata"]["best_score"] == 5.0
        assert not summary["metadata"]["l3_loaded"]
        assert summary["measurement_complete"]
        candidate = json.loads(
            (root / "working" / "exp002_candidate" / "api_usage.json").read_text()
        )
        assert candidate["by_agent"]["summarizer"]["calls"] == 1
        assert (root / "final").is_dir()
        assert (root.parent / "task_knowledge.json").is_file()
    finally:
        set_recorder(None)
