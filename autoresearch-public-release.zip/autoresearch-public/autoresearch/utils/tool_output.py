"""Small model-facing previews with complete, readable logs kept on disk."""

from __future__ import annotations

import re
import uuid
from pathlib import Path

_ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
DEFAULT_PREVIEW_CHARS = 6000


def output_preview(text: str, max_chars: int = DEFAULT_PREVIEW_CHARS) -> str:
    """Keep startup context and the latest traceback/metrics; strip terminal noise."""
    cleaned = _ANSI.sub("", text).replace("\r", "\n")
    if len(cleaned) <= max_chars:
        return cleaned
    marker = f"\n... [output shortened; {len(text)} captured characters, full log on disk] ...\n"
    available = max(0, max_chars - len(marker))
    if not available:
        return marker[:max_chars]
    head = available // 4
    tail = available - head
    return cleaned[:head] + marker + (cleaned[-tail:] if tail else "")


def new_log_dir(workdir: Path, tool: str) -> Path:
    root = workdir.resolve()
    directory = root / "tool_logs" / f"{tool}_{uuid.uuid4().hex}"
    if not directory.resolve().is_relative_to(root):
        raise ValueError("Tool logs must stay inside the working directory")
    directory.mkdir(parents=True, exist_ok=False)
    return directory


def save_output_logs(workdir: Path, tool: str, stdout: str, stderr: str) -> tuple[Path, Path]:
    directory = new_log_dir(workdir, tool)
    paths = directory / "stdout.log", directory / "stderr.log"
    for path, content in zip(paths, (stdout, stderr)):
        path.write_text(content, encoding="utf-8", errors="replace")
    return paths


def log_reference(path: Path | None, workdir: Path) -> str:
    if path is None:
        return ""
    try:
        return str(path.relative_to(workdir.resolve()))
    except ValueError:
        return str(path)
