"""Deterministic auto-diagnostics module.

Runs after every successful experiment to extract structured diagnostic signals
from stdout. No LLM calls — pure Python.
"""
from __future__ import annotations

import re
from typing import Any

import numpy as np


# =============================================================================
# stdout parsing (universal — works for all competition types)
# =============================================================================

_FOLD_SCORE_PATTERNS = [
    re.compile(r"[Ff]old\s*[\[#]?\s*(\d+)\]?\s*(?:score|val|metric|auc|f1|rmse|mae|acc\w*)\s*[:=]\s*([\d.]+)", re.IGNORECASE),
    re.compile(r"[Ff]old\s*(\d+)\s*[:|-]\s*([\d.]+)"),
    re.compile(r"(?:CV|cv)\s*[Ff]old\s*(\d+)\s*[:=]\s*([\d.]+)"),
    re.compile(r"\[Fold\s*(\d+)\]\s*.*?[:=]\s*([\d.]+)"),
]

_TRAIN_VAL_PATTERN = re.compile(
    r"(?:epoch|step)\s*[\[#]?\s*(\d+)\]?\s*.*?"
    r"train[_\s]?loss\s*[:=]\s*([\d.]+).*?"
    r"val[_\s]?loss\s*[:=]\s*([\d.]+)",
    re.IGNORECASE,
)

_EARLY_STOP_PATTERN = re.compile(
    r"[Ee]arly\s*stop\w*\s*(?:at|after)?\s*(?:epoch|step)\s*[\[#]?\s*(\d+)",
)


def parse_stdout_diagnostics(stdout: str) -> dict[str, Any]:
    result: dict[str, Any] = {}

    # Extract fold scores
    fold_scores: dict[int, float] = {}
    for pattern in _FOLD_SCORE_PATTERNS:
        for match in pattern.finditer(stdout):
            fold_idx = int(match.group(1))
            score = float(match.group(2))
            if 0 <= fold_idx <= 20 and 0 <= score <= 1e6:
                fold_scores[fold_idx] = score
        if fold_scores:
            break

    if fold_scores:
        scores = [fold_scores[k] for k in sorted(fold_scores.keys())]
        result["fold_scores"] = scores
        if len(scores) >= 2:
            result["fold_variance"] = float(np.var(scores))

    # Extract train-val gap from last epoch
    train_val_matches = list(_TRAIN_VAL_PATTERN.finditer(stdout))
    if train_val_matches:
        last = train_val_matches[-1]
        train_loss = float(last.group(2))
        val_loss = float(last.group(3))
        result["train_val_gap"] = val_loss - train_loss

    # Extract early stopping / convergence epoch
    es_match = _EARLY_STOP_PATTERN.search(stdout)
    if es_match:
        result["convergence_epoch"] = int(es_match.group(1))

    return result
