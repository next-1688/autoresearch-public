"""Export research usage tables: python -m autoresearch.utils.summarize_usage."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

from ..harness.telemetry import load_run_summary


def export_reports(roots: list[Path], output: Path) -> dict[str, int]:
    paths: set[Path] = set()
    for root in roots:
        if root.is_file():
            paths.add(root.resolve())
        else:
            paths.update(path.resolve() for path in root.rglob("run_metadata.json"))
    runs, phases, experiments = [], [], []
    for path in sorted(paths):
        summary = load_run_summary(path.parent)
        metadata = summary["metadata"]
        common = {
            "run_id": metadata["run_id"],
            "task": metadata.get("task_name", ""),
            "method": metadata.get("method_label", ""),
            "benchmark": metadata.get("benchmark", ""),
            "competition_id": metadata.get("competition_id", ""),
            "evaluation_protocol": metadata.get("evaluation_protocol", ""),
            "score_split": metadata.get("score_split", ""),
            "run_directory": str(path.parent),
            "status": metadata.get("status", "unknown"),
            "measurement_complete": summary["measurement_complete"],
        }
        counts = summary["experiments"]
        runs.append(
            {
                **common,
                "models": ";".join(
                    sorted({v["model"] for v in metadata.get("models", {}).values()})
                ),
                "budget_seconds": metadata.get("budget", {}).get("total_time_seconds"),
                "incumbent_loaded": metadata.get("incumbent_loaded"),
                "l3_loaded": metadata.get("l3_loaded"),
                "calls": summary["calls"],
                "externally_reported_calls": summary["externally_reported_calls"],
                "successful_calls": summary["successful_calls"],
                "failed_calls": summary["failed_calls"],
                "in_progress_calls": summary["in_progress_calls"],
                "usage_missing_calls": summary["usage_missing_calls"],
                "input_tokens": summary["input_tokens"],
                "output_tokens": summary["output_tokens"],
                "total_tokens": summary["total_tokens"],
                "tokens_complete": summary["tokens_complete"],
                "cache_read_tokens": summary["cache_read_tokens"],
                "cache_creation_tokens": summary["cache_creation_tokens"],
                "reasoning_tokens": summary["reasoning_tokens"],
                "estimated_cost_usd": summary["total_cost"],
                "experiments_started": counts["started"],
                "experiments_completed": counts["completed"],
                "experiments_failed": counts["failed"],
                "experiments_accepted": counts["accepted"],
                "experiments_in_progress": counts["in_progress"],
                "baselines_completed": summary["baselines"]["completed"],
                "completed_including_baseline": summary[
                    "completed_experiments_including_baseline"
                ],
                "diagnostics_completed": summary["diagnostics"]["completed"],
                "wall_clock_seconds": summary["wall_clock_seconds"],
                "cumulative_activity_seconds": summary["cumulative_activity_seconds"],
                "in_progress_activities": summary["in_progress_activities"],
                "metric": metadata.get("metric"),
                "best_score": metadata.get("best_score"),
            }
        )
        for phase, values in sorted(summary["by_phase"].items()):
            phases.append(
                {
                    **common,
                    "phase": phase,
                    **{
                        key: values[key]
                        for key in (
                            "calls",
                            "successful_calls",
                            "failed_calls",
                            "usage_missing_calls",
                            "input_tokens",
                            "output_tokens",
                            "total_tokens",
                            "active_seconds",
                            "call_share",
                            "activity_time_share",
                        )
                    },
                }
            )
        for activity in summary["activities"]:
            if activity["agent"] not in {"executor", "analysis"}:
                continue
            experiments.append(
                {
                    **common,
                    "activity_id": activity["activity_id"],
                    "experiment": activity["experiment"],
                    "agent": activity["agent"],
                    "mode": activity.get("mode"),
                    "execution_status": activity["status"],
                    "completed_valid_evaluation": activity["completed"],
                    "accepted": activity["accepted"],
                    "evaluation_count": activity["evaluation_count"],
                    "last_score": activity.get("last_score"),
                    "active_seconds": activity["active_seconds"],
                }
            )
    output.mkdir(parents=True, exist_ok=True)
    tables = {"runs.csv": runs, "phases.csv": phases, "experiments.csv": experiments}
    for name, rows in tables.items():
        with (output / name).open("w", encoding="utf-8-sig", newline="") as handle:
            if rows:
                writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
    return {name: len(rows) for name, rows in tables.items()}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Export run, phase and experiment usage tables"
    )
    parser.add_argument(
        "roots",
        nargs="+",
        type=Path,
        help="Run directories, workspace roots, or summary JSON files",
    )
    parser.add_argument("--output", type=Path, default=Path("api_usage_report"))
    args = parser.parse_args()
    for root in args.roots:
        if not root.exists():
            parser.error(f"input does not exist: {root}")
    counts = export_reports(args.roots, args.output)
    if not counts["runs.csv"]:
        parser.error("no recorded runs found (run_metadata.json)")
    for name, count in counts.items():
        print(f"{args.output / name}: {count} rows")


if __name__ == "__main__":
    main()
