"""Pull a named metric out of a command's stdout or log.

This is the whole coupling between the framework and a task's evaluation:
the task prints its number, the framework reads it back. Nothing here parses
the task's data, so a task can be tabular, image, audio, or text without the
framework knowing which.

Matching is deliberately three-tiered. Exact match is what a well-behaved eval
script gives us. Fuzzy match covers the common drift between the metric name
written in the task document and the one the script happens to print
(``eval_loss`` vs ``loss``, ``RMSE`` vs ``rmse``). When both fail we do not
guess: :func:`extract_metric` reports every ``key: value`` pair it saw, so the
error message tells the task author exactly what their script printed and they
can fix one side or the other.

Last occurrence wins. A training log prints the metric once per epoch and the
final line is the one that describes the model that got saved.

Besides the named extraction above, this module also hosts :func:`extract_score`
— the unkeyed variant used by the ``python_run`` tool, where the script is
free-form and signals its result with an explicit ``__SCORE__:`` marker or a
keyword like ``Final RMSE:``.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

#: A float, in any form a print statement or a formatter is likely to emit:
#: ``0.456``, ``-1e-3``, ``3``, ``nan``, ``inf``. Percent signs are handled by
#: the caller-visible ``was_percent`` flag rather than silently divided by 100.
_NUMBER = r"[-+]?(?:\d+\.?\d*(?:[eE][-+]?\d+)?|\.\d+(?:[eE][-+]?\d+)?|nan|inf|Inf|NaN)"

#: ``name: 0.456`` / ``name = 0.456`` / ``'name': 0.456`` / ``"name" : 0.456``
#: Also tolerates a trailing ``%`` and surrounding brackets from dict reprs.
_ASSIGNMENT = re.compile(
    r"""["']?(?P<key>[A-Za-z_][A-Za-z0-9_.\-/]*)["']?\s*[:=]\s*(?P<value>""" + _NUMBER + r")(?P<pct>\s*%)?",
)


@dataclass
class MetricExtraction:
    """Outcome of one extraction attempt.

    ``found`` is the only field a caller must check. ``matched_key`` and
    ``how`` exist so the failure and the near-miss are both explainable in a
    log line rather than needing a rerun to diagnose.
    """

    found: bool
    value: float | None = None
    matched_key: str | None = None
    how: str = "not_found"  # exact | fuzzy | not_found
    was_percent: bool = False
    all_values: list[float] = field(default_factory=list)
    all_metrics_found: dict[str, list[float]] = field(default_factory=dict)

    def describe(self) -> str:
        """One line fit for a log or an exception message."""
        if self.found:
            note = ""
            if self.how == "fuzzy":
                note = f" (fuzzy match on {self.matched_key!r})"
            if self.was_percent:
                note += " (printed with a % sign; value taken verbatim)"
            return f"{self.matched_key}={self.value}{note}"
        if not self.all_metrics_found:
            return "no `key: value` pairs found in the output at all"
        seen = ", ".join(
            f"{k}={v[-1]}" for k, v in sorted(self.all_metrics_found.items())
        )
        return f"metric not found. The output printed: {seen}"


def scan_metrics(text: str) -> dict[str, list[float]]:
    """Every ``key: value`` pair in ``text``, in order of appearance.

    Used both to find the target metric and, when that fails, to show the
    task author what their script actually printed.
    """
    found: dict[str, list[float]] = {}
    for match in _ASSIGNMENT.finditer(text):
        try:
            value = float(match.group("value"))
        except ValueError:
            continue
        found.setdefault(match.group("key"), []).append(value)
    return found


def _normalize(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", name.lower())


def _fuzzy_candidates(target: str, keys: list[str]) -> list[str]:
    """Keys that plausibly mean ``target``, best first.

    Ordered most-conservative-first so a caller that takes the head gets the
    tightest interpretation: exact-after-normalization, then one name contained
    in the other. Ties keep source order, so an earlier-printed key wins.
    """
    norm_target = _normalize(target)
    if not norm_target:
        return []
    exact_norm = [k for k in keys if _normalize(k) == norm_target]
    contains = [
        k
        for k in keys
        if k not in exact_norm
        and (norm_target in _normalize(k) or _normalize(k) in norm_target)
    ]
    return exact_norm + contains


def extract_metric(text: str, metric_name: str) -> MetricExtraction:
    """Find ``metric_name`` in ``text``.

    Never raises and never guesses: a miss comes back as ``found=False`` with
    ``all_metrics_found`` populated so the caller can report the mismatch.
    """
    all_found = scan_metrics(text or "")

    values = all_found.get(metric_name)
    if values:
        return MetricExtraction(
            found=True,
            value=values[-1],
            matched_key=metric_name,
            how="exact",
            was_percent=_printed_as_percent(text, metric_name),
            all_values=values,
            all_metrics_found=all_found,
        )

    for key in _fuzzy_candidates(metric_name, list(all_found)):
        values = all_found[key]
        if values:
            return MetricExtraction(
                found=True,
                value=values[-1],
                matched_key=key,
                how="fuzzy",
                was_percent=_printed_as_percent(text, key),
                all_values=values,
                all_metrics_found=all_found,
            )

    return MetricExtraction(found=False, all_metrics_found=all_found)


def _printed_as_percent(text: str, key: str) -> bool:
    """Whether the last occurrence of ``key`` carried a ``%``.

    Reported rather than acted on. A script printing ``3.79%`` and one printing
    ``0.0379`` differ by 100x, and silently dividing would make every later
    delta wrong in a way no one would notice; surfacing it lets the run stop.
    """
    last = None
    for match in _ASSIGNMENT.finditer(text or ""):
        if match.group("key").strip("\"'") == key:
            last = match
    return bool(last and last.group("pct"))


def require_metric(text: str, metric_name: str, *, source: str = "output") -> float:
    """Like :func:`extract_metric` but raise with a usable message on a miss.

    The message names the metric that was expected and lists what was printed,
    because the fix is always on one of those two sides.
    """
    result = extract_metric(text, metric_name)
    if not result.found:
        raise ValueError(
            f"Could not read metric {metric_name!r} from {source}. "
            f"{result.describe()}. Either print it as `{metric_name}: <number>` "
            f"or correct the metric name in the task document."
        )
    if result.was_percent:
        raise ValueError(
            f"Metric {metric_name!r} in {source} is printed as a percentage "
            f"({result.value}%). Print the raw value instead — the framework "
            "will not rescale it, and a 100x mismatch invalidates every delta."
        )
    value = float(result.value)
    # nan/inf parse cleanly but compare falsely: `nan > best` is always False, so
    # a diverged run would read as "did not improve" instead of as a failure.
    if not math.isfinite(value):
        raise ValueError(
            f"Metric {metric_name!r} in {source} is {value}, not a finite number. "
            "Treating this as a score would hide a diverged or crashed run."
        )
    return value


#: A float, in any form a print statement or a formatter is likely to emit.
_NUMBER_FOR_SCORE = r"-?[\d]+\.?[\d]*(?:[eE][+-]?\d+)?"

_SCORE_MARKER_RE = re.compile(
    rf"__SCORE__\s*[:=]\s*({_NUMBER_FOR_SCORE})", re.IGNORECASE,
)
_SCORE_KEYWORD_RE = re.compile(
    rf"(?:Final|CV|OOF|Val|Best|Mean).*?"
    rf"(?:score|auc|accuracy|f1|rmse|mae|loss|mse|r2|kappa|mcc)"
    rf"\s*[:=]\s*({_NUMBER_FOR_SCORE})",
    re.IGNORECASE,
)


def extract_score(stdout: str) -> float | None:
    """Extract the best score from experiment stdout output.

    Priority:
      1. __SCORE__ marker (explicit, always wins if present)
      2. Last keyword match in the log (Final/CV/OOF/Val/Best/Mean + metric name)
    """
    last_marker = None
    for m in _SCORE_MARKER_RE.finditer(stdout):
        try:
            last_marker = float(m.group(1))
        except ValueError:
            pass
    if last_marker is not None:
        return last_marker

    last_match = None
    for m in _SCORE_KEYWORD_RE.finditer(stdout):
        try:
            last_match = float(m.group(1))
        except ValueError:
            pass
    return last_match
