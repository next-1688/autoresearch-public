"""运行环境检测：GPU/CPU/内存/已安装 ML 包"""

from __future__ import annotations

import importlib
import os
import platform
import subprocess
from dataclasses import dataclass, field


@dataclass
class HardwareInfo:
    has_gpu: bool = False
    gpu_name: str = ""
    gpu_memory_mb: int = 0
    cpu_count: int = 1
    ram_gb: float = 0.0
    platform: str = ""
    installed_packages: list[str] = field(default_factory=list)
    missing_packages: list[str] = field(default_factory=list)

    @property
    def compute_tier(self) -> str:
        """返回计算能力等级：gpu_high / gpu_low / cpu_only"""
        if self.has_gpu and self.gpu_memory_mb >= 16000:
            return "gpu_high"
        if self.has_gpu:
            return "gpu_low"
        return "cpu_only"

    def to_constraint_str(self, gpu_sharers: int = 1) -> str:
        """生成硬件引导文本：正向引导模型选择 + 显存预算。

        ``gpu_sharers`` 是可能同时用这张卡的 agent 数（实验并发 + 诊断并发）。
        框架不再用锁把 GPU 串行化，所以这个数必须说出来：告诉 agent「你有整张
        卡」再让多个 agent 同时跑，是让它们各自算出一个必然 OOM 的 batch_size。
        它需要的不是许可，是当前空闲显存这个事实。
        """
        if self.compute_tier == "cpu_only":
            return (
                "HARDWARE CONSTRAINT: You are running on CPU only (no GPU available).\n"
                "- DO NOT use deep learning models (transformers, torch, tensorflow)\n"
                "- USE sklearn, lightgbm, xgboost, catboost instead\n"
                "- Keep model complexity low to fit within time budget\n"
                f"- {self.cpu_count} CPU cores available — use parallel training when the library supports it (e.g. n_jobs=-1, thread_count, etc.)"
            )
        sharing = self._sharing_str(gpu_sharers)
        if self.compute_tier == "gpu_low":
            return (
                f"HARDWARE: {self.gpu_name} ({self.gpu_memory_mb}MB VRAM — limited)\n"
                "- Small GPU available — use it but keep models small\n"
                f"- VRAM budget: {self.gpu_memory_mb}MB on the card.{sharing}\n"
                "- OK: DistilBERT, EfficientNet-B0, MobileNetV2, small CNNs\n"
                "- Risky: DeBERTa-base, ResNet-152, large models (may OOM)\n"
                "- Use the largest batch_size that fits in the memory actually free "
                "when you start.\n"
                "- Batch size reference (assumes the whole card; scale down when sharing):\n"
                "  * Image (small ≤64px): 64-128\n"
                "  * Image (medium 224px): 16-32\n"
                "  * Image (large 384px+): 4-8 with gradient accumulation\n"
                "  * Transformer/NLP: 4-8 with gradient accumulation\n"
                "- Always use mixed precision: `from torch.cuda.amp import GradScaler, autocast`. Do NOT use `torch.amp.GradScaler` — it may not exist.\n"
                "- Halve if OOM; if <30% of the memory you claimed is used during "
                "training, double batch_size"
            )
        return (
            f"HARDWARE: {self.gpu_name} ({self.gpu_memory_mb}MB VRAM)\n"
            "- You HAVE a powerful GPU — USE IT for deep learning (NLP, images)\n"
            f"- VRAM budget: {self.gpu_memory_mb}MB on the card.{sharing}\n"
            "- For neural networks: device = torch.device('cuda')\n"
            "- For mixed precision: `from torch.cuda.amp import GradScaler, autocast`. Do NOT use `torch.amp.GradScaler` — it may not exist.\n"
            "- For NLP tasks: PREFER transformer fine-tuning (DeBERTa/RoBERTa) over TF-IDF + sklearn\n"
            "- For image tasks: PREFER pretrained CNN fine-tuning (EfficientNet/ResNet)\n"
            "- For tabular data: LightGBM on CPU is fine, GPU is optional\n"
            "- **Use the memory that is free, all of it**: pick the largest batch_size "
            "that fits in the free memory you measured. Leaving it idle wastes "
            "compute; sizing to the card's total when a neighbour holds part of it "
            "just OOMs.\n"
            "- Batch size reference — these assume exclusive use of a card that size, "
            "so scale them by your share:\n"
            "  * Image (small ≤64px, e.g. CIFAR/MNIST): 256-512 on 16GB, 512-1024 on 80GB\n"
            "  * Image (medium 224px): 64-128 on 16GB, 128-256 on 80GB\n"
            "  * Image (large 384px+): 16-32 on 16GB, 64-128 on 80GB\n"
            "  * Transformer/NLP: 16-32 on 16GB, 32-64 on 80GB\n"
            "- Always use mixed precision (torch.cuda.amp.autocast) to effectively double batch capacity\n"
            "- Halve if OOM; if training uses <30% of the memory you claimed, double the batch_size\n"
            "- RUNTIME AWARENESS: larger models train proportionally slower. "
            "DeBERTa-large is ~3-4x slower than DeBERTa-base per epoch. "
            "Before switching to a larger model, estimate: (parent_runtime × scale_factor). "
            "If estimated time > 50% of timeout, keep the smaller model and tune hyperparameters instead."
        )

    @staticmethod
    def _sharing_str(gpu_sharers: int) -> str:
        """One sentence on who else may be on the card."""
        if gpu_sharers <= 1:
            return " You have it to yourself."
        return (
            f" Up to {gpu_sharers} agents share it, so the card total is NOT your "
            "budget: call torch.cuda.mem_get_info() (or read nvidia-smi) at the "
            "start of the run and size everything to the free number you get back. "
            "If a neighbour already holds most of the card, run something smaller "
            "or wait — do not shrink the model you were asked to test just to make "
            "it fit alongside."
        )

    def to_dict(self) -> dict:
        return {
            "has_gpu": self.has_gpu,
            "gpu_name": self.gpu_name,
            "gpu_memory_mb": self.gpu_memory_mb,
            "cpu_count": self.cpu_count,
            "ram_gb": self.ram_gb,
            "platform": self.platform,
            "compute_tier": self.compute_tier,
            "installed_packages": self.installed_packages,
            "missing_packages": self.missing_packages,
        }


_IMPORT_TO_DIST = {
    "sklearn": "scikit-learn",
    "cv2": "opencv-python",
    "PIL": "Pillow",
}


def _get_package_version(import_name: str) -> str:
    """Get installed version for a package by its import name."""
    from importlib.metadata import PackageNotFoundError, version
    dist_name = _IMPORT_TO_DIST.get(import_name, import_name)
    try:
        return version(dist_name)
    except PackageNotFoundError:
        try:
            return version(import_name)
        except PackageNotFoundError:
            return ""


_ML_PACKAGES = [
    "sklearn", "lightgbm", "xgboost", "catboost",
    "torch", "torchvision", "transformers", "timm",
    "tensorflow",
    "pandas", "numpy", "scipy",
    "nltk", "spacy", "optuna",
    "PIL", "cv2", "albumentations",
]


def _cgroup_memory_limit_gb() -> float | None:
    """Return this process's cgroup memory limit in GiB, or None if unlimited /
    unavailable. Reads cgroup v2 (memory.max) then v1 (memory.limit_in_bytes).
    A value of 'max' or an implausibly large sentinel (>= 1 PiB) means no limit."""
    _SENTINEL = 1 << 50  # 1 PiB; kernels use ~PAGE_COUNTER_MAX to mean "unlimited"
    for path in ("/sys/fs/cgroup/memory.max",
                 "/sys/fs/cgroup/memory/memory.limit_in_bytes"):
        try:
            raw = open(path).read().strip()
        except OSError:
            continue
        if raw == "max":
            return None
        try:
            val = int(raw)
        except ValueError:
            continue
        if val <= 0 or val >= _SENTINEL:
            return None
        return val / (1024 ** 3)
    return None


def detect_hardware() -> HardwareInfo:
    info = HardwareInfo()
    info.platform = platform.system().lower()
    info.cpu_count = os.cpu_count() or 1

    # RAM 检测
    try:
        import psutil
        info.ram_gb = psutil.virtual_memory().total / (1024 ** 3)
    except ImportError:
        if info.platform == "darwin":
            try:
                out = subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True)
                info.ram_gb = int(out.strip()) / (1024 ** 3)
            except Exception:
                pass
        elif info.platform == "linux":
            try:
                with open("/proc/meminfo") as f:
                    for line in f:
                        if line.startswith("MemTotal:"):
                            kb = int(line.split()[1])
                            info.ram_gb = kb / (1024 * 1024)
                            break
            except Exception:
                pass

    # Clamp to the container's cgroup memory limit if it is tighter than host
    # RAM. psutil/MemTotal report the HOST total, which over-states what this
    # process may actually use inside a k8s/Docker pod — telling the planner it
    # has more RAM than the cgroup allows invites OOM-kills.
    cgroup_gb = _cgroup_memory_limit_gb()
    if cgroup_gb and (info.ram_gb <= 0 or cgroup_gb < info.ram_gb):
        info.ram_gb = cgroup_gb

    # GPU 检测
    info.has_gpu = _detect_gpu(info)

    # 包检测（带版本号）
    for pkg in _ML_PACKAGES:
        try:
            importlib.import_module(pkg)
            version = _get_package_version(pkg)
            info.installed_packages.append(f"{pkg}=={version}" if version else pkg)
        except (ImportError, Exception):
            info.missing_packages.append(pkg)

    return info


def _detect_gpu(info: HardwareInfo) -> bool:
    # 方法1: torch.cuda
    try:
        import torch
        if torch.cuda.is_available():
            info.gpu_name = torch.cuda.get_device_name(0)
            info.gpu_memory_mb = torch.cuda.get_device_properties(0).total_memory // (1024 * 1024)
            return True
    except ImportError:
        pass

    # 方法2: nvidia-smi
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
            text=True, timeout=5,
        )
        parts = out.strip().split(",")
        if len(parts) >= 2:
            info.gpu_name = parts[0].strip()
            info.gpu_memory_mb = int(parts[1].strip())
            return True
    except (FileNotFoundError, subprocess.TimeoutExpired, Exception):
        pass

    return False


# =============================================================================
# Model Strategy & Environment Guide (task-aware prompt generation)
# =============================================================================
