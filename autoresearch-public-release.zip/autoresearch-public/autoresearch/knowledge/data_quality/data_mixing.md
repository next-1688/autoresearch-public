# Data Mixing

**Summary**: Mixes data from different sources/domains at optimized ratios to balance general and specialized capabilities.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: easy
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
SFT data typically includes multiple domains (general instructions, code, math, domain knowledge, etc.). Treating data mixing ratios as optimization variables allows finding optimal proportions through small-scale experiments or proxy tasks. In practice, high-quality domain data should be upsampled and general data downsampled.

## Usage
```python
from datasets import interleave_datasets, load_dataset

# Load different domain datasets
general = load_dataset("general_instruct", split="train")
code = load_dataset("code_instruct", split="train")
math = load_dataset("math_instruct", split="train")

# Mix by ratio
mixed = interleave_datasets(
    [general, code, math],
    probabilities=[0.5, 0.3, 0.2],  # mixing ratios
    stopping_strategy="all_exhausted"
)

# Or manual control:
import random

def mixed_sampler(datasets, weights, total_samples):
    samples = []
    for ds, w in zip(datasets, weights):
        n = int(total_samples * w)
        samples.extend(random.sample(list(ds), min(n, len(ds))))
    random.shuffle(samples)
    return samples
```

## Recommended Hyperparameters
- Start with small-scale experiments (e.g., 1% of data) to sweep different mixing ratios
- Common starting point: 50% general, 30% code, 20% math (adjust per use case)

## Notes
- First sweep mixing ratios on small scale, then train at full scale with the best ratio.
- High-quality domain-specific data benefits from upsampling.
- The `interleave_datasets` function from HuggingFace Datasets provides convenient mixing support.
