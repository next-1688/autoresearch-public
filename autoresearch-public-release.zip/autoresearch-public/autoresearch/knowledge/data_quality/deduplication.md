# Deduplication

**Summary**: Removes duplicate samples from training data to reduce overfitting and memorization, improving generalization.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer N/A | DeepSpeed N/A | Megatron N/A | Custom PyTorch N/A (preprocessing)

## Principle
Duplicate data causes the model to over-memorize specific patterns. Deduplication methods range from simple to sophisticated: exact hashing (MD5/SHA) -> fuzzy deduplication (MinHash LSH) -> semantic deduplication (embedding clustering). MinHash scales to trillion-scale datasets.

## Usage
```python
# Method 1: Exact deduplication (fastest)
from datasets import Dataset
dataset = dataset.map(lambda x: {"hash": hash(x["text"])})
dataset = dataset.filter(lambda x, idx: x["hash"] not in seen,
                         with_indices=True)

# Method 2: MinHash fuzzy deduplication (recommended)
pip install datasketch

from datasketch import MinHash, MinHashLSH

lsh = MinHashLSH(threshold=0.8, num_perm=128)

for idx, text in enumerate(texts):
    mh = MinHash(num_perm=128)
    for word in text.split():
        mh.update(word.encode('utf8'))
    # Query for near-duplicates
    if not lsh.query(mh):
        lsh.insert(str(idx), mh)
        # keep this sample

# Method 3: Semantic deduplication (most accurate, expensive)
from sentence_transformers import SentenceTransformer
from sklearn.cluster import DBSCAN

embedder = SentenceTransformer("all-MiniLM-L6-v2")
embeddings = embedder.encode(texts)
clusters = DBSCAN(eps=0.1, min_samples=2, metric="cosine").fit(embeddings)
# Keep only one sample per cluster

# NVIDIA NeMo Curator tool:
# pip install nemo-curator
# Provides industrial-grade deduplication pipeline
```

## Recommended Hyperparameters
- MinHash: threshold=0.8, num_perm=128
- Semantic: DBSCAN eps=0.1, metric="cosine"

## Notes
- MinHash LSH is the best balance between speed and quality for large datasets.
- Semantic deduplication is most accurate but computationally expensive.
- NVIDIA NeMo Curator provides production-ready deduplication pipelines.
- This is a preprocessing step applied before training begins.
