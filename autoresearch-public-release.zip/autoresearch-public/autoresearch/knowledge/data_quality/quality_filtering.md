# Quality Filtering

**Summary**: Filters out low-quality, toxic, PII-containing, or irrelevant training samples to improve SFT effectiveness.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer N/A | DeepSpeed N/A | Megatron N/A | Custom PyTorch N/A (preprocessing)

## Principle
"Less is More" -- a high-quality small dataset for SFT outperforms a low-quality large dataset. Quality filtering uses perplexity scoring, LLM-based scoring, and rule-based filtering (length/language/format) to select the best samples.

## Usage
```python
# Method 1: Perplexity-based quality scoring
from transformers import AutoModelForCausalLM, AutoTokenizer

scorer = AutoModelForCausalLM.from_pretrained("gpt2")
tokenizer = AutoTokenizer.from_pretrained("gpt2")

def compute_perplexity(text):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
    with torch.no_grad():
        loss = scorer(**inputs, labels=inputs["input_ids"]).loss
    return torch.exp(loss).item()

# Filter out samples with extremely high or low perplexity
filtered = [x for x in dataset
            if 10 < compute_perplexity(x["text"]) < 1000]

# Method 2: Cleanlab automated filtering
pip install cleanlab

from cleanlab import Datalab
lab = Datalab(data=dataset, label_name="label")
lab.find_issues()
clean_indices = lab.get_issues().query("is_issue == False").index

# Method 3: Rule-based filtering
def quality_filter(example):
    text = example["output"]
    if len(text) < 10: return False          # too short
    if len(text) > 10000: return False       # too long
    if text.count("\n") / len(text) > 0.3: return False  # format anomaly
    return True

dataset = dataset.filter(quality_filter)
```

## Recommended Hyperparameters
- Perplexity filter range: 10 to 1000 (adjust per dataset)
- Minimum text length: 10 characters
- Maximum text length: 10000 characters

## Notes
- High-quality small datasets consistently outperform low-quality large datasets for SFT.
- Combining multiple filtering methods (rules + perplexity + LLM scoring) yields best results.
- This is a preprocessing step applied before training begins.
