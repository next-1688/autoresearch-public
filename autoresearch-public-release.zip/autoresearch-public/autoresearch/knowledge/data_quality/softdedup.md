# SoftDedup (Soft Deduplication / Reweighting)

**Summary**: Instead of removing duplicates, reduces their training weight based on duplication degree, preserving information while reducing overfitting.
**Paper**: https://arxiv.org/abs/2407.06654
**Code**: N/A
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer N/A | DeepSpeed N/A | Megatron N/A | Custom PyTorch N/A (preprocessing)

## Principle
Completely removing near-duplicates may discard valuable variants. SoftDedup assigns different weights to each sample based on its duplication degree: the more duplicated, the lower the weight. This reduces the training steps needed to reach equivalent performance without sacrificing data diversity.

## Usage
```python
# Implementation: compute duplication degree via embedding similarity, convert to sample weights
from sentence_transformers import SentenceTransformer
from sklearn.neighbors import NearestNeighbors
import numpy as np

embedder = SentenceTransformer("all-MiniLM-L6-v2")
embeddings = embedder.encode(texts)

# Compute K-nearest neighbor similarity for each sample
nn = NearestNeighbors(n_neighbors=10, metric="cosine")
nn.fit(embeddings)
distances, _ = nn.kneighbors(embeddings)

# Higher similarity -> higher duplication -> lower weight
avg_similarity = 1 - distances.mean(axis=1)
weights = 1.0 / (1.0 + avg_similarity * 10)  # adjustable
weights = weights / weights.mean()  # normalize

# Use weighted loss during training:
# loss = (per_token_loss * sample_weight).mean()
```

## Recommended Hyperparameters
- K neighbors: 10
- Weight scaling factor: 10 (in the formula `1.0 / (1.0 + avg_similarity * factor)`)
- Normalize weights to have mean 1.0

## Notes
- Preserves data diversity better than hard deduplication.
- Reduces training steps needed to reach equivalent performance.
- Can be combined with hard deduplication for a two-stage approach.
- Requires computing pairwise similarities, which can be expensive for very large datasets.
