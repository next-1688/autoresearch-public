# DS2 (Data Selection via Submodular Optimization)

**Summary**: Selects a small core subset via submodular optimization; 3.3% of data can surpass a full 300K dataset.
**Paper**: https://arxiv.org/abs/2403.05894
**Code**: N/A
**Modification Complexity**: complex
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Data selection is modeled as a submodular function maximization problem, simultaneously optimizing data diversity and representativeness. A greedy algorithm selects a small but high-quality core subset from the large dataset. The ICLR 2025 paper demonstrates that a 3.3% curated subset outperforms full-data training.

## Usage
```python
# Implementation: embedding-based submodular selection
from sentence_transformers import SentenceTransformer
import numpy as np

embedder = SentenceTransformer("all-MiniLM-L6-v2")
embeddings = embedder.encode(texts)

def greedy_submodular_select(embeddings, k, lambda_div=1.0):
    """Greedily select k most representative and diverse samples"""
    n = len(embeddings)
    selected = []
    remaining = set(range(n))

    # Normalize
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    emb_norm = embeddings / (norms + 1e-8)

    for _ in range(k):
        best_idx, best_score = -1, -float('inf')
        for idx in remaining:
            # Representativeness: similarity to full set
            rep = emb_norm[idx] @ emb_norm.T
            rep_score = rep.mean()

            # Diversity: distance from already selected set
            if selected:
                sel_emb = emb_norm[selected]
                div_score = -rep[selected].max()  # far from selected samples
            else:
                div_score = 0

            score = rep_score + lambda_div * div_score
            if score > best_score:
                best_score = score
                best_idx = idx

        selected.append(best_idx)
        remaining.remove(best_idx)

    return selected

# Select 3-5% core subset
k = int(len(texts) * 0.05)
selected_indices = greedy_submodular_select(embeddings, k)
```

## Recommended Hyperparameters
- Selection ratio: 3-5% of full dataset
- lambda_div: 1.0 (balance between representativeness and diversity)

## Notes
- The greedy algorithm has O(n*k) complexity; consider approximate methods for very large datasets.
- Published at ICLR 2025.
- Particularly effective when the full dataset has significant redundancy.
- Can be combined with quality filtering for even better results.
