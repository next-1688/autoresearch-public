# FiNE (Filtering + Augmentation)

**Summary**: Combines quality filtering with LLM-based generative augmentation to surpass full-scale low-quality datasets using small high-quality subsets.
**Paper**: https://aclanthology.org/2025.naacl-long.437
**Code**: N/A
**Modification Complexity**: complex
**Framework Compatibility**: HF Trainer N/A | DeepSpeed N/A | Megatron N/A | Custom PyTorch N/A (preprocessing)

## Principle
First, a quality model filters out low-quality samples. Then, a strong LLM rewrites and augments the retained high-quality samples to generate more high-quality variants. Experiments show that the FiNE-processed small dataset surpasses the full original dataset on instruction-following tasks.

## Usage
```python
# Step 1: Quality filtering (using LLM scoring)
from openai import OpenAI
client = OpenAI()

def score_quality(instruction, response):
    result = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user",
                   "content": f"Rate 1-5 the quality:\nQ: {instruction}\nA: {response}"}]
    )
    return int(result.choices[0].message.content.strip())

# Keep samples scored >= 4
high_quality = [x for x in dataset if score_quality(x["q"], x["a"]) >= 4]

# Step 2: LLM augmentation (rewrite generation)
def augment(instruction, response):
    result = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user",
                   "content": f"Rewrite this response in a different style while keeping accuracy:\nQ: {instruction}\nA: {response}"}]
    )
    return result.choices[0].message.content

augmented = [{"q": x["q"], "a": augment(x["q"], x["a"])} for x in high_quality]
final_dataset = high_quality + augmented
```

## Recommended Hyperparameters
- Quality score threshold: >= 4 (on a 1-5 scale)
- Augmentation ratio: 1x (one rewrite per high-quality sample)

## Notes
- Requires API access to a strong LLM for both scoring and augmentation.
- API costs can be significant for large datasets; budget accordingly.
- The filtering step alone often provides substantial improvement.
- This is a preprocessing pipeline applied before training begins.
