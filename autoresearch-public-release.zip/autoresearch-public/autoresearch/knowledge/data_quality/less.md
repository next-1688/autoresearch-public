# LESS (Low-rank Estimation for Data Selection)

**Summary**: Uses influence functions to select the most valuable training subset from a large dataset; 5% of data can match full-data performance.
**Paper**: https://arxiv.org/abs/2402.04333
**Code**: https://github.com/princeton-nlp/LESS
**Modification Complexity**: complex
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Efficiently estimates each training sample's influence score on a target task validation set through low-rank approximation of the influence function. The highest-scoring samples are selected for training. Demonstrated at ICML 2024 that using only 5% of data achieves full-data training performance.

## Usage
```python
# LESS workflow:
# Step 1: Train on a small data subset to collect gradient features
# Step 2: Compute each candidate sample's influence score on the validation set
# Step 3: Select top-k samples for training

# Using LESS command line:
# 1. Collect gradients
python -m less.collect_grads \
    --model_path meta-llama/Llama-2-7b \
    --data_path train_data.jsonl \
    --output_dir grads/

# 2. Compute influence scores
python -m less.compute_scores \
    --grad_dir grads/ \
    --val_data_path val_data.jsonl \
    --output_path scores.json

# 3. Select top-k
python -m less.select_data \
    --scores_path scores.json \
    --train_data_path train_data.jsonl \
    --output_path selected_data.jsonl \
    --percentage 0.05  # select 5%
```

## Recommended Hyperparameters
- Selection percentage: 3-5% of the full dataset is usually sufficient
- On specific tasks, smaller subsets may even outperform full-data training

## Notes
- Requires a representative validation set for the target task.
- The gradient collection step can be computationally expensive.
- Particularly effective for task-specific fine-tuning where only relevant data matters.
- Published at ICML 2024.
