# Liger Kernel (LinkedIn GPU Efficient Runtime)

**Summary**: Replaces core operators in HuggingFace models with efficient Triton kernels, achieving +20% throughput and -60% memory.
**Paper**: N/A
**Code**: https://github.com/linkedin/Liger-Kernel
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Rewrites CrossEntropy, RMSNorm, SwiGLU, RoPE, and other operators using Triton, achieving operator fusion and memory optimization. No model code changes required -- a single-line patch applies to the model. Supports mainstream architectures including Llama, Mistral, Qwen, and Gemma.

## Usage
```python
pip install liger-kernel

# Method 1: One-line patch (recommended)
from liger_kernel.transformers import apply_liger_kernel_to_llama
apply_liger_kernel_to_llama()  # call before loading model

# Other models:
from liger_kernel.transformers import (
    apply_liger_kernel_to_mistral,
    apply_liger_kernel_to_qwen2,
    apply_liger_kernel_to_gemma,
)

# Method 2: Use individual kernels
from liger_kernel.transformers import LigerFusedLinearCrossEntropyLoss
loss_fn = LigerFusedLinearCrossEntropyLoss()

# Method 3: HuggingFace Trainer integration
training_args = TrainingArguments(
    use_liger_kernel=True,  # HF Trainer has built-in integration
    # ... other args
)
```

## Recommended Hyperparameters
- No hyperparameters to tune; just enable the kernel patch.

## Notes
- Throughput improvement of ~20% and training memory reduction of ~60%.
- Fully compatible with existing training code.
- Must call the patch function before loading the model.
- Supports Llama, Mistral, Qwen, Gemma and more architectures.
