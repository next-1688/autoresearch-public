# Gradient Clipping

**Summary**: Limits the maximum gradient norm to prevent gradient explosion and training instability.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✓ | Custom PyTorch ✓

## Principle
When the L2 norm of gradients exceeds a threshold, all gradients are proportionally scaled down. This is the standard practice in LLM training to prevent loss spikes and training collapse.

## Usage
```python
# HuggingFace Trainer:
training_args = TrainingArguments(
    max_grad_norm=1.0,  # default is already 1.0
)

# Manual implementation:
torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
optimizer.step()
```

## Recommended Hyperparameters
- max_norm=1.0 (standard value for LLM training)

## Notes
- This is a standard practice enabled by default in most training frameworks.
- HuggingFace Trainer uses max_grad_norm=1.0 by default.
- Essential for preventing training divergence, especially with mixed precision training.
