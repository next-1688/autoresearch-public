# EMA (Exponential Moving Average)

**Summary**: Maintains an exponential moving average of model parameters, smoothing training fluctuations and improving generalization.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
A shadow model is maintained whose parameters are the exponential moving average of the training model: theta_ema = decay * theta_ema + (1-decay) * theta. The EMA model is used for evaluation and inference. It is more stable and often achieves better generalization performance.

## Usage
```python
# Manual implementation
import copy

class EMAModel:
    def __init__(self, model, decay=0.9999):
        self.ema_model = copy.deepcopy(model)
        self.decay = decay
        for p in self.ema_model.parameters():
            p.requires_grad = False

    @torch.no_grad()
    def update(self, model):
        for ema_p, model_p in zip(self.ema_model.parameters(),
                                   model.parameters()):
            ema_p.data.mul_(self.decay).add_(model_p.data, alpha=1-self.decay)

# Usage:
ema = EMAModel(model, decay=0.9999)
for batch in dataloader:
    loss = model(**batch).loss
    loss.backward()
    optimizer.step()
    ema.update(model)  # update EMA every step

# Use ema.ema_model for evaluation

# MosaicML Composer built-in support:
from composer.algorithms import EMA
ema_algo = EMA(half_life="50ba")  # 50 batch half-life
```

## Recommended Hyperparameters
- decay=0.9999 (slow update, stable)
- decay=0.999 (faster tracking)

## Notes
- Doubles memory usage since a full copy of the model is maintained.
- Use the EMA model for evaluation and final inference, not the training model.
- MosaicML Composer provides built-in EMA support.
