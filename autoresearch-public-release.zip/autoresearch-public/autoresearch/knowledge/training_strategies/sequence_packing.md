# Sequence Packing

**Summary**: Packs multiple short sequences into one long sequence to eliminate padding waste and improve GPU utilization.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: easy
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
SFT data has highly variable lengths; fixed-length training wastes compute on padding tokens. Packing concatenates multiple samples into a single max_seq_len sequence, using special attention masks to isolate different samples. Combined with Flash Attention's variable-length attention, this enables efficient training with minimal wasted computation.

## Usage
```python
# Method 1: TRL SFTTrainer built-in support
from trl import SFTTrainer, SFTConfig

training_args = SFTConfig(
    packing=True,          # enable packing
    max_seq_length=2048,
    # ... other args
)

# Method 2: NeMo framework
# In config file:
# model.data.train_ds.packed_sequence: True
# model.data.train_ds.pack_size: 4096

# Note: After enabling packing, reduce global_batch_size accordingly
# new batch_size ≈ original batch_size / avg sequences per pack
```

## Recommended Hyperparameters
- max_seq_length: 2048 or 4096 depending on model and data distribution
- Adjust batch_size inversely proportional to the average number of sequences per pack

## Notes
- Requires proper attention mask implementation to prevent cross-sample attention leakage.
- Can significantly speed up training (2-5x) when data has many short sequences.
- Works best with Flash Attention for variable-length attention support.
