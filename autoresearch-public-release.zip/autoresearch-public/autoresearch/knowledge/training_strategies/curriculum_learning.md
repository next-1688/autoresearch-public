# Curriculum Learning

**Summary**: Orders training data from easy to hard, improving convergence speed and final performance.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Inspired by human learning, the model first trains on simple samples and gradually introduces complex ones. Difficulty metrics can be based on sequence length, perplexity, instruction complexity (Bloom's taxonomy), or model loss. This can improve convergence speed and final performance, though effectiveness varies across models and tasks.

## Usage
```python
# Manual implementation of loss-based curriculum learning
from torch.utils.data import Sampler
import numpy as np

class CurriculumSampler(Sampler):
    def __init__(self, difficulties, num_epochs, epoch=0):
        """
        difficulties: difficulty score per sample (e.g., perplexity)
        """
        self.difficulties = np.array(difficulties)
        self.num_epochs = num_epochs
        self.epoch = epoch

    def __iter__(self):
        # Gradually introduce harder samples as training progresses
        progress = self.epoch / self.num_epochs  # 0 -> 1
        threshold = np.percentile(self.difficulties,
                                   min(100, 30 + 70 * progress))
        valid_indices = np.where(self.difficulties <= threshold)[0]
        np.random.shuffle(valid_indices)
        return iter(valid_indices.tolist())

    def __len__(self):
        return len(self.difficulties)

# Simple method: sort by sequence length
sorted_dataset = dataset.sort("length")  # short to long
```

## Recommended Hyperparameters
- Start with top 30% easiest samples, linearly increase to 100% over training
- Difficulty metric: perplexity or sequence length are simplest to implement

## Notes
- Effects can be unstable; validate on small scale before large-scale deployment.
- Simple length-based sorting is the easiest approach and often works well.
- More sophisticated difficulty metrics (e.g., model loss) may require a preliminary scoring pass.
