# Gradient Accumulation

**Summary**: Accumulates gradients over multiple mini-batches before updating parameters, effectively increasing batch size.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✓ | Custom PyTorch ✓

## Principle
When GPU memory is insufficient for the desired batch size, multiple forward and backward passes accumulate gradients before executing a single parameter update. The effective batch_size = micro_batch x accumulation_steps x num_gpus.

## Usage
```python
# HuggingFace Trainer:
training_args = TrainingArguments(
    per_device_train_batch_size=4,
    gradient_accumulation_steps=8,
    # effective batch_size = 4 * 8 = 32 (single GPU)
)

# Manual implementation:
accumulation_steps = 8
optimizer.zero_grad()
for i, batch in enumerate(dataloader):
    loss = model(**batch).loss
    loss = loss / accumulation_steps  # normalize
    loss.backward()

    if (i + 1) % accumulation_steps == 0:
        optimizer.step()
        optimizer.zero_grad()
```

## Recommended Hyperparameters
- Set accumulation_steps so that effective batch_size reaches 32~256.
- effective batch_size = per_device_batch_size x accumulation_steps x num_gpus

## Notes
- Remember to normalize the loss by accumulation_steps in manual implementations.
- Larger effective batch sizes generally improve training stability.
- No additional memory overhead beyond the base micro-batch.
