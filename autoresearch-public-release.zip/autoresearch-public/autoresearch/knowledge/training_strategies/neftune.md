# NEFTune (Noisy Embedding Fine-Tuning)

**Summary**: Adds uniform noise to embeddings during training, dramatically improving generation quality (AlpacaEval 29% to 64%).
**Paper**: https://arxiv.org/abs/2310.05914
**Code**: https://github.com/neelsjain/NEFTune
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✓ | Custom PyTorch ✓

## Principle
During forward propagation, scaled uniform noise is added to token embedding vectors: embed += alpha/sqrt(L*d) * U(-1,1), where L is sequence length, d is embedding dimension, and alpha is noise intensity. This acts as a form of data augmentation that improves model generation diversity and quality.

## Usage
```python
# Method 1: HuggingFace TRL native support
from trl import SFTTrainer, SFTConfig

training_args = SFTConfig(
    neftune_noise_alpha=5.0,  # just add this line!
    # ... other args
)
trainer = SFTTrainer(model=model, args=training_args, ...)

# Method 2: Manual implementation
def neftune_forward_hook(module, input, output):
    if module.training:
        dims = torch.tensor(output.size(1) * output.size(2))
        mag_norm = module.neftune_noise_alpha / torch.sqrt(dims)
        output = output + torch.zeros_like(output).uniform_(-mag_norm, mag_norm)
    return output

model.model.embed_tokens.neftune_noise_alpha = 5.0
model.model.embed_tokens.register_forward_hook(neftune_forward_hook)
```

## Recommended Hyperparameters
- alpha=5 (Alpaca/Evol-Instruct)
- alpha=10 (ShareGPT)
- alpha=15 (OpenPlatypus)

## Notes
- Extremely easy to integrate with one-line config change in TRL.
- The noise is only applied during training; inference is unaffected.
- Works with any model architecture that has a standard embedding layer.
