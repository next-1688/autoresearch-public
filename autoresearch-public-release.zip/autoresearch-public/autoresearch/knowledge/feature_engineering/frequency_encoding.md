# Frequency / Count Encoding

**Summary**: Replace categorical values with their occurrence frequency as a numerical feature
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: trivial
**Library Compatibility**: sklearn ✓ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
Map each categorical level to how often it appears in the dataset. This converts high-cardinality
categoricals into a single numerical column that preserves ordinal information about category
popularity. Unlike target encoding, frequency encoding uses no target information and therefore
carries zero leakage risk. Variations include raw count, normalized frequency (count / total),
and log-frequency (log1p of count) to handle skewed distributions.

## Usage
```python
import pandas as pd
import numpy as np

# Raw count encoding
def frequency_encode(train, test, col):
    freq_map = train[col].value_counts().to_dict()
    train[f'{col}_freq'] = train[col].map(freq_map)
    test[f'{col}_freq'] = test[col].map(freq_map).fillna(0)
    return train, test

# Normalized frequency encoding
def normalized_freq_encode(train, test, col):
    freq_map = train[col].value_counts(normalize=True).to_dict()
    train[f'{col}_nfreq'] = train[col].map(freq_map)
    test[f'{col}_nfreq'] = test[col].map(freq_map).fillna(0)
    return train, test

# Log-frequency (handles skew in count distribution)
def log_freq_encode(train, test, col):
    freq_map = train[col].value_counts().to_dict()
    train[f'{col}_logfreq'] = train[col].map(freq_map).apply(np.log1p)
    test[f'{col}_logfreq'] = test[col].map(freq_map).fillna(0).apply(np.log1p)
    return train, test

# Apply to multiple columns
for col in high_card_cols:
    train, test = frequency_encode(train, test, col)
```

## Recommended Hyperparameters
- No tunable parameters for basic frequency encoding
- Choose variant based on count distribution skew: use log-frequency when max_count / median_count > 100
- Consider combining with target encoding for complementary signals

## When to Use
- High-cardinality categoricals (100+ levels) where one-hot is infeasible
- Tree-based models (frequency provides natural split points)
- As a complement to target encoding (frequency captures popularity, TE captures target signal)
- When a leak-free categorical encoding is needed (no target information used)

## When NOT to Use
- Category frequency has no predictive relationship with the target
- Very few categories (<10) -- one-hot or ordinal encoding is clearer
- Linear models where frequency magnitude is not meaningful without further transformation

## Notes
- Frequency encoding is deterministic and does not require CV-based computation.
- Unseen categories in the test set should map to 0 (or a small epsilon).
- Often the single strongest leak-free encoding for high-cardinality categoricals in tree models.
- Pair with target encoding: frequency captures structural importance, TE captures target signal.
