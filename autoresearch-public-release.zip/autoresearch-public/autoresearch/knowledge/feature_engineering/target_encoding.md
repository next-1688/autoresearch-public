# Bayesian Target Encoding with Prior Smoothing

**Summary**: Encode high-cardinality categoricals using smoothed target statistics with CV-based leakage prevention
**Paper**: https://dl.acm.org/doi/10.1145/507533.507538
**Code**: https://github.com/scikit-learn-contrib/category_encoders
**Modification Complexity**: moderate
**Library Compatibility**: sklearn ✓ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
Replace each categorical level with a smoothed estimate of the target mean for that level.
Formula: `TE(cat) = (count * mean_target + prior * global_mean) / (count + prior)`
The prior (smoothing) parameter regularizes rare categories toward the global mean, preventing
overfitting on low-count levels. CV-based encoding (encode fold N using folds != N) is essential
to prevent target leakage during training.

## Usage
```python
import category_encoders as ce
from sklearn.model_selection import KFold

# Option 1: category_encoders (fit separately within each training fold)
encoder = ce.TargetEncoder(cols=cat_cols, smoothing=30)
X_encoded = encoder.fit_transform(X_train, y_train)

# Option 2: Manual Bayesian TE with CV (recommended for control)
def bayesian_te_cv(X, y, col, n_splits=5, prior=30):
    te = pd.Series(index=X.index, dtype=float)
    global_mean = y.mean()
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    for tr_idx, val_idx in kf.split(X):
        stats = y.iloc[tr_idx].groupby(X[col].iloc[tr_idx]).agg(['mean', 'count'])
        mapping = (stats['count'] * stats['mean'] + prior * global_mean) / (stats['count'] + prior)
        te.iloc[val_idx] = X[col].iloc[val_idx].map(mapping).fillna(global_mean)
    return te

# Use the out-of-fold encoding as a feature; fit a full-training mapping
# separately for inference and validate with the task's evaluation metric.
```

## Recommended Hyperparameters
- `smoothing` / `prior`: 10-100 (higher = more regularization; start at 30)
- `n_splits` for CV encoding: 5-10

## When to Use
- High-cardinality categorical features (100+ levels, e.g., entity_id, group_id)
- When one-hot encoding is infeasible due to dimensionality

## When NOT to Use
- Very few categories (<10) -- one-hot or ordinal encoding suffices
- Target variable has extreme noise -- TE will encode noise
- Categories with too few observations to estimate a stable target statistic

## Notes
- CatBoost has built-in ordered target encoding; consider it before manual TE.
- Always compute TE on the training folds only; apply the learned mapping to test data.
