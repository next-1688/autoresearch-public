# Feature Selection for Tabular Models

**Summary**: Identify and retain only predictive features using model-agnostic importance and elimination methods
**Paper**: https://www.jmlr.org/papers/v11/kursa10a.html (Boruta)
**Code**: https://github.com/scikit-learn-contrib/boruta_py
**Modification Complexity**: moderate
**Library Compatibility**: sklearn ✓ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
Remove irrelevant and redundant features to reduce overfitting, improve training speed, and
increase interpretability. Key methods:
- **Permutation importance**: shuffle a feature, measure prediction degradation (model-agnostic)
- **Boruta**: compare each feature's importance against the max importance of randomly shuffled
  shadow copies; features consistently beating shadows are confirmed relevant
- **Null importance**: train on shuffled target to establish a noise baseline; real features must
  exceed this threshold
- **RFECV**: recursively remove least important features, validated by cross-validation score
- **VIF**: detect multicollinearity (VIF > 10 suggests redundancy)

## Usage
```python
from sklearn.inspection import permutation_importance
from sklearn.ensemble import RandomForestClassifier
from boruta import BorutaPy
import numpy as np

# Permutation importance (use held-out test set to avoid bias)
model = RandomForestClassifier(n_estimators=200, random_state=42)
model.fit(X_train, y_train)
perm_imp = permutation_importance(model, X_test, y_test, n_repeats=10, random_state=42)
important_mask = perm_imp.importances_mean > 0.001
selected_features = X_test.columns[important_mask]

# Boruta (wrapper around RF importance with shadow features)
rf = RandomForestClassifier(n_estimators=200, max_depth=7, random_state=42, n_jobs=-1)
boruta = BorutaPy(rf, n_estimators='auto', max_iter=100, random_state=42)
boruta.fit(X_train.values, y_train.values)
selected = X_train.columns[boruta.support_].tolist()
tentative = X_train.columns[boruta.support_weak_].tolist()

# Null importance (noise baseline)
def null_importance(model_cls, X, y, n_runs=50):
    real_imp = model_cls().fit(X, y).feature_importances_
    null_imps = np.zeros((n_runs, X.shape[1]))
    for i in range(n_runs):
        y_shuffled = np.random.permutation(y)
        null_imps[i] = model_cls().fit(X, y_shuffled).feature_importances_
    threshold = np.percentile(null_imps, 95, axis=0)
    return real_imp > threshold
```

## Recommended Hyperparameters
- Permutation importance: `n_repeats=10-30`, threshold at mean > 0 or > 0.001
- Boruta: `max_iter=100-200`, `max_depth=5-7` for the internal RF
- Null importance: `n_runs=50-100`, threshold at 95th percentile of null distribution
- RFECV: `step=1` for precision, `step=0.1` (10% per round) for speed on large feature sets
- VIF threshold: drop features with VIF > 10 (strong multicollinearity)

## When to Use
- Many features (>30) where some may be irrelevant or redundant
- After interaction/aggregation feature generation to prune the expanded feature set
- Post-modeling validation: confirm that selected features genuinely contribute
- Debugging overfitting: identify features that hurt generalization

## When NOT to Use
- Few features (<10) where all are known relevant from domain expertise
- Very large datasets where repeated model fitting (Boruta, null importance) is prohibitively slow
- Features are already curated and validated through domain knowledge

## Notes
- Always compute permutation importance on a held-out set, not the training set.
- Boruta is conservative; tentative features (`support_weak_`) often deserve inclusion.
- Null importance is the most robust method but also the most compute-intensive.
- Combine methods: use permutation importance for quick screening, Boruta for confirmation.
- For tree ensembles, built-in feature importance (gain/split) is biased toward high-cardinality
  features; prefer permutation importance for unbiased assessment.
