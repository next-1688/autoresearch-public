# Group-Level Aggregation Features

**Summary**: Compute statistical aggregations over hierarchical groups to capture relational patterns
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: moderate
**Library Compatibility**: sklearn ✓ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
For data with natural group structure (e.g., devices, stations, categories), compute group-level
statistics and merge them back as row-level features. This surfaces distributional patterns
(mean, std, count, nunique) that individual rows cannot express. Temporal variants include
rolling means, time-since-last, and trend slopes. These features are especially powerful in
relational/hierarchical datasets where rows share group membership.

## Usage
```python
import pandas as pd

# Basic group aggregation
def add_agg_features(df, group_col, agg_col, aggs=['mean', 'std', 'count', 'min', 'max']):
    agg_df = df.groupby(group_col)[agg_col].agg(aggs)
    agg_df.columns = [f'{group_col}_{agg_col}_{a}' for a in aggs]
    return df.merge(agg_df, on=group_col, how='left')

# Multi-group aggregation
group_cols = ['station_id', 'category_id']
agg_col = 'measurement'
for gc in group_cols:
    df = add_agg_features(df, gc, agg_col)

# Nunique: count distinct values within group
df['station_nunique_sensors'] = df.groupby('station_id')['sensor_id'].transform('nunique')

# Temporal aggregation (rolling)
df = df.sort_values(['entity_id', 'date'])
df['rolling_7d_mean'] = df.groupby('entity_id')['target'].transform(
    lambda x: x.rolling(7, min_periods=1).mean()
)
df['time_since_last'] = df.groupby('entity_id')['date'].diff().dt.days
```

## Recommended Hyperparameters
- Aggregation statistics: start with mean, std, count; add nunique, median, skew if beneficial
- Rolling window sizes: 7, 14, 30 for daily data; adjust to domain periodicity
- Always use `min_periods=1` for rolling to handle edge cases at group boundaries

## When to Use
- Relational data with natural group structure (station-sensor, category hierarchies)
- Temporal patterns requiring rolling or cumulative statistics
- Low-to-medium cardinality grouping keys where aggregations are statistically stable

## When NOT to Use
- Groups with too few observations to estimate stable statistics
- No natural grouping exists in the data (aggregations would be meaningless)

## Notes
- Leakage risk: when aggregating target-related columns, use CV-based computation (same
  principle as target encoding) to avoid encoding the current row's target into its own feature.
- For test data, compute aggregations from training data only and map via merge.
- Combine count aggregations with frequency encoding for complementary signals.
