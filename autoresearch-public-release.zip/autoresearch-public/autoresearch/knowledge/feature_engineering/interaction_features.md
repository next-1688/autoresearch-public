# Interaction Feature Engineering

**Summary**: Generate cross-feature interactions (products, ratios, polynomials) to capture combined signals
**Paper**: N/A
**Code**: https://github.com/alteryx/featuretools
**Modification Complexity**: moderate
**Library Compatibility**: sklearn ✓ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
Create new features from combinations of existing ones to explicitly surface interactions that
models might not learn efficiently. Types include arithmetic (A*B, A/B, A-B, A+B), polynomial
(A^2, A*B), and ratio features (A / (B + eps)). Because interaction generation is combinatorial,
aggressive feature selection after generation is critical to avoid the curse of dimensionality.

## Usage
```python
from sklearn.preprocessing import PolynomialFeatures
from sklearn.feature_selection import mutual_info_classif
import numpy as np
import pandas as pd

# Option 1: sklearn PolynomialFeatures (degree-2 interactions)
poly = PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)
X_inter = poly.fit_transform(X_train[numeric_cols])
feature_names = poly.get_feature_names_out(numeric_cols)

# Option 2: Manual ratio features (domain-guided)
def make_ratio_features(df, pairs, eps=1e-8):
    for a, b in pairs:
        df[f'{a}_div_{b}'] = df[a] / (df[b] + eps)
        df[f'{a}_mul_{b}'] = df[a] * df[b]
    return df

ratio_pairs = [('distance', 'duration'), ('mass', 'volume')]
X_train = make_ratio_features(X_train, ratio_pairs)

# Feature selection after generation: keep only informative interactions
mi_scores = mutual_info_classif(X_inter, y_train, random_state=42)
top_k = np.argsort(mi_scores)[-20:]  # keep top 20 interactions
X_inter_selected = X_inter[:, top_k]
```

## Recommended Hyperparameters
- `degree`: 2 (degree 3+ rarely helps and explodes feature count)
- `interaction_only`: True (skip pure polynomial terms unless domain-justified)
- Post-generation selection: keep top 10-30 by mutual information or permutation importance
- For ratios: always add epsilon (1e-8) to denominators to avoid division by zero

## When to Use
- Suspected feature interactions not captured by tree splits at current depth
- Moderate feature count (<50 base features) to keep combinatorial growth manageable
- Linear/logistic models that cannot learn interactions natively
- Domain knowledge suggests specific meaningful ratios (e.g., mass/volume, area/perimeter)

## When NOT to Use
- Already many features (>100) -- combinatorial explosion worsens curse of dimensionality
- Tree models with sufficient depth (>=6) that can learn interactions via sequential splits

## Notes
- featuretools automates deep feature synthesis for relational datasets but generates massive
  feature sets -- always follow with aggressive selection.
- Ratio features are often more interpretable and effective than blind polynomial expansion.
- When using interactions in ensembles, test the full pipeline (individual + ensemble) to catch
  cases where per-model gains vanish or reverse at the ensemble level.
