# Training Optimization Techniques Index

Index of technique cards by applicable scenario. Read the linked file for principle, code, and hyperparameters.

## 1. Optimizers

| Method | Summary | Applicable Scenarios | File |
|--------|---------|---------------------|------|
| AdamW | Decoupled weight decay Adam, standard baseline | Default choice for most training | optimizers/adamw.md |
| LION | Sign-momentum optimizer, ~1/3 less memory than Adam | Memory constrained, large batch | optimizers/lion.md |
| Sophia | Second-order optimizer, ~50% fewer steps to converge | Long training runs, large batch | optimizers/sophia.md |
| Muon | Momentum + Newton-Schulz orthogonalization for hidden weights | Experimental, promising on small models | optimizers/muon.md |
| SOAP | Second-order approximate preconditioner | Balance of first and second-order methods | optimizers/soap.md |
| Schedule-Free | No LR schedule needed, continuous improvement | Simplify hyperparameter search | optimizers/schedule_free.md |
| AdEMAMix | Dual EMA mixing (slow + fast momentum) | Anti-forgetting, long training | optimizers/ademamix.md |
| Grokfast | Gradient frequency filter for faster generalization | Delayed generalization (grokking) | optimizers/grokfast.md |
| Adam-mini | Partitioned Adam with ~50% less optimizer memory | Very large models, memory pressure | optimizers/adam_mini.md |
| SPAM | Spike-aware Adam with momentum reset | Training instability, loss spikes | optimizers/spam.md |
| Spectrum | SNR-based layer selection, train only top 25-50% layers | Selective layer training, efficiency | optimizers/spectrum.md |

## 2. Parameter-Efficient Fine-Tuning (PEFT)

| Method | Summary | Applicable Scenarios | File |
|--------|---------|---------------------|------|
| LoRA | Low-rank adaptation matrices, no inference latency | Standard PEFT baseline | peft/lora.md |
| QLoRA | 4-bit quantized base model + LoRA adapter | Single GPU, low memory (24GB for 7B) | peft/qlora.md |
| DoRA | Weight-decomposed LoRA (magnitude + direction) | Better than LoRA at same rank | peft/dora.md |
| LoRA+ | Different learning rates for A and B matrices | Improve LoRA convergence speed | peft/lora_plus.md |
| PiSSA | SVD-initialized LoRA adapter | Better initialization, faster convergence | peft/pissa.md |
| rsLoRA | Rank-stabilized scaling (α/√r instead of α/r) | High-rank LoRA (r > 64) | peft/rslora.md |
| AdaLoRA | Adaptive rank allocation per layer by importance | Automatic rank budget allocation | peft/adalora.md |
| VeRA | Shared random matrices + per-layer scaling vectors | Ultra-low parameter count | peft/vera.md |
| OLoRA | QR-based orthonormal initialization for LoRA | Faster convergence, training stability | peft/olora.md |
| LoRA-FA | Freeze A matrix, train only B, reduce activation memory | Reduce trainable params by half | peft/lora_fa.md |
| GaLore | Gradient low-rank projection, full-param quality | Full-param quality with LoRA-level memory | peft/galore.md |
| LISA | Random layerwise importance sampling | LoRA memory but full-param performance | peft/lisa.md |

## 3. Training Strategies

| Method | Summary | Applicable Scenarios | File |
|--------|---------|---------------------|------|
| NEFTune | Add uniform noise to embeddings during training | Almost always beneficial for instruction tuning | training_strategies/neftune.md |
| Sequence Packing | Pack multiple short samples into one sequence | Variable-length data, GPU utilization | training_strategies/sequence_packing.md |
| Curriculum Learning | Order training data easy→hard | Large diverse datasets | training_strategies/curriculum_learning.md |
| Liger Kernel | Fused Triton kernels for transformers | +20% throughput, -60% memory | training_strategies/liger_kernel.md |
| Gradient Accumulation | Accumulate gradients across mini-batches | Simulate larger batch with limited GPU | training_strategies/gradient_accumulation.md |
| Gradient Clipping | Cap gradient norm to prevent explosions | Training stability (standard practice) | training_strategies/gradient_clipping.md |
| EMA | Exponential moving average of model weights | Smoother convergence, better generalization | training_strategies/ema.md |

## 4. Data Quality & Selection

| Method | Summary | Applicable Scenarios | File |
|--------|---------|---------------------|------|
| Deduplication | Remove exact/near-duplicate samples | Always, preprocessing step | data_quality/deduplication.md |
| Quality Filtering | Score-based sample filtering | Noisy or web-crawled data | data_quality/quality_filtering.md |
| SoftDedup | Soft de-weighting of near-duplicates | Alternative to hard dedup | data_quality/softdedup.md |
| Data Mixing | Multi-source data ratio optimization | Multi-task/multi-domain training | data_quality/data_mixing.md |
| FiNE | Filtering + LLM-based augmentation | Small high-quality dataset creation | data_quality/fine.md |
| LESS | Low-rank data selection via influence functions | Task-specific data selection, 5% data | data_quality/less.md |
| DS2 | Submodular optimization for data selection | Optimal subset selection, 3.3% data | data_quality/ds2.md |

## 5. Learning Rate Scheduling

| Method | Summary | Applicable Scenarios | File |
|--------|---------|---------------------|------|
| Cosine Annealing | Cosine-shaped LR decay from peak to near zero | Default for most training | lr_scheduling/cosine.md |
| WSD | Warmup-Stable-Decay three-phase schedule | Flexible, unknown total steps | lr_scheduling/wsd.md |
| Linear Decay | Linear warmup + linear/polynomial decay | Simple alternative to cosine | lr_scheduling/linear.md |
| Constant + Warmup | Constant LR after warmup | Short fine-tuning, LoRA | lr_scheduling/constant.md |

## 6. Loss Functions & Regularization

| Method | Summary | Applicable Scenarios | File |
|--------|---------|---------------------|------|
| Label Smoothing | Soften one-hot labels to probability distribution | Overconfident predictions, calibration | loss_regularization/label_smoothing.md |
| R-Drop | KL divergence between two dropout-masked forward passes | Small datasets, overfitting | loss_regularization/r_drop.md |
| Token Weighting | Selective loss masking per token | Instruction tuning, noisy labels | loss_regularization/token_weighting.md |
| Model Merging | SLERP/TIES/DARE post-training weight merge | Combine multiple fine-tuned checkpoints | loss_regularization/model_merging.md |
| KL Regularization | KL divergence from reference model | Anti-forgetting, catastrophic forgetting | loss_regularization/kl_regularization.md |

## 7. Gradient Boosting & Tree Models

| Method | Summary | Applicable Scenarios | File |
|--------|---------|---------------------|------|
| XGBoost | Gradient boosted trees with L1/L2 regularization and GPU support | Tabular data regression/classification/ranking, structured features | tabular_ml/xgboost.md |
| LightGBM | Fast GBDT with GOSS/EFB, leaf-wise growth, native categorical support | Large tabular datasets, categorical features, speed-critical | tabular_ml/lightgbm.md |
| CatBoost | Ordered boosting with automatic categorical feature handling | Many categorical features, small-medium datasets, minimal tuning | tabular_ml/catboost.md |
| Hyperparameter Optimization | Optuna TPE/CMA-ES with pruning and multi-objective | GBDT default params not tuned, significant improvement room | tabular_ml/hyperparameter_optimization.md |
| Imbalanced Targets | Zero-inflated/imbalanced target handling: sampling, weighting, focal loss, hurdle | Zero-inflated targets (>70% zeros), class imbalance >10:1, ranking on imbalanced data | tabular_ml/imbalanced_targets.md |
| Custom Objectives | Custom GBDT loss functions: quantile, Tweedie, zero-inflated Poisson, focal | Standard loss doesn't match eval metric, domain-specific optimization | tabular_ml/custom_objectives.md |

## 8. Ensemble Methods

| Method | Summary | Applicable Scenarios | File |
|--------|---------|---------------------|------|
| Stacking | Multi-layer stacking with K-fold OOF predictions and meta-learner | Multiple diverse base models, enough data for K-fold | ensemble_methods/stacking.md |
| Blending | Weighted averaging with Nelder-Mead/Optuna weight optimization | Quick ensemble of 2-5 models, guaranteed improvement over best single | ensemble_methods/blending.md |
| Rank Averaging | Percentile rank normalization then averaging, scale-invariant | Ranking metrics, heterogeneous model types, different prediction scales | ensemble_methods/rank_averaging.md |
| Model Diversity | Error correlation analysis and diversity-driven model selection | Large model pool, need optimal subset, ensemble degradation diagnosis | ensemble_methods/model_diversity.md |

## 9. Feature Engineering

| Method | Summary | Applicable Scenarios | File |
|--------|---------|---------------------|------|
| Target Encoding | Bayesian smoothed target encoding with CV leak prevention | High-cardinality categoricals, post-hoc score adjustment, multiplicative blend | feature_engineering/target_encoding.md |
| Frequency Encoding | Category frequency/count as feature, replacing one-hot | High-cardinality categoricals (100+ levels), tree models | feature_engineering/frequency_encoding.md |
| Interaction Features | Automated arithmetic/polynomial interaction generation with selection | Suspected feature interactions, moderate feature count (<50) | feature_engineering/interaction_features.md |
| Aggregation Features | Group-level statistics (mean/std/count) for hierarchical data | Relational data with group structure, temporal patterns | feature_engineering/aggregation_features.md |
| Feature Selection | Permutation importance, Boruta, null importance, RFECV, VIF | Many features (>30), suspect irrelevant/redundant features | feature_engineering/feature_selection.md |

## 10. Ranking & Reranking

| Method | Summary | Applicable Scenarios | File |
|--------|---------|---------------------|------|
| LambdaRank | LambdaRank/LambdaMART for NDCG-optimized learning-to-rank | Explicit ranking tasks, NDCG/MAP metric, grouped items | ranking_methods/lambdarank.md |
| Pairwise Ranking | BPR/RankNet/margin-based pairwise ranking losses | Simpler ranking, binary relevance, pairwise ordering | ranking_methods/pairwise_ranking.md |

## 11. Deep Tabular Models

| Method | Summary | Applicable Scenarios | File |
|--------|---------|---------------------|------|
| TabNet | Attentive feature selection with sparsemax, interpretable | Medium-large tabular (>10K rows), interpretability needed | deep_tabular/tabnet.md |
| FT-Transformer | Feature tokenization + Transformer encoder for tabular | Medium-large datasets (>50K), mixed numerical/categorical | deep_tabular/ft_transformer.md |
| NODE | Neural Oblivious Decision Ensembles, differentiable trees | Neural flexibility with tree inductive bias, medium datasets | deep_tabular/node.md |
| DCN v2 | Deep & Cross Network with explicit feature crossing layers | Many feature interactions, medium-large data | deep_tabular/dcn_v2.md |
| Deep Ensemble | Multi-seed, Snapshot Ensemble, SWA for tabular DL | Deep tabular models, uncertainty estimation, variance reduction | deep_tabular/deep_ensemble.md |
