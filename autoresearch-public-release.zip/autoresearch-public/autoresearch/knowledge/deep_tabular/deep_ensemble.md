# Deep Ensemble Methods for Tabular Models

**Summary**: Variance reduction and uncertainty estimation via multi-seed, snapshot, or SWA ensembling
**Paper**: https://arxiv.org/abs/1612.01474
**Code**: N/A (built into PyTorch: torch.optim.swa_utils)
**Modification Complexity**: moderate
**Library Compatibility**: pytorch ✓ | sklearn ✓

## Principle

Ensembling exploits sensitivity to initialization and training noise:
1. **Multi-seed**: same architecture, K different seeds, average outputs
2. **Snapshot Ensemble**: cyclic LR, save at each cycle minimum, ensemble checkpoints
3. **SWA**: average model weights over training trajectory, single-model ensemble approximation

All reduce variance. Multi-seed also provides uncertainty via prediction disagreement.

## Usage
```python
import torch
from torch.optim.swa_utils import AveragedModel, SWALR
base_model = MyTabularModel(input_dim=50, hidden_dim=256)
optimizer = torch.optim.Adam(base_model.parameters(), lr=1e-3)
swa_model = AveragedModel(base_model)
swa_scheduler = SWALR(optimizer, swa_lr=5e-4, anneal_epochs=5)
# Normal training phase
for epoch in range(50):
    train_one_epoch(base_model, optimizer, train_loader)
# SWA phase: average weights
for epoch in range(50, 100):
    train_one_epoch(base_model, optimizer, train_loader)
    swa_model.update_parameters(base_model)
    swa_scheduler.step()
torch.optim.swa_utils.update_bn(train_loader, swa_model)  # update BN stats
```

## Recommended Hyperparameters

- **Multi-seed**: 3-5 seeds (diminishing returns beyond 5)
- **Snapshot**: 3-5 cosine annealing cycles, T_0 = total_epochs / n_cycles
- **SWA**: start at 50-75% of training, swa_lr = 0.5 * initial_lr

## When to Use

- Deep tabular models (TabNet, FT-Transformer, NODE) as base learners
- Want uncertainty estimates (multi-seed disagreement as proxy)
- Need variance reduction without changing architecture

## When NOT to Use

- Single strong model is sufficient
- Compute budget limited (multi-seed multiplies cost by K)
- GBDT models (use model-level stacking/blending instead)

## Notes

- SWA is most compute-efficient: single model cost, ensemble-like performance
- Snapshot is a good middle ground: one training run, multiple models
- Always update batch norm statistics after SWA weight averaging
- Combine neural + GBDT ensembles for maximum diversity
