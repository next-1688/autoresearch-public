# FT-Transformer

**Summary**: Feature Tokenizer + Transformer that converts each tabular feature into a token for self-attention
**Paper**: https://arxiv.org/abs/2106.11959
**Code**: https://github.com/yandex-research/rtdl
**Modification Complexity**: complex
**Library Compatibility**: pytorch ✓

## Principle

Each feature (numerical or categorical) is projected into a d-dimensional token embedding.
A [CLS] token is prepended and the sequence is processed by a Transformer encoder, enabling
all-pairs feature interactions. Often matches or exceeds GBDT on medium-large datasets.

## Usage
```python
import torch, torch.nn as nn
class FTTransformer(nn.Module):
    def __init__(self, n_num, cat_cards, d=192, n_blocks=3, n_heads=8, drop=0.1):
        super().__init__()
        self.num_emb = nn.Linear(1, d)
        self.cat_embs = nn.ModuleList([nn.Embedding(c, d) for c in cat_cards])
        self.cls = nn.Parameter(torch.randn(1, 1, d))
        enc = nn.TransformerEncoderLayer(d, n_heads, d*4, drop, "gelu", batch_first=True)
        self.tf = nn.TransformerEncoder(enc, n_blocks)
        self.head = nn.Linear(d, 1)
    def forward(self, x_num, x_cat):
        num_tok = self.num_emb(x_num.unsqueeze(-1))
        cat_tok = torch.stack([e(x_cat[:, i]) for i, e in enumerate(self.cat_embs)], 1)
        tokens = torch.cat([self.cls.expand(x_num.size(0), -1, -1), num_tok, cat_tok], 1)
        return self.head(self.tf(tokens)[:, 0])
```

## Recommended Hyperparameters

- `d_token`: 64-256 (192 default) | `n_blocks`: 2-4 | `n_heads`: 8
- `dropout`: 0.1-0.2 | `lr`: 1e-4 with AdamW, weight_decay=1e-5
- Batch size: 256-1024 | Warmup: 5-10% of total steps

## When to Use

- Medium-to-large datasets (>50K preferred, >10K minimum)
- Mix of numerical and categorical features with complex interactions
- GBDT plateau: boosted trees have saturated

## When NOT to Use

- Small datasets (<10K rows): overfits easily
- Need fast training/inference: Transformer overhead is significant
- Interpretability required: attention weights are unreliable for importance

## Notes

- Per-feature tokenization is key: shared linear layers perform much worse
- Pre-layer normalization (GPT-2 style) is more stable than post-layer norm
- Can be combined with GBDT in ensembles for best results
- Consider using the rtdl library for a well-tested implementation
