# NODE: Neural Oblivious Decision Ensembles

**Summary**: Differentiable ensemble of oblivious decision trees trained end-to-end with backpropagation
**Paper**: https://arxiv.org/abs/1909.06312
**Code**: https://github.com/Qwicen/node
**Modification Complexity**: complex
**Library Compatibility**: pytorch ✓

## Principle

NODE replaces traditional trees with differentiable oblivious decision trees (ODTs). An
oblivious tree uses the same split feature/threshold at each depth level, yielding 2^depth
leaves. Soft entmax/softmax comparisons make it differentiable. An ensemble of many ODTs
is trained jointly via backprop, bridging tree and neural approaches.

## Usage
```python
import torch, torch.nn as nn
class NODELayer(nn.Module):
    def __init__(self, in_f, num_trees=1024, depth=6, tree_dim=1):
        super().__init__()
        self.feat_sel = nn.Parameter(torch.randn(num_trees, depth, in_f))
        self.thresholds = nn.Parameter(torch.randn(num_trees, depth))
        self.leaves = nn.Parameter(torch.randn(num_trees, 2**depth, tree_dim))
        self.depth = depth
    def forward(self, x):
        w = torch.softmax(self.feat_sel, -1)        # (T, D, F)
        chosen = torch.einsum("tdf,bf->btd", w, x)  # (B, T, D)
        c = torch.sigmoid(chosen - self.thresholds)  # (B, T, D)
        probs = c.new_ones(c.shape[0], c.shape[1], 1)
        for d in range(self.depth):
            s = c[:, :, d:d+1]
            probs = torch.cat([probs * s, probs * (1 - s)], -1)
        return (probs.unsqueeze(-1) * self.leaves).sum(2).mean(1)
```

## Recommended Hyperparameters

- `num_trees`: 512-2048 (1024 default) | `depth`: 4-8 (6 typical)
- `tree_dim`: 1-3 | `lr`: 1e-3 with cosine annealing
- Batch size: 512-2048 | Use entmax (alpha=1.5) for sparser feature selection

## When to Use

- Want neural flexibility with tree-like inductive bias
- Medium datasets (10K-500K rows)
- Ensembling with GBDT: NODE captures complementary patterns

## When NOT to Use

- Very small datasets (<5K): ODTs overfit, GBDT is safer
- Need fast inference: 1024 PyTorch trees is slower than LightGBM
- GBDT already near-optimal: NODE rarely beats well-tuned XGBoost by much

## Notes

- Use entmax (sparse softmax) for crisper feature selection than softmax
- Training is GPU-intensive; use mixed precision (fp16)
- NODE can be a layer within a larger architecture (e.g., stacked with MLPs)
- Regularize via dropout on leaf responses and weight decay
