# DCN v2: Deep & Cross Network v2

**Summary**: Explicit bounded-degree feature crossing layers combined with a deep DNN
**Paper**: https://arxiv.org/abs/2008.13535
**Code**: https://github.com/tensorflow/recommenders
**Modification Complexity**: complex
**Library Compatibility**: pytorch ✓ | tensorflow ✓

## Principle

Cross layers compute x_{l+1} = x_0 * (W_l * x_l + b_l) + x_l, producing bounded-degree
polynomial interactions at linear cost. V2 replaces rank-1 weights with full matrices.
Cross and deep streams run in parallel and concatenate for final prediction.

## Usage
```python
import torch, torch.nn as nn
class CrossLayer(nn.Module):
    def __init__(self, d):
        super().__init__()
        self.W = nn.Linear(d, d, bias=True)
    def forward(self, x0, xl):
        return x0 * self.W(xl) + xl

class DCNv2(nn.Module):
    def __init__(self, d_in, n_cross=3, deep=[512, 256, 128], drop=0.1):
        super().__init__()
        self.crosses = nn.ModuleList([CrossLayer(d_in) for _ in range(n_cross)])
        layers = []
        prev = d_in
        for dim in deep:
            layers += [nn.Linear(prev, dim), nn.ReLU(), nn.Dropout(drop)]
            prev = dim
        self.deep = nn.Sequential(*layers)
        self.head = nn.Linear(d_in + deep[-1], 1)
    def forward(self, x):
        xc = x
        for cl in self.crosses:
            xc = cl(x, xc)
        return self.head(torch.cat([xc, self.deep(x)], 1))
```

## Recommended Hyperparameters

- `num_cross_layers`: 2-4 (3 typical) | `deep_dims`: [512, 256, 128]
- `dropout`: 0.1-0.3 | `lr`: 1e-3 to 1e-4 with AdamW
- Batch size: 512-4096 | Low-rank cross for >1K features (rank=64-256)

## When to Use

- Many feature interactions suspected
- Medium-to-large datasets with dense or mixed features

## When NOT to Use

- Few features (<10): not enough interactions to justify cross layers
- Simple tasks with minimal feature interactions
- Small datasets (<5K rows) | Interpretability needed

## Notes

- Parallel architecture (cross || deep -> concat) typically outperforms stacked
- Low-rank: replace W with U*V^T to reduce parameters
- Embedding layer for categoricals is critical; share between cross and deep
