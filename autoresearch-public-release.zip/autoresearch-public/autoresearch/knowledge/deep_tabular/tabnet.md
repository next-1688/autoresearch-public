# TabNet

**Summary**: Attentive interpretable tabular learning with sequential sparse feature selection
**Paper**: https://arxiv.org/abs/1908.07442
**Code**: https://github.com/dreamquark-ai/tabnet
**Modification Complexity**: moderate
**Library Compatibility**: pytorch ✓ | pytorch-tabnet ✓

## Principle

TabNet processes tabular data through sequential decision steps, each applying a learned
sparse attention mask (via Sparsemax) to select a subset of features. Feature reuse is
controlled by gamma. Self-supervised pre-training on masked features boosts performance
on limited labeled data.

## Usage
```python
from pytorch_tabnet.tab_model import TabNetRegressor
model = TabNetRegressor(
    n_d=64, n_a=64, n_steps=5, gamma=1.5, lambda_sparse=1e-4,
    optimizer_fn=torch.optim.Adam, optimizer_params=dict(lr=2e-2),
    scheduler_fn=torch.optim.lr_scheduler.StepLR,
    scheduler_params={"step_size": 50, "gamma": 0.9},
    mask_type="sparsemax",
)
model.fit(X_train, y_train, eval_set=[(X_val, y_val)],
          eval_metric=["rmse"], max_epochs=200, patience=20, batch_size=1024)
```

## Recommended Hyperparameters

- `n_d`, `n_a`: 8-64 (equal values; 64 for larger datasets)
- `n_steps`: 3-10 (5 default) | `gamma`: 1.0-2.0
- `lambda_sparse`: 1e-4 to 1e-3 | `batch_size`: 256-4096
- `lr`: 0.01-0.025 with step or cosine decay

## When to Use

- Medium-to-large tabular datasets (>10K rows)
- Feature-level interpretability desired (attention masks per sample)
- Unlabeled data available for self-supervised pre-training

## When NOT to Use

- Very small datasets (<5K rows): prone to overfitting, GBDT more robust
- Already strong GBDT baseline with no room to improve
- Latency-sensitive inference: sequential attention adds overhead

## Notes

- Pre-training: `model.pretrain(X_unlabeled)` before `fit()` for semi-supervised gains
- Handles categorical features via `cat_idxs` and `cat_dims` parameters
- GPU training recommended for datasets >50K rows
- Sparse attention makes the model naturally robust to irrelevant features
