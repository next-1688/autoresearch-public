# QLoRA (Quantized LoRA)

**Summary**: Train LoRA adapters on a 4-bit quantized frozen base model, enabling fine-tuning of 7B models on a single 24GB GPU.
**Paper**: https://arxiv.org/abs/2305.14314
**Code**: N/A
**Modification Complexity**: easy
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✗ | Custom PyTorch ✓

## Principle
The base model is quantized to NF4 (4-bit NormalFloat), with double quantization and paged optimizers to further reduce memory. During backpropagation, gradients are computed by dequantizing from 4-bit, and only the LoRA adapter parameters are updated.

## Usage
```python
pip install bitsandbytes peft transformers

from transformers import AutoModelForCausalLM, BitsAndBytesConfig

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16,
    bnb_4bit_use_double_quant=True  # double quantization
)

model = AutoModelForCausalLM.from_pretrained(
    "model_name", quantization_config=bnb_config
)

# Then configure LoRA adapter as usual
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
model = prepare_model_for_kbit_training(model)
model = get_peft_model(model, lora_config)
```

## Recommended Hyperparameters
Key settings: `load_in_4bit=True` + `bnb_4bit_quant_type="nf4"` + `bnb_4bit_use_double_quant=True`. LoRA hyperparameters same as standard LoRA.

## Notes
- Requires the `bitsandbytes` library, which has best support on NVIDIA GPUs.
- `prepare_model_for_kbit_training` handles gradient checkpointing and layer norm casting for quantized models.
- Inference can be done either in 4-bit or by merging and dequantizing the adapter.
