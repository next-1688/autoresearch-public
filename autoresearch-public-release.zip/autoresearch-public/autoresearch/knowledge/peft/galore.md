# GaLore (Gradient Low-Rank Projection)

**Summary**: Apply low-rank projection to gradients, achieving full-parameter learning with memory overhead close to LoRA.
**Paper**: https://arxiv.org/abs/2403.03507
**Code**: https://github.com/jiaweizzhao/GaLore
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Instead of decomposing weights into low-rank form, GaLore projects gradients into a low-rank space and uses the projected gradients to update optimizer states. The projection matrix is periodically recomputed via SVD. This allows full-parameter updates while reducing optimizer state memory by up to 65%.

## Usage
```python
pip install galore-torch

from galore_torch import GaLoreAdamW, GaLoreAdamW8bit

# Separate layers that need GaLore
galore_params = [p for n, p in model.named_parameters()
                 if "mlp" in n or "self_attn" in n]
regular_params = [p for n, p in model.named_parameters()
                  if "mlp" not in n and "self_attn" not in n]

optimizer = GaLoreAdamW(
    [{"params": regular_params},
     {"params": galore_params, "rank": 128,
      "update_proj_gap": 200, "scale": 0.25}],
    lr=1e-5
)

# Or in HuggingFace Trainer:
training_args = TrainingArguments(
    optim="galore_adamw",
    optim_target_modules=["attn", "mlp"],
)
```

## Recommended Hyperparameters
rank=128, update_proj_gap=200, scale=0.25

## Notes
- GaLore updates all parameters (not just adapters), so it can potentially match full fine-tuning quality.
- The periodic SVD recomputation adds some overhead; `update_proj_gap` controls this tradeoff.
- Requires the `galore-torch` package or HuggingFace Trainer's built-in `galore_adamw` optimizer.
- Custom optimizer parameter groups are needed to separate GaLore and regular parameters.
