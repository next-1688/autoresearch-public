# LoRA+ (Differentiated Learning Rates)

**Summary**: Use different learning rates for LoRA's A and B matrices, with a larger lr for B, improving convergence speed.
**Paper**: https://arxiv.org/abs/2402.12354
**Code**: N/A
**Modification Complexity**: easy
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Standard LoRA uses the same learning rate for both A and B, but theoretical analysis shows that B (the matrix projecting back to the original space) should use a larger learning rate. LoRA+ sets lr_B = ratio x lr_A, typically with ratio=16.

## Usage
```python
# HuggingFace PEFT support
from peft import LoraConfig, get_peft_model

lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    task_type="CAUSAL_LM"
)
model = get_peft_model(model, lora_config)

# Manually set different lr for param groups:
lora_A_params = [p for n, p in model.named_parameters() if "lora_A" in n]
lora_B_params = [p for n, p in model.named_parameters() if "lora_B" in n]

optimizer = torch.optim.AdamW([
    {"params": lora_A_params, "lr": 1e-5},
    {"params": lora_B_params, "lr": 1e-5 * 16},  # ratio=16
])

# Or in LLaMA-Factory: loraplus_lr_ratio: 16.0
```

## Recommended Hyperparameters
lr_ratio = 16 (B's lr is 16x that of A)

## Notes
- Requires custom optimizer parameter groups, not directly supported by standard Trainer without modification.
- LLaMA-Factory has built-in support via `loraplus_lr_ratio` config.
- The optimal ratio may vary by model and task; 16 is a good default.
