# rsLoRA (Rank-Stabilized LoRA)

**Summary**: Replace the scaling factor alpha/r with alpha/sqrt(r), stabilizing training for high-rank adapters.
**Paper**: https://arxiv.org/abs/2312.03732
**Code**: N/A
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
The standard LoRA scaling factor alpha/r causes gradients to become too small at high ranks, limiting the effectiveness of large-rank adapters. rsLoRA changes the scaling factor to alpha/sqrt(r), keeping gradient magnitudes consistent across different ranks and allowing higher ranks to achieve better performance.

## Usage
```python
from peft import LoraConfig, get_peft_model

lora_config = LoraConfig(
    r=64,              # can safely use larger ranks
    lora_alpha=64,
    target_modules=["q_proj", "v_proj", "k_proj", "o_proj"],
    use_rslora=True,   # enable rsLoRA scaling
    task_type="CAUSAL_LM"
)

model = get_peft_model(model, lora_config)
```

## Recommended Hyperparameters
Use with high rank (r=64~256), `use_rslora=True`

## Notes
- Most beneficial when using large ranks (r >= 64); for small ranks the difference is negligible.
- A trivial one-flag change to any existing LoRA config.
- Allows exploring higher-rank adapters without gradient instability.
