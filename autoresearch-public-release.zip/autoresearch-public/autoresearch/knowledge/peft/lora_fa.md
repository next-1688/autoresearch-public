# LoRA-FA (Frozen-A)

**Summary**: Freeze the A matrix after random initialization (no updates), training only the B matrix, drastically reducing activation memory.
**Paper**: https://arxiv.org/abs/2308.03303
**Code**: N/A
**Modification Complexity**: easy
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Standard LoRA needs to store A's input activations for backpropagation. LoRA-FA freezes A after random initialization and only trains B. Since A is frozen, its full-rank input activations do not need to be stored, resulting in a significant reduction in activation memory with minimal performance loss.

## Usage
```python
# Manual implementation (PEFT does not have built-in support yet)
from peft import LoraConfig, get_peft_model

lora_config = LoraConfig(
    r=16, lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    task_type="CAUSAL_LM"
)
model = get_peft_model(model, lora_config)

# Freeze all lora_A parameters before training
for name, param in model.named_parameters():
    if "lora_A" in name:
        param.requires_grad = False
```

## Recommended Hyperparameters
Same as standard LoRA; simply freeze lora_A parameters after model setup.

## Notes
- Implementation is straightforward: standard LoRA config followed by freezing A.
- Activation memory savings are most significant for long sequences and large batch sizes.
- Performance degradation is typically minimal compared to standard LoRA.
