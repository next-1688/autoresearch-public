# LoRA (Low-Rank Adaptation)

**Summary**: Freeze pretrained weights and inject trainable low-rank matrices, reducing parameters by 10,000x with no inference latency.
**Paper**: https://arxiv.org/abs/2106.09685
**Code**: https://github.com/huggingface/peft
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✓ | Custom PyTorch ✓

## Principle
The update ΔW to weight matrix W is decomposed into the product of two low-rank matrices A×B (rank r << d). Only A and B are trained during fine-tuning, and at inference time they can be merged back into the original weights, adding no latency.

## Usage
```python
pip install peft

from peft import LoraConfig, get_peft_model

lora_config = LoraConfig(
    r=16,                        # rank, common: 8, 16, 32, 64
    lora_alpha=32,               # scaling factor, typically = 2*r
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                     "gate_proj", "up_proj", "down_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)

model = get_peft_model(model, lora_config)
model.print_trainable_parameters()
# Output: trainable params: ~0.1% of total
```

## Recommended Hyperparameters
r=16, lora_alpha=32, dropout=0.05, target=all linear layers

## Notes
- LoRA is the most widely adopted PEFT method and is supported by virtually all training frameworks.
- Increasing rank improves capacity but also increases trainable parameters; r=16 is a good default for most tasks.
- Applying LoRA to all linear layers (not just attention) generally yields better results.
