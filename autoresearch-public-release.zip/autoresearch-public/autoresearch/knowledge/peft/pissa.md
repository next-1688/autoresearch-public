# PiSSA (SVD Initialization)

**Summary**: Initialize LoRA adapters using SVD decomposition of original weights, accelerating convergence, especially effective in quantized scenarios.
**Paper**: https://arxiv.org/abs/2404.02948
**Code**: N/A
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
In standard LoRA, A is randomly initialized and B is zero-initialized, causing an initial zero-gradient problem. PiSSA performs SVD on the original weight W and uses the principal components to initialize the adapter (A=sqrt(S)*V^T, B=U*sqrt(S)), with the residual as the frozen weight. This allows the adapter to capture the most important weight information from the start.

## Usage
```python
# HuggingFace PEFT support
from peft import LoraConfig, get_peft_model

lora_config = LoraConfig(
    r=16,
    lora_alpha=16,    # PiSSA recommends alpha=r
    target_modules=["q_proj", "v_proj", "k_proj", "o_proj"],
    init_lora_weights="pissa",     # key parameter!
    # init_lora_weights="pissa_niter_4",  # fast approximate SVD
    task_type="CAUSAL_LM"
)

model = get_peft_model(model, lora_config)

# QPiSSA (combined with QLoRA):
# init_lora_weights="pissa" + load_in_4bit=True
```

## Recommended Hyperparameters
init_lora_weights="pissa", lora_alpha=r

## Notes
- There is a one-time SVD overhead during initialization; use `pissa_niter_4` to speed it up with approximate SVD.
- QPiSSA combines PiSSA initialization with QLoRA quantization for maximum memory efficiency.
- Setting lora_alpha equal to r (rather than 2*r) is recommended for PiSSA.
