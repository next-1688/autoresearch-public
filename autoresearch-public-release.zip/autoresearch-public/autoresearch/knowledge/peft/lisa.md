# LISA (Layerwise Importance Sampled AdamW)

**Summary**: Randomly freeze most intermediate layers and only update sampled layers, achieving memory usage comparable to LoRA but performance close to full-parameter fine-tuning.
**Paper**: https://arxiv.org/abs/2403.17919
**Code**: https://github.com/OptimalScale/LMFlow
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
It was observed that weight norm changes across layers during LoRA fine-tuning follow a highly skewed distribution. Based on this, LISA randomly samples a small number of layers (e.g., 2) to unfreeze and train at each step, keeping all other layers frozen. The embedding layer and LM head are always unfrozen. LISA surpasses LoRA on 70B models.

## Usage
```python
# Manual implementation of LISA strategy
import random

def lisa_step(model, num_active_layers=2, total_layers=32):
    # Freeze all layers
    for param in model.parameters():
        param.requires_grad = False

    # Always unfreeze embedding and lm_head
    for param in model.model.embed_tokens.parameters():
        param.requires_grad = True
    for param in model.lm_head.parameters():
        param.requires_grad = True

    # Randomly sample num_active_layers layers to unfreeze
    active = random.sample(range(total_layers), num_active_layers)
    for idx in active:
        for param in model.model.layers[idx].parameters():
            param.requires_grad = True

# Call at each training step (or every K steps):
lisa_step(model, num_active_layers=2)

# LLaMA-Factory: use_lisa: true, lisa_activated_layers: 2
```

## Recommended Hyperparameters
num_active_layers=2 (for 7B models), =4 (for 70B models), resample every step or every K steps

## Notes
- LISA does not require any adapter modules; it operates directly on the base model weights.
- The random layer sampling introduces stochasticity that acts as regularization.
- LLaMA-Factory has built-in support via `use_lisa` and `lisa_activated_layers` config options.
- Memory usage depends on the number of active layers; 2 active layers gives memory comparable to LoRA.
