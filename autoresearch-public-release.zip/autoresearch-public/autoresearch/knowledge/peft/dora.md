# DoRA (Weight-Decomposed Low-Rank Adaptation)

**Summary**: Decompose weights into magnitude and direction, with LoRA updating only the direction component, achieving better performance than standard LoRA.
**Paper**: https://arxiv.org/abs/2402.09353
**Code**: https://github.com/NVlabs/DoRA
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✗ | Custom PyTorch ✓

## Principle
Inspired by Weight Normalization, DoRA decomposes pretrained weight W into magnitude m and direction V/||V||. During fine-tuning, LoRA updates the directional component while simultaneously learning a magnitude scaling vector. This makes the update pattern closer to full-parameter fine-tuning.

## Usage
```python
# HuggingFace PEFT has built-in support
from peft import LoraConfig, get_peft_model

lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj", "k_proj", "o_proj",
                     "gate_proj", "up_proj", "down_proj"],
    use_dora=True,  # just add this one line!
    task_type="CAUSAL_LM"
)

model = get_peft_model(model, lora_config)
```

## Recommended Hyperparameters
Same as LoRA, plus `use_dora=True`.

## Notes
- Training is slightly slower than standard LoRA (~10%), but performance consistently surpasses LoRA.
- DoRA is a drop-in replacement: simply add `use_dora=True` to any existing LoRA config.
