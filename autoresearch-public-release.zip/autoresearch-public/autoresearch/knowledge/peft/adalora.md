# AdaLoRA (Adaptive LoRA)

**Summary**: Adaptively allocate rank budget across different layers based on weight importance scores.
**Paper**: https://arxiv.org/abs/2303.10512
**Code**: https://github.com/QingruZhang/AdaLoRA
**Modification Complexity**: easy
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Different layers have varying importance for a given task. AdaLoRA parameterizes adapters using SVD and dynamically adjusts each layer's rank through importance scoring, allocating more parameter budget to important layers and pruning redundant ranks from less important ones.

## Usage
```python
from peft import AdaLoraConfig, get_peft_model

adalora_config = AdaLoraConfig(
    init_r=12,            # initial rank
    target_r=8,           # target average rank
    beta1=0.85,
    beta2=0.85,
    tinit=200,            # warmup steps before pruning starts
    tfinal=1000,          # step at which pruning stops
    deltaT=10,            # pruning interval (every N steps)
    lora_alpha=32,
    lora_dropout=0.1,
    target_modules=["q_proj", "v_proj"],
    task_type="CAUSAL_LM"
)

model = get_peft_model(model, adalora_config)
```

## Recommended Hyperparameters
init_r=12, target_r=8, tinit=200, tfinal=1000

## Notes
- AdaLoRA requires careful tuning of pruning schedule parameters (tinit, tfinal, deltaT).
- The SVD parameterization adds slight overhead compared to standard LoRA.
- Best suited for scenarios where parameter budget is tight and layer-wise importance varies significantly.
