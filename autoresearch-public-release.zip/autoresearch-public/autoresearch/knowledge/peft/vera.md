# VeRA (Vector-based Random Matrix Adaptation)

**Summary**: All layers share a single pair of frozen random matrices, learning only per-layer scaling vectors, resulting in extremely small parameter count.
**Paper**: https://arxiv.org/abs/2310.11454
**Code**: N/A
**Modification Complexity**: easy
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
VeRA replaces the per-layer independent A and B matrices in LoRA with globally shared frozen random matrices. Each layer only learns two diagonal scaling vectors d and b. This reduces parameter count by 10-100x compared to LoRA while achieving comparable performance.

## Usage
```python
from peft import VeraConfig, get_peft_model

vera_config = VeraConfig(
    r=256,                 # VeRA's r can be set large (shared matrices add no extra params)
    target_modules=["q_proj", "v_proj", "k_proj", "o_proj"],
    projection_prng_key=42,  # random seed to ensure shared matrix consistency
    task_type="CAUSAL_LM"
)

model = get_peft_model(model, vera_config)
model.print_trainable_parameters()
# Trainable parameters far fewer than LoRA
```

## Recommended Hyperparameters
r=256 (can be set large), projection_prng_key with a fixed seed

## Notes
- Since matrices are shared across layers, using a large rank does not significantly increase parameter count.
- The fixed random seed (`projection_prng_key`) must be consistent for reproducibility and adapter loading.
- Best for extremely parameter-constrained scenarios where LoRA's parameter count is still too large.
