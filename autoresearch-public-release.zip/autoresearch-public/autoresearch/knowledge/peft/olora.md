# OLoRA (Orthonormal LoRA)

**Summary**: Use QR decomposition for orthonormal initialization of LoRA matrices, accelerating convergence.
**Paper**: https://arxiv.org/abs/2406.01775
**Code**: N/A
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
OLoRA applies QR decomposition to orthonormally initialize the A matrix of LoRA, ensuring that initial directions are diverse and mutually orthogonal. This reduces redundant updates during early training, accelerates convergence, and often improves final performance.

## Usage
```python
from peft import LoraConfig, get_peft_model

lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj", "k_proj", "o_proj"],
    init_lora_weights="olora",   # OLoRA orthonormal initialization
    task_type="CAUSAL_LM"
)

model = get_peft_model(model, lora_config)
```

## Recommended Hyperparameters
`init_lora_weights="olora"`, all other settings same as standard LoRA

## Notes
- A trivial one-flag change to any existing LoRA config.
- The QR decomposition initialization has negligible overhead.
- Particularly beneficial for tasks where standard random initialization leads to slow early convergence.
