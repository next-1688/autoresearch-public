# R-Drop (Regularized Dropout)

**Summary**: Constrains output distributions from two forward passes (with different dropout masks) to be consistent via KL divergence, improving generalization.
**Paper**: https://arxiv.org/abs/2106.14448
**Code**: N/A
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
The same input passes through the model twice (with different outputs due to dropout randomness), and bidirectional KL divergence penalizes the difference between the two outputs. This forces the model to be robust to dropout variations, effectively increasing regularization strength. Shown effective on 18 datasets across translation, summarization, and understanding tasks.

## Usage
```python
import torch.nn.functional as F

def r_drop_loss(logits1, logits2, labels, alpha=5.0):
    """
    logits1, logits2: outputs from two forward passes of the same input
    labels: ground truth labels
    alpha: KL divergence weight
    """
    # Standard CE loss
    ce_loss = 0.5 * (F.cross_entropy(logits1, labels) +
                      F.cross_entropy(logits2, labels))

    # KL divergence regularization
    p = F.log_softmax(logits1, dim=-1)
    q = F.log_softmax(logits2, dim=-1)
    kl_loss = 0.5 * (F.kl_div(p, q.exp(), reduction='batchmean') +
                      F.kl_div(q, p.exp(), reduction='batchmean'))

    return ce_loss + alpha * kl_loss

# Training loop:
for batch in dataloader:
    logits1 = model(**batch).logits  # first forward pass
    logits2 = model(**batch).logits  # second forward pass (different dropout)
    loss = r_drop_loss(logits1, logits2, batch["labels"], alpha=5.0)
    loss.backward()
    optimizer.step()
```

## Recommended Hyperparameters
- alpha=5.0 (KL divergence weight)

## Notes
- Training time approximately doubles due to two forward passes per step.
- Requires dropout to be enabled during training (the default).
- Effective across diverse NLP tasks including translation, summarization, and comprehension.
