# KL Regularization

**Summary**: Constrains the fine-tuned model's output distribution from diverging too far from the original pretrained model, preventing catastrophic forgetting.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
A KL divergence penalty term between the fine-tuned model's output distribution and the original model's output distribution is added to the SFT loss. This preserves the pretrained model's general knowledge while learning new task-specific behaviors.

## Usage
```python
import torch.nn.functional as F

# Load reference model (frozen original pretrained model)
ref_model = AutoModelForCausalLM.from_pretrained("base_model")
ref_model.eval()
for p in ref_model.parameters():
    p.requires_grad = False

def sft_with_kl_loss(model, ref_model, batch, beta=0.1):
    outputs = model(**batch)
    logits = outputs.logits

    with torch.no_grad():
        ref_logits = ref_model(**batch).logits

    # SFT loss
    ce_loss = F.cross_entropy(
        logits.view(-1, logits.size(-1)),
        batch["labels"].view(-1)
    )

    # KL regularization
    log_probs = F.log_softmax(logits, dim=-1)
    ref_probs = F.softmax(ref_logits, dim=-1)
    kl_loss = F.kl_div(log_probs, ref_probs, reduction='batchmean')

    return ce_loss + beta * kl_loss

# Recommended: beta=0.1 ~ 0.5
```

## Recommended Hyperparameters
- beta=0.1 to 0.5 (KL penalty weight)

## Notes
- Requires loading an additional reference model, doubling memory usage.
- The reference model can be quantized to reduce memory overhead.
- Particularly important for domain-specific fine-tuning where preserving general capabilities matters.
- Similar concept is used in RLHF/DPO to prevent reward hacking.
