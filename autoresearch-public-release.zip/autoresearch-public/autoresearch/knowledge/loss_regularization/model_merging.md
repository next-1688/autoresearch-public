# Model Merging (SLERP / TIES / DARE)

**Summary**: Combines capabilities of multiple fine-tuned models through weight arithmetic without additional training.
**Paper**: TIES: https://arxiv.org/abs/2306.01708 | DARE: https://arxiv.org/abs/2311.03099
**Code**: https://github.com/arcee-ai/mergekit
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer N/A | DeepSpeed N/A | Megatron N/A | Custom PyTorch N/A (post-training)

## Principle
- **SLERP** (Spherical Linear Interpolation): Interpolates two models on the weight-space sphere, maintaining weight norm consistency.
- **TIES** (Trim, Elect Sign, Merge): Trims small changes -> resolves sign conflicts -> merges remaining parameters.
- **DARE** (Drop And REscale): Randomly drops most delta parameters and rescales, reducing interference before merging.

## Usage
```yaml
# Install mergekit
pip install mergekit

# SLERP config (merge_config.yaml):
slices:
  - sources:
      - model: model_A
        layer_range: [0, 32]
      - model: model_B
        layer_range: [0, 32]
merge_method: slerp
base_model: model_A
parameters:
  t: 0.5  # interpolation coefficient 0->A, 1->B
dtype: bfloat16

# DARE-TIES config:
models:
  - model: base_model
  - model: finetuned_model_A
    parameters:
      density: 0.5    # DARE retention ratio
      weight: 1.0
  - model: finetuned_model_B
    parameters:
      density: 0.5
      weight: 0.5
merge_method: dare_ties
base_model: base_model
dtype: bfloat16
```
```bash
# Execute merge
mergekit-yaml merge_config.yaml ./merged_model --cuda
```

## Recommended Hyperparameters
- SLERP: t=0.5
- DARE: density=0.5
- For multi-model merging: use TIES or DARE-TIES

## Notes
- No additional training required; this is a post-training technique.
- mergekit is the standard tool for model merging.
- SLERP works best for two-model merging; TIES/DARE-TIES for three or more models.
- The merged model quality depends heavily on the compatibility of the source models.
