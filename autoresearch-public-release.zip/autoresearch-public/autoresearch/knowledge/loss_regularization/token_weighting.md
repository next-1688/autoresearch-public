# Token Weighting / Selective Loss Masking

**Summary**: Applies different loss weights to different tokens, focusing on key tokens and ignoring noise tokens.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: easy
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Not all tokens are equally important in SFT -- the instruction portion should not be included in the loss (only supervise the response), and certain key tokens in the response (e.g., answer cores, critical code lines) are more important than filler tokens. Token-level weights or masks enable selective training.

## Usage
```python
# Method 1: Compute loss only on response portion (standard practice)
# TRL SFTTrainer automatic support:
from trl import SFTTrainer, SFTConfig, DataCollatorForCompletionOnlyLM

response_template = "[/INST]"  # or "<|assistant|>"
collator = DataCollatorForCompletionOnlyLM(
    response_template=response_template,
    tokenizer=tokenizer
)
trainer = SFTTrainer(
    model=model, args=training_args,
    data_collator=collator,  # automatically masks instruction portion
    train_dataset=dataset,
)

# Method 2: Custom token weights
def weighted_loss(logits, labels, weights):
    """
    weights: shape [batch, seq_len], weight for each token
    """
    shift_logits = logits[..., :-1, :].contiguous()
    shift_labels = labels[..., 1:].contiguous()
    shift_weights = weights[..., 1:].contiguous()

    loss_fct = torch.nn.CrossEntropyLoss(reduction='none')
    per_token_loss = loss_fct(
        shift_logits.view(-1, shift_logits.size(-1)),
        shift_labels.view(-1)
    ).view(shift_labels.shape)

    weighted = per_token_loss * shift_weights
    return weighted.sum() / shift_weights.sum()
```

## Recommended Hyperparameters
- Response-only loss masking is the standard practice for SFT.
- Custom token weights depend on the specific task and importance criteria.

## Notes
- Masking instruction tokens from the loss is considered standard practice in SFT.
- TRL's DataCollatorForCompletionOnlyLM provides easy built-in support.
- Custom token weighting requires defining an importance function for your specific use case.
