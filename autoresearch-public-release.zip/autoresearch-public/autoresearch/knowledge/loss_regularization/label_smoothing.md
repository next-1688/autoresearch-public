# Label Smoothing

**Summary**: Softens one-hot labels into a probability distribution, reducing overfitting and improving model calibration.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✓ | Custom PyTorch ✓

## Principle
Target probabilities are changed from [0, 1] to [epsilon/V, 1-epsilon+epsilon/V], where epsilon is the smoothing coefficient and V is the vocabulary size. This prevents the model from becoming overly confident on training data, improving generalization and probability calibration.

## Usage
```python
# HuggingFace Trainer:
training_args = TrainingArguments(
    label_smoothing_factor=0.1,  # common values: 0.05 ~ 0.1
)

# PyTorch manual implementation:
loss_fn = torch.nn.CrossEntropyLoss(label_smoothing=0.1)

# Or in model config:
# model.config.label_smoothing = 0.1
```

## Recommended Hyperparameters
- label_smoothing=0.1 (general purpose)
- label_smoothing=0.05 (for smaller models)

## Notes
- One of the simplest regularization techniques to implement.
- Improves model calibration, making predicted probabilities more reliable.
- Built-in support in both HuggingFace Trainer and PyTorch CrossEntropyLoss.
