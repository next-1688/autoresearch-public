# Rank Averaging

**Summary**: Average percentile-rank-transformed predictions to neutralize scale differences and boost ranking metrics.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: trivial
**Library Compatibility**: sklearn ✓ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
Rank averaging converts each model's predictions to percentile ranks (0 to 1), then averages the ranks. This eliminates scale and distribution differences between models -- a critical issue when ensembling heterogeneous model types (e.g., GBDT vs neural nets vs linear models). Each model's contribution is normalized purely by ordering, making the method robust to outliers and miscalibration. It is especially effective for ranking-based metrics (AUC, NDCG, top-K precision) where only relative ordering matters.

## Usage
```python
import numpy as np
from scipy.stats import rankdata

def rank_average(predictions_list, weights=None):
    """Rank-average multiple model predictions.

    Args:
        predictions_list: list of 1D arrays (one per model)
        weights: optional weights per model (default: equal)
    Returns:
        Averaged rank predictions in [0, 1]
    """
    n = len(predictions_list[0])
    if weights is None:
        weights = np.ones(len(predictions_list))
    weights = np.array(weights) / sum(weights)

    ranked = np.zeros(n)
    for preds, w in zip(predictions_list, weights):
        ranks = rankdata(preds, method="average") / n  # percentile ranks
        ranked += w * ranks
    return ranked

# Example: rank-average 3 GBDT variants for a ranking task
lgb_preds = lgb_model.predict(X_test)
xgb_preds = xgb_model.predict(X_test)
cat_preds = cat_model.predict(X_test)

final_ranks = rank_average([lgb_preds, xgb_preds, cat_preds])
# Use final_ranks directly for ranking metrics; threshold for classification
```

## Recommended Hyperparameters
- Use `method="average"` in rankdata for tie handling (default, most stable)
- Equal weights is the default; optimize weights only when models have clearly different quality
- For classification: apply threshold to rank-averaged output, or use original probabilities for calibration

## When to Use
- Ranking-oriented metrics: AUC, NDCG, MAP, top-K precision
- Ensembling heterogeneous model types with different prediction scales
- Models output different ranges (e.g., one in [0,1], another in [-3, 3])
- Quick, parameter-free ensemble that "just works"

## When NOT to Use
- Need calibrated probabilities (rank transform destroys calibration)
- Regression with absolute-value metrics (MAE, RMSE) -- rank transform discards magnitude information
- All models already output on the same well-calibrated scale (plain averaging is simpler and sufficient)

## Notes
- Evaluate both individual model quality and error correlation when selecting ensemble members; validate the combined ranks on held-out data.
- Rank averaging is especially powerful in Kaggle-style competitions where leaderboard metric is AUC or ranking-based.
- Can be combined with blending: first rank-transform, then optimize weights on the ranks.
- Computational cost is negligible -- O(n log n) per model for the sort underlying rankdata.
