# Multi-Layer Model Stacking

**Summary**: Train a meta-learner on out-of-fold predictions from diverse base models to capture complementary signals.
**Paper**: https://doi.org/10.1016/S0893-6080(05)80023-1
**Code**: N/A
**Modification Complexity**: moderate
**Library Compatibility**: sklearn ✓ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
Stacking trains multiple base models (level-0) and feeds their out-of-fold (OOF) predictions as features to a meta-learner (level-1). K-fold OOF generation is critical: each base model is trained on K-1 folds and predicts the held-out fold, producing unbiased meta-features that prevent data leakage. The meta-learner learns optimal combination weights plus non-linear interactions between base predictions. Two-level stacking uses a single meta-learner; three-level stacking adds another layer, though returns diminish quickly beyond two levels.

## Usage
```python
from sklearn.ensemble import StackingRegressor, GradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.model_selection import cross_val_predict
import lightgbm as lgb
import numpy as np

# --- Option 1: sklearn StackingRegressor ---
estimators = [
    ("lgb", lgb.LGBMRegressor(n_estimators=500, learning_rate=0.05)),
    ("gb", GradientBoostingRegressor(n_estimators=300)),
]
stack = StackingRegressor(estimators=estimators, final_estimator=Ridge(alpha=1.0), cv=5)
stack.fit(X_train, y_train)
preds = stack.predict(X_test)

# --- Option 2: Manual OOF stacking (more control) ---
from sklearn.model_selection import KFold
kf = KFold(n_splits=5, shuffle=True, random_state=42)
oof = np.zeros((len(X_train), len(estimators)))
test_preds = np.zeros((len(X_test), len(estimators)))

for i, (name, model) in enumerate(estimators):
    oof[:, i] = cross_val_predict(model, X_train, y_train, cv=kf, method="predict")
    model.fit(X_train, y_train)
    test_preds[:, i] = model.predict(X_test)

meta = Ridge(alpha=1.0)
meta.fit(oof, y_train)
final_preds = meta.predict(test_preds)
```

## Recommended Hyperparameters
- OOF folds: 5 (default), 10 for small datasets
- Meta-learner default: Ridge (regression) or LogisticRegression (classification) -- safe, avoids overfitting
- Meta-learner advanced: LightGBM with low depth (max_depth=3, n_estimators=100, learning_rate=0.05) when data > 10k rows
- Base models: aim for 3-7 diverse models spanning different algorithm families

## When to Use
- Multiple diverse base models are available (e.g., GBDT + linear + NN)
- Dataset is large enough for reliable K-fold splits (generally > 5k rows)
- Competition or project where marginal accuracy gain justifies added complexity

## When NOT to Use
- Very small datasets (< 1k rows) -- OOF predictions will be noisy
- All base models are similar (e.g., all XGBoost variants with different seeds) -- stacking adds complexity without diversity benefit
- Strict latency requirements at inference time

## Notes
- Always use OOF predictions for meta-learner training; never use in-sample predictions (severe leakage).
- A linear meta-learner is almost always the right starting point -- it regularizes naturally and rarely overfits.
- Three-level stacking rarely improves over two-level; the extra complexity is seldom justified.
- Include raw features alongside OOF predictions in the meta-learner input only if you have enough data to avoid overfitting.
