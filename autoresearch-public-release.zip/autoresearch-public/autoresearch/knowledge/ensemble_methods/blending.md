# Weighted Averaging / Blending

**Summary**: Combine model predictions via optimized weights to outperform any single model with minimal effort.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: trivial
**Library Compatibility**: sklearn ✓ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
Blending averages predictions from multiple models using learned or fixed weights. Simple averaging (equal weights) is a surprisingly strong baseline because it reduces variance when models make uncorrelated errors. Optimized weights can further improve results by upweighting stronger or more diverse models. Weights are typically constrained to sum to 1 and be non-negative. Weight optimization can use Nelder-Mead (gradient-free, robust), Optuna (handles noisy objectives), or grid search over a simplex. Holdout-based weight estimation is faster; CV-based is more reliable.

## Usage
```python
import numpy as np
from scipy.optimize import minimize

# preds: list of arrays, each shape (n_samples,)
# y_true: ground truth
preds = [model_a_preds, model_b_preds, model_c_preds]

# --- Option 1: Simple average (strong baseline) ---
blend = np.mean(preds, axis=0)

# --- Option 2: Scipy weight optimization ---
from sklearn.metrics import mean_squared_error

def objective(weights):
    w = np.array(weights)
    w = w / w.sum()  # normalize
    blended = sum(w_i * p for w_i, p in zip(w, preds))
    return mean_squared_error(y_true, blended)

result = minimize(objective, x0=[1/len(preds)] * len(preds),
                  method="Nelder-Mead",
                  constraints={"type": "eq", "fun": lambda w: sum(w) - 1})
best_weights = np.array(result.x) / sum(result.x)
final_preds = sum(w * p for w, p in zip(best_weights, preds))

# --- Option 3: Optuna weight search ---
import optuna
def optuna_objective(trial):
    ws = [trial.suggest_float(f"w{i}", 0.0, 1.0) for i in range(len(preds))]
    ws = np.array(ws) / sum(ws)
    blended = sum(w * p for w, p in zip(ws, preds))
    return mean_squared_error(y_true, blended)

study = optuna.create_study(direction="minimize")
study.optimize(optuna_objective, n_trials=200, show_progress_bar=False)
```

## Recommended Hyperparameters
- Start with simple average -- it often matches or beats optimized weights on test set
- Nelder-Mead: run multiple restarts (5-10) with random initial weights to avoid local minima
- Optuna: 200-500 trials sufficient for 2-5 models
- Always evaluate weights on held-out data or via CV, never on training set

## When to Use
- Quick ensemble of 2-5 models with minimal code changes
- Want guaranteed improvement (or at worst no degradation) over the best single model
- Time-constrained: blending takes minutes, not hours

## When NOT to Use
- Only one model available -- nothing to blend
- Models produce nearly identical predictions (correlation > 0.99) -- blending adds no value
- Need to capture non-linear interactions between model outputs (use stacking instead)

## Notes
- Simple average is the most underrated technique in ML competitions -- always try it first.
- Optimized weights can overfit to validation set; prefer CV-based estimation for robustness.
- For classification, blend probabilities (not class labels) before applying threshold.
- Blending log-odds instead of probabilities can work better for imbalanced binary tasks.
