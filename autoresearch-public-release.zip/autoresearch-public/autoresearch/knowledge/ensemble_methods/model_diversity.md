# Diversity-Driven Model Selection for Ensembles

**Summary**: Select ensemble members by maximizing prediction diversity, not just individual accuracy.
**Paper**: https://doi.org/10.1023/A:1022859003006
**Code**: N/A
**Modification Complexity**: moderate
**Library Compatibility**: sklearn ✓ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
Ensemble performance depends on both individual model accuracy and the diversity (error decorrelation) among members. Adding a highly accurate model whose errors are correlated with existing members yields little gain -- or can even degrade performance. Diversity metrics quantify how differently models err: Spearman correlation of residuals, Q-statistic, disagreement measure, and double-fault measure. Greedy forward selection picks models that minimize ensemble error on validation data, naturally balancing accuracy and diversity. Negative Correlation Learning explicitly penalizes correlated errors during training.

## Usage
```python
import numpy as np
from scipy.stats import spearmanr
from itertools import combinations

def error_correlation_matrix(predictions_list, y_true):
    """Compute pairwise Spearman correlation of prediction errors."""
    residuals = [preds - y_true for preds in predictions_list]
    n_models = len(residuals)
    corr_matrix = np.ones((n_models, n_models))
    for i, j in combinations(range(n_models), 2):
        rho, _ = spearmanr(residuals[i], residuals[j])
        corr_matrix[i, j] = corr_matrix[j, i] = rho
    return corr_matrix

def greedy_diverse_selection(predictions_list, y_true, metric_fn, max_models=5):
    """Greedy forward selection: pick models that minimize ensemble error."""
    available = list(range(len(predictions_list)))
    selected = []

    # Start with the single best model
    scores = [(metric_fn(y_true, predictions_list[i]), i) for i in available]
    best_idx = min(scores, key=lambda x: x[0])[1]  # assumes lower is better
    selected.append(best_idx)
    available.remove(best_idx)

    while len(selected) < max_models and available:
        best_score, best_candidate = float("inf"), None
        for idx in available:
            trial = selected + [idx]
            ensemble_pred = np.mean([predictions_list[i] for i in trial], axis=0)
            score = metric_fn(y_true, ensemble_pred)
            if score < best_score:
                best_score, best_candidate = score, idx
        if best_candidate is None:
            break
        selected.append(best_candidate)
        available.remove(best_candidate)
    return selected

# Example usage
from sklearn.metrics import mean_squared_error
corr = error_correlation_matrix(all_preds, y_val)
print("Pairwise error correlations:\n", np.round(corr, 3))
chosen = greedy_diverse_selection(all_preds, y_val, mean_squared_error, max_models=4)
print("Selected model indices:", chosen)
```

## Recommended Hyperparameters
- Target pairwise error correlation below 0.7 for meaningful diversity benefit
- Greedy selection: limit to 3-7 models; beyond that, marginal gains vanish
- Diversity sources: vary algorithm family, feature subsets, hyperparameters, random seeds, preprocessing
- Validate ensemble on held-out fold to avoid selection overfitting

## When to Use
- Large model pool (10+) and need to select the best subset for ensemble
- Models span multiple algorithm families (GBDT, linear, NN, kNN)
- Diminishing returns observed when adding more models -- diversity analysis identifies why

## When NOT to Use
- Only 2-3 models available -- just try all combinations directly
- All models use the same algorithm with minor hyperparameter variation (diversity will be low by construction)
- Time budget does not allow training a large model pool

## Notes
- Check validation error correlation before adding a model; adding similar models does not guarantee an ensemble improvement.
- Algorithm diversity > hyperparameter diversity > seed diversity, in terms of decorrelation impact.
- Greedy forward selection can overfit to validation set; use nested CV if the model pool is large.
- The Q-statistic measures pairwise dependence: Q near 0 means independent errors (ideal); Q near 1 means highly correlated errors.
