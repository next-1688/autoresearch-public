# Pairwise Ranking Losses

**Summary**: Learn relative ordering between item pairs via BPR, RankNet, or margin-based losses
**Paper**: https://icml.cc/2015/wp-content/uploads/2015/06/icml_ranking.pdf
**Code**: N/A
**Modification Complexity**: moderate
**Library Compatibility**: xgboost ✓ | lightgbm ✓ | pytorch ✓

## Principle

Pairwise ranking reduces ranking to binary classification on item pairs. Key variants:
- **RankNet**: cross-entropy on score differences (sigmoid of s_i - s_j)
- **BPR**: simplified RankNet for implicit feedback
- **Margin-based**: hinge loss requiring a score margin between positive and negative items

## Usage
```python
# XGBoost pairwise ranking
import xgboost as xgb
dtrain = xgb.DMatrix(X_train, label=y_train)
dtrain.set_group(train_group_sizes)
params = {"objective": "rank:pairwise", "eval_metric": "ndcg", "eta": 0.1, "max_depth": 6}
model = xgb.train(params, dtrain, num_boost_round=300)

# PyTorch margin ranking loss
import torch.nn as nn
loss_fn = nn.MarginRankingLoss(margin=1.0)
loss = loss_fn(score_pos, score_neg, torch.ones_like(score_pos))
```

## Recommended Hyperparameters

- XGBoost `rank:pairwise`: eta=0.05-0.1, max_depth=6-8
- Margin loss: margin=0.5-2.0 depending on score scale
- Pair sampling: 5-20 negatives per positive
- Hard negative mining: top 10-30% of negatives for better convergence

## When to Use

- Binary relevance ranking (relevant / not relevant)
- Need explicit pairwise ordering guarantees
- Implicit feedback data (clicks, purchases)

## When NOT to Use

- Graded relevance with multiple levels (LambdaRank is better)
- Very large groups (O(n^2) pair explosion)
- Absolute score calibration needed (pairwise only learns relative order)

## Notes

- Pair construction strategy strongly affects training efficiency and quality
- Hard negative mining accelerates convergence significantly
- For large groups, subsample pairs via random or importance-weighted sampling
- Combine with pointwise loss (multi-task) for better absolute score calibration
