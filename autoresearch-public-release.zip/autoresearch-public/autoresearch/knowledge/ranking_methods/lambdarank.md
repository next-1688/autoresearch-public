# LambdaRank / LambdaMART

**Summary**: Listwise learning-to-rank via lambda gradients that directly optimize NDCG
**Paper**: https://www.microsoft.com/en-us/research/publication/from-ranknet-to-lambdarank-to-lambdamart-an-overview/
**Code**: N/A (built into GBDT libraries)
**Modification Complexity**: moderate
**Library Compatibility**: lightgbm ✓ | xgboost ✓ | catboost ✓

## Principle

LambdaRank defines implicit loss gradients (lambdas) that weight pairwise swaps by their
effect on NDCG. LambdaMART combines this with MART (gradient-boosted trees). Each gradient
is scaled by |delta_NDCG| so the model focuses on swaps that matter most for ranking.

## Usage
```python
import lightgbm as lgb
ranker = lgb.LGBMRanker(
    objective="lambdarank", metric="ndcg", n_estimators=500,
    learning_rate=0.05, num_leaves=63, min_child_samples=20,
    label_gain=[0, 1, 3, 7, 15], eval_at=[5, 10],
)
ranker.fit(X_train, y_train, group=train_group_sizes,
           eval_set=[(X_val, y_val)], eval_group=[val_group_sizes])
```

## Recommended Hyperparameters

- `eval_at`: [5, 10] | `label_gain`: [0, 1, 3, 7, 15] for graded relevance
- `n_estimators`: 300-1000 with early stopping | `num_leaves`: 31-127
- XGBoost: `objective='rank:ndcg'` | CatBoost: `loss_function='YetiRank'`

## When to Use

- Explicit ranking task with groups of items to rank
- Optimizing NDCG, MAP, or other IR metrics
- Graded relevance labels (multi-level, not just binary)

## When NOT to Use

- Pointwise regression already achieves strong results
- No natural group structure in the data
- Binary relevance only (pairwise methods may be simpler)

## Notes

- The `group` parameter is critical: defines which rows belong to the same query
- Group sizes must be a list of integers summing to total rows
- Label values should be non-negative integers representing relevance grades
