# Constant with Warmup

**Summary**: Linear warmup followed by a constant learning rate; suitable for short training or LoRA fine-tuning.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✓ | Custom PyTorch ✓

## Principle
The learning rate linearly increases during warmup and then remains constant for the rest of training. This is the simplest schedule and works well when training duration is short or when using parameter-efficient methods like LoRA/QLoRA.

## Usage
```python
training_args = TrainingArguments(
    lr_scheduler_type="constant_with_warmup",
    learning_rate=2e-5,
    warmup_steps=100,
)

# Or PyTorch:
from transformers import get_constant_schedule_with_warmup
scheduler = get_constant_schedule_with_warmup(optimizer, num_warmup_steps=100)
```

## Recommended Hyperparameters
- warmup_steps: 100 or warmup_ratio=0.03~0.1
- learning_rate: 2e-5 (typical for SFT)

## Notes
- Best suited for LoRA/QLoRA fine-tuning and short training runs.
- Simplest possible schedule with minimal hyperparameter tuning.
- For longer training runs, cosine or linear decay may yield better results.
