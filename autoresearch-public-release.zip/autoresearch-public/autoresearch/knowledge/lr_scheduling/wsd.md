# WSD (Warmup-Stable-Decay)

**Summary**: Three-phase schedule -- warmup, constant, rapid decay. No need to know total steps in advance; supports mid-training branching.
**Paper**: https://arxiv.org/abs/2404.06395
**Code**: N/A
**Modification Complexity**: easy
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Divided into three phases: Warmup (linear warmup) -> Stable (constant lr for the main training) -> Decay (rapid decay to produce a strong model). The Stable phase can continue indefinitely; whenever a model is needed, fork a Decay phase from the current checkpoint to obtain a strong model. Particularly suitable for scenarios where total training steps are unknown.

## Usage
```python
# Manual implementation of WSD scheduler
class WSDScheduler:
    def __init__(self, optimizer, warmup_steps, stable_steps, decay_steps,
                 max_lr, min_lr=0):
        self.optimizer = optimizer
        self.warmup_steps = warmup_steps
        self.stable_steps = stable_steps
        self.decay_steps = decay_steps
        self.max_lr = max_lr
        self.min_lr = min_lr
        self.step_count = 0

    def step(self):
        self.step_count += 1
        if self.step_count <= self.warmup_steps:
            # Warmup: linear warmup
            lr = self.max_lr * self.step_count / self.warmup_steps
        elif self.step_count <= self.warmup_steps + self.stable_steps:
            # Stable: constant learning rate
            lr = self.max_lr
        else:
            # Decay: cosine/linear decay
            decay_progress = (self.step_count - self.warmup_steps - self.stable_steps) / self.decay_steps
            decay_progress = min(1.0, decay_progress)
            lr = self.min_lr + 0.5 * (self.max_lr - self.min_lr) * (1 + math.cos(math.pi * decay_progress))

        for pg in self.optimizer.param_groups:
            pg['lr'] = lr

# Usage:
scheduler = WSDScheduler(optimizer,
    warmup_steps=500, stable_steps=5000, decay_steps=1000,
    max_lr=2e-5, min_lr=1e-7)
```

## Recommended Hyperparameters
- warmup = 5% of total steps
- decay = 10% of total steps
- stable = remaining steps

## Notes
- Ideal when total training duration is unknown or flexible.
- The stable phase can be extended indefinitely; branch off a decay phase anytime to get a usable model.
- Requires custom implementation as it is not built into standard frameworks.
