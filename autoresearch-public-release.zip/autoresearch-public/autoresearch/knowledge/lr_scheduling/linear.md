# Linear Warmup + Linear/Polynomial Decay

**Summary**: Linear warmup followed by linear or polynomial decay; simple and straightforward.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✓ | Custom PyTorch ✓

## Principle
The learning rate linearly increases during warmup, then linearly (or polynomially) decays to zero over the remaining training steps. This is a simple, well-understood schedule that works reliably across many settings.

## Usage
```python
# HuggingFace Trainer:
training_args = TrainingArguments(
    lr_scheduler_type="linear",       # linear decay
    # lr_scheduler_type="polynomial", # polynomial decay
    learning_rate=2e-5,
    warmup_steps=100,
)

# PyTorch:
from transformers import get_linear_schedule_with_warmup

scheduler = get_linear_schedule_with_warmup(
    optimizer,
    num_warmup_steps=100,
    num_training_steps=total_steps
)
```

## Recommended Hyperparameters
- warmup_steps: 100 or warmup_ratio=0.03~0.1
- learning_rate: 2e-5 (typical for SFT)

## Notes
- Simpler alternative to cosine schedule.
- Linear decay can be slightly less effective than cosine for long training runs.
- Polynomial decay offers a middle ground with adjustable decay power.
