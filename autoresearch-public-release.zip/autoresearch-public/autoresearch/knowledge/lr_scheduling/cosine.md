# Cosine Annealing

**Summary**: Learning rate decays following a cosine function from peak to near-zero; the most commonly used schedule in LLM training.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✓ | Custom PyTorch ✓

## Principle
lr(t) = lr_min + 0.5 * (lr_max - lr_min) * (1 + cos(pi * t / T)). Used with warmup: learning rate first linearly increases to the peak, then decays following a cosine curve. The smooth decay avoids the abrupt changes of step-wise schedules.

## Usage
```python
# HuggingFace Trainer (cosine is the default):
training_args = TrainingArguments(
    lr_scheduler_type="cosine",
    learning_rate=2e-5,
    warmup_steps=100,   # or warmup_ratio=0.03
    num_train_epochs=3,
)

# PyTorch manual:
from torch.optim.lr_scheduler import CosineAnnealingLR

scheduler = CosineAnnealingLR(optimizer, T_max=total_steps, eta_min=1e-7)

# Cosine with warmup:
from transformers import get_cosine_schedule_with_warmup

scheduler = get_cosine_schedule_with_warmup(
    optimizer,
    num_warmup_steps=100,
    num_training_steps=total_steps
)
```

## Recommended Hyperparameters
- warmup_ratio=0.03~0.1
- eta_min=0 or 1e-7

## Notes
- Default scheduler in HuggingFace Trainer.
- Most widely used LR schedule for LLM fine-tuning and pretraining.
- The smooth decay curve helps with stable convergence compared to step-wise schedules.
