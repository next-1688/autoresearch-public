# LION (EvoLved sIgn mOmeNtum)

**Summary**: A sign-momentum optimizer discovered via program search, requiring less memory than Adam (no second-moment storage).
**Paper**: https://arxiv.org/abs/2302.06675
**Code**: https://github.com/lucidrains/lion-pytorch
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
LION uses only the sign of the gradient direction (+-1) for each update, computing the update direction by taking the sign of an interpolation between momentum and the current gradient. It only needs to store momentum (no second-moment v), reducing optimizer memory by approximately 1/3.

## Usage
```python
pip install lion-pytorch

from lion_pytorch import Lion

optimizer = Lion(
    model.parameters(),
    lr=3e-6,             # 3-10x smaller than AdamW
    betas=(0.9, 0.99),
    weight_decay=0.1     # 3-10x larger than AdamW
)

# For HuggingFace Trainer (requires custom integration)
# Override create_optimizer in a Trainer subclass
```

## Recommended Hyperparameters
- lr = AdamW_lr / 3~10, weight_decay = AdamW_wd x 3~10, betas=(0.95, 0.98)

## Notes
- Learning rate should be significantly smaller than AdamW, while weight decay should be significantly larger.
- Memory savings come from not storing the second moment, making it attractive for large models.
- Requires custom integration for HF Trainer, DeepSpeed, and Megatron.
