# Spectrum (SNR-Based Layer Selection)

**Summary**: Selects the most important 25-50% of layers for training based on signal-to-noise ratio (SNR), freezing the rest.
**Paper**: https://arxiv.org/abs/2406.06623
**Code**: https://github.com/cognitivecomputations/spectrum
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Spectrum computes the signal-to-noise ratio for each layer's weights. Layers with low SNR contain more "noise" (i.e., information redundancy) and have low training value. By only unfreezing the layers with the highest SNR for fine-tuning, it achieves performance comparable to full-parameter fine-tuning while training only 25-50% of the parameters.

## Usage
```python
# Spectrum provides precomputed layer importance rankings
# Step 1: Compute SNR (or use precomputed results)
pip install spectrum-finetuning

from spectrum import compute_snr, get_top_layers

snr_scores = compute_snr(model)  # SNR for each layer
top_layers = get_top_layers(snr_scores, ratio=0.5)  # Top 50%

# Step 2: Only unfreeze selected layers
for name, param in model.named_parameters():
    param.requires_grad = False

for layer_idx in top_layers:
    for param in model.model.layers[layer_idx].parameters():
        param.requires_grad = True

# Always unfreeze embedding and lm_head
for param in model.model.embed_tokens.parameters():
    param.requires_grad = True
for param in model.lm_head.parameters():
    param.requires_grad = True
```

## Recommended Hyperparameters
- Freeze 50-75% of layers, prioritizing keeping layers with the highest SNR unfrozen.

## Notes
- The SNR computation is a one-time cost before training begins.
- For HF Trainer, manual layer freezing must be applied before passing the model to the Trainer.
- Always keep embedding and lm_head layers unfrozen regardless of their SNR scores.
- Provides significant memory and compute savings with minimal performance degradation.
