# SOAP (Second-Order Approximate Preconditioner)

**Summary**: A preconditioned optimizer that uses matrix decomposition to provide second-order approximate acceleration.
**Paper**: N/A
**Code**: https://github.com/nikhilvyas/SOAP
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
SOAP periodically decomposes the gradient matrix to construct an approximate second-order preconditioner, reducing curvature discrepancies in the parameter space. It is particularly effective with large batch sizes.

## Usage
```python
from soap import SOAP

optimizer = SOAP(
    model.parameters(),
    lr=3e-3,
    betas=(0.95, 0.95),
    weight_decay=0.01,
    precondition_frequency=10  # Update preconditioner every 10 steps
)
```

## Recommended Hyperparameters
- lr=3e-3, betas=(0.95, 0.95), precondition_frequency=10

## Notes
- Best performance is achieved with large batch sizes.
- The preconditioner update frequency controls the trade-off between computation cost and optimization quality.
- Suitable for scenarios where second-order information can significantly improve convergence.
