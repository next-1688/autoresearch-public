# Adam-mini

**Summary**: Reduces optimizer memory by 50% by grouping parameters based on Hessian structure analysis to share learning rates.
**Paper**: https://arxiv.org/abs/2406.16793
**Code**: https://github.com/zyushun/Adam-mini
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Adam-mini analyzes the structure of the second moment v in Adam and discovers that many parameters within the same Transformer block can share the same v value. By grouping parameters according to Hessian structure, each group maintains only a single v, reducing optimizer state memory by approximately half with no performance degradation.

## Usage
```python
pip install adam-mini

from adam_mini import Adam_mini

optimizer = Adam_mini(
    named_parameters=model.named_parameters(),
    lr=2e-5,
    betas=(0.9, 0.999),
    weight_decay=0.01,
    model_sharding=False,  # Set False for single GPU
    n_embd=4096,           # Model hidden size
    n_head=32,             # Number of attention heads
    n_query_groups=32      # Number of GQA groups (= n_head if no GQA)
)
```

## Recommended Hyperparameters
- Same as AdamW; additionally requires specifying n_embd, n_head, and n_query_groups for the target model.

## Notes
- Requires model architecture information (hidden size, number of heads, GQA groups) at initialization.
- Set `model_sharding=True` when using model parallelism across multiple GPUs.
- Drop-in memory savings with no performance loss compared to standard AdamW.
