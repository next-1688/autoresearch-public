# Grokfast (Gradient Filter)

**Summary**: Accelerates generalization (grokking) by amplifying slow-varying components in the gradient, requiring only a few lines of code.
**Paper**: https://arxiv.org/abs/2405.20233
**Code**: https://github.com/ironjr/grokfast
**Modification Complexity**: easy
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✓ | Custom PyTorch ✓

## Principle
Grokfast treats the sequence of parameter gradients as a signal and uses an exponential moving average filter to separate fast-varying and slow-varying components. By amplifying the slow-varying component (which corresponds to the generalization signal), it can accelerate grokking by over 50x.

## Usage
```python
# Method 1: Grokfast-EMA (recommended, simple)
# Insert after loss.backward() and before optimizer.step()

from grokfast import gradfilter_ema

grads = None  # Initialize

for batch in dataloader:
    loss = model(batch)
    loss.backward()

    # Insert this one line
    grads = gradfilter_ema(model, grads=grads, alpha=0.98, lamb=2.0)

    optimizer.step()
    optimizer.zero_grad()

# Method 2: Grokfast-MA (window filter)
from grokfast import gradfilter_ma
grads = None
grads = gradfilter_ma(model, grads=grads, window_size=100, lamb=5.0)
```

## Recommended Hyperparameters
- EMA: alpha=0.98, lamb=2.0
- MA: window_size=100, lamb=5.0

## Notes
- Framework-agnostic: since it operates as a gradient hook between backward() and step(), it works with any training framework.
- Grokfast-EMA is simpler and recommended for most use cases.
- The `lamb` parameter controls the amplification strength of the slow-varying gradient component.
