# Muon

**Summary**: An optimizer designed for Transformer "hidden weights" with built-in muP scaling, eliminating the need to tune lr across model sizes.
**Paper**: N/A
**Code**: https://github.com/KellerJordan/Muon
**Modification Complexity**: complex
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Muon applies Nesterov momentum combined with Newton-Schulz orthogonalization preconditioning to the hidden layer weights, while still using AdamW for embedding and head layers. The built-in muP scaling allows hyperparameters to transfer across different model sizes without retuning.

## Usage
```python
from muon import Muon

# Separate parameter groups for different optimizers
hidden_params = [p for n, p in model.named_parameters()
                 if 'embed' not in n and 'head' not in n]
other_params = [p for n, p in model.named_parameters()
                if 'embed' in n or 'head' in n]

optimizer = Muon(
    hidden_params,
    lr=0.02,
    momentum=0.95,
    nesterov=True,
    ns_steps=5  # Newton-Schulz iteration steps
)
optimizer_adam = torch.optim.AdamW(other_params, lr=3e-4)

# Both optimizers must be stepped during training
optimizer.step()
optimizer_adam.step()
```

## Recommended Hyperparameters
- lr=0.02, momentum=0.95, ns_steps=5

## Notes
- Requires a dual-optimizer setup: Muon for hidden layers and AdamW for embedding/head layers.
- Both optimizers must be stepped and zero_grad'd in the training loop.
- The built-in muP scaling is a key advantage for scaling experiments across model sizes.
