# SPAM (Spike-Aware Adam with Momentum Reset)

**Summary**: Detects loss spikes during training and automatically resets momentum to improve training stability.
**Paper**: https://arxiv.org/abs/2501.06842
**Code**: N/A
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
SPAM monitors loss spikes during training and automatically resets the optimizer's accumulated momentum when a spike is detected. This prevents abnormal gradients from continuing to affect subsequent updates through momentum, improving the stability of large-scale training.

## Usage
```python
# Implementation: add spike detection and momentum reset on top of AdamW
class SPAMAdam(torch.optim.AdamW):
    def __init__(self, *args, spike_threshold=5.0, **kwargs):
        super().__init__(*args, **kwargs)
        self.spike_threshold = spike_threshold
        self.loss_history = []

    def detect_and_reset(self, current_loss):
        if len(self.loss_history) > 10:
            avg = sum(self.loss_history[-10:]) / 10
            if current_loss > avg * self.spike_threshold:
                # Spike detected, reset momentum
                for group in self.param_groups:
                    for p in group['params']:
                        state = self.state[p]
                        if 'exp_avg' in state:
                            state['exp_avg'].zero_()
                print(f"Spike detected (loss={current_loss:.4f}), momentum reset")
        self.loss_history.append(current_loss)
```

## Recommended Hyperparameters
- spike_threshold=5.0 (ratio of current loss to recent average that triggers a reset)

## Notes
- Primarily designed for large-scale pretraining or long training scenarios where loss spikes are common.
- The spike detection threshold may need tuning depending on the training dynamics of the specific task.
- Can be combined with any Adam variant as the base optimizer.
