# AdEMAMix (Adaptive EMA Mixing)

**Summary**: Mixes two EMAs with different decay rates to better leverage historical gradient information and reduce forgetting.
**Paper**: https://arxiv.org/abs/2409.03137
**Code**: https://github.com/apple/ml-ademamix
**Modification Complexity**: moderate
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
AdEMAMix maintains two exponential moving averages -- one with fast decay and one with slow decay -- and mixes them for parameter updates. The slow EMA retains gradient information from further back in training, helping the model reduce catastrophic forgetting and improve final performance.

## Usage
```python
# Apple official implementation
from ademamix import AdEMAMix

optimizer = AdEMAMix(
    model.parameters(),
    lr=1e-3,
    betas=(0.9, 0.999, 0.9999),  # beta1, beta2, beta3 (slow EMA)
    alpha=5.0,                     # Slow EMA mixing coefficient
    weight_decay=0.01
)
```

## Recommended Hyperparameters
- betas=(0.9, 0.999, 0.9999), alpha=5.0

## Notes
- The third beta (beta3) controls the slow EMA decay rate; higher values retain gradient history for longer.
- The alpha parameter controls how much the slow EMA contributes to the update.
- Particularly useful for long training runs where catastrophic forgetting is a concern.
