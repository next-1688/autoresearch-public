# Sophia (Second-Order)

**Summary**: A scalable stochastic second-order optimizer that leverages Hessian information to accelerate convergence, reducing FLOPs by approximately 50%.
**Paper**: https://arxiv.org/abs/2305.14342
**Code**: https://github.com/Liuhong99/Sophia
**Modification Complexity**: complex
**Framework Compatibility**: HF Trainer ✗ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Sophia uses a diagonal Hessian approximation as a preconditioner, adaptively scaling the update for each parameter. A clipping mechanism controls the update magnitude, allowing it to reach the same loss as AdamW in roughly half the training steps.

## Usage
```python
# Clone the repository first
from sophia import SophiaG

optimizer = SophiaG(
    model.parameters(),
    lr=2e-4,
    betas=(0.965, 0.99),
    rho=0.01,          # Clipping threshold
    weight_decay=0.1
)

# Need to estimate Hessian every k steps (additional compute overhead)
# Using Hutchinson estimator:
if step % 10 == 0:
    loss.backward(create_graph=True)
    # Compute diagonal Hessian estimate
```

## Recommended Hyperparameters
- lr=2e-4, rho=0.01, betas=(0.965, 0.99), update Hessian every 10 steps

## Notes
- Works better with large batch sizes; has additional per-step computation overhead for Hessian estimation.
- The Hessian computation requires `create_graph=True`, which increases memory usage.
- Best suited for pretraining or long fine-tuning runs where the faster convergence can offset the extra per-step cost.
