# Schedule-Free AdamW

**Summary**: A schedule-free optimizer from Meta that replaces traditional lr schedules with interpolation and averaging, winner of MLCommons 2024 AlgoPerf competition.
**Paper**: https://arxiv.org/abs/2405.15682
**Code**: https://github.com/facebookresearch/schedule_free
**Modification Complexity**: easy
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✗ | Megatron ✗ | Custom PyTorch ✓

## Principle
Schedule-Free AdamW uses momentum interpolation and Polyak averaging to replace explicit learning rate decay schedules. It eliminates the need to specify total training steps or design warmup/cosine/decay strategies. It won the MLCommons 2024 AlgoPerf competition.

## Usage
```python
pip install schedulefree

import schedulefree

optimizer = schedulefree.AdamWScheduleFree(
    model.parameters(),
    lr=1e-3,             # Can use a larger lr
    betas=(0.9, 0.999),
    weight_decay=0.01,   # Recommended non-zero
    warmup_steps=500
)

# During training:
optimizer.train()
# ... training loop ...

# During evaluation (important! must switch mode):
optimizer.eval()
# ... evaluation ...
optimizer.train()  # Switch back to training mode
```

## Recommended Hyperparameters
- lr=1e-3 (can be larger), warmup_steps=500, weight_decay>0

## Notes
- Must call `optimizer.train()` and `optimizer.eval()` when switching between training and evaluation; failing to do so will produce incorrect results.
- Eliminates the need to tune learning rate schedules, warmup steps, or total training steps.
- For HF Trainer, requires a custom Trainer subclass to handle the train/eval mode switching.
