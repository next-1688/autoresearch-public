# AdamW

**Summary**: Decoupled weight decay Adam optimizer, the de facto standard baseline for LLM training.
**Paper**: https://arxiv.org/abs/2202.00089
**Code**: N/A (built-in to PyTorch)
**Modification Complexity**: trivial
**Framework Compatibility**: HF Trainer ✓ | DeepSpeed ✓ | Megatron ✓ | Custom PyTorch ✓

## Principle
AdamW decouples weight decay from the gradient update, so that the regularization effect is not affected by adaptive learning rate scaling. It is scale-free and significantly outperforms Adam+L2 in deep networks without BatchNorm.

## Usage
```python
# Native PyTorch support
optimizer = torch.optim.AdamW(
    model.parameters(),
    lr=2e-5,          # SFT common range: 1e-5 ~ 5e-5
    betas=(0.9, 0.999),
    weight_decay=0.01,  # Common range: 0.01 ~ 0.1
    eps=1e-8
)

# HuggingFace Trainer usage
training_args = TrainingArguments(
    optim="adamw_torch",  # or "adamw_hf", "adamw_8bit"
    learning_rate=2e-5,
    weight_decay=0.01,
)
```

## Recommended Hyperparameters
- lr=2e-5, weight_decay=0.01, betas=(0.9, 0.999)

## Notes
- The universal baseline optimizer for LLM fine-tuning; try this first before exploring alternatives.
- Supports 8-bit variants (e.g., `adamw_8bit` via bitsandbytes) to reduce memory usage.
- Compatible with all major training frameworks out of the box.
