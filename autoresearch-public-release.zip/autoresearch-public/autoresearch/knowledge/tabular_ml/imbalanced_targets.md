# Handling Imbalanced and Zero-Inflated Targets

**Summary**: Techniques for training GBDT models when target distributions are heavily skewed or zero-inflated.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: moderate
**Library Compatibility**: sklearn ✓ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
Imbalanced targets cause models to under-predict the minority class/tail. Solutions fall into three categories: (1) resampling the training data, (2) cost-sensitive learning via sample weights or built-in parameters, and (3) architectural approaches like hurdle models that decompose the problem. The right technique depends on the degree of imbalance, the evaluation metric, and whether the task is classification or regression on zero-inflated data.

## Usage
```python
# --- Built-in class weight parameters ---
# XGBoost: scale_pos_weight = count(neg) / count(pos)
xgb_params = {"scale_pos_weight": (y == 0).sum() / (y == 1).sum()}

# LightGBM: is_unbalance or scale_pos_weight
lgb_params = {"is_unbalance": True}  # auto-computes weight ratio

# CatBoost: auto_class_weights
cb_params = {"auto_class_weights": "Balanced"}

# --- Sample weights for regression on zero-inflated targets ---
import numpy as np
sample_weight = np.where(y > 0, 5.0, 1.0)  # upweight non-zero samples
model.fit(X_train, y_train, sample_weight=sample_weight)

# --- SMOTE oversampling (classification) ---
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import TomekLinks
from imblearn.combine import SMOTETomek
smote_tomek = SMOTETomek(smote=SMOTE(sampling_strategy=0.5, random_state=42),
                         tomek=TomekLinks())
X_res, y_res = smote_tomek.fit_resample(X_train, y_train)

# --- Hurdle model: classifier * regressor ---
from sklearn.model_selection import cross_val_predict
# Step 1: classify zero vs non-zero
y_binary = (y_train > 0).astype(int)
clf = lgb.LGBMClassifier(**clf_params)
p_nonzero = cross_val_predict(clf, X_train, y_binary, method="predict_proba")[:, 1]

# Step 2: regress on non-zero subset only
mask = y_train > 0
reg = lgb.LGBMRegressor(**reg_params)
reg.fit(X_train[mask], y_train[mask])
y_pred_nz = reg.predict(X_test)

# Step 3: combine
clf.fit(X_train, y_binary)
y_pred = clf.predict_proba(X_test)[:, 1] * y_pred_nz

# --- Focal loss for hard-example mining (classification) ---
def focal_loss_lgb(y_true, y_pred, gamma=2.0, alpha=0.25):
    p = 1.0 / (1.0 + np.exp(-y_pred))
    grad = p - y_true  # standard log-loss gradient, reweighted
    focal_weight = alpha * ((1 - p) ** gamma * y_true + p ** gamma * (1 - y_true))
    grad *= focal_weight
    hess = p * (1 - p) * focal_weight
    return grad, hess
```

## Recommended Hyperparameters
- **scale_pos_weight / is_unbalance**: start with auto, then tune the ratio
- **SMOTE sampling_strategy**: 0.3-0.5 for heavy imbalance (not 1.0, which over-generates)
- **sample_weight ratio** (non-zero vs zero): 3-10x, tune via CV
- **Focal loss gamma**: 1.0-3.0 (higher = more focus on hard examples)

## When to Use
- Target has >70% zeros (zero-inflated regression or classification)
- Class imbalance exceeds 10:1
- Ranking or threshold-sensitive metrics on zero-inflated data

## When NOT to Use
- Mild imbalance (<3:1) -- GBDT handles this natively
- The model already achieves good recall/precision on the minority class
- AUC is the metric and calibration does not matter

## Notes
- SMOTE only works for classification; for zero-inflated regression, use sample_weight or Tweedie loss instead.
- Always evaluate with the competition metric, not just accuracy -- accuracy is misleading on imbalanced data.
