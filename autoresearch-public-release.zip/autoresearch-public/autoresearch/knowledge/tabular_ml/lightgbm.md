# LightGBM with GOSS and EFB

**Summary**: Fast gradient boosting with leaf-wise growth, native categorical support, and efficient large-dataset handling.
**Paper**: https://papers.nips.cc/paper/2017/hash/6449f44a102fde848669bdd9eb6b76fa-Abstract.html
**Code**: https://github.com/microsoft/LightGBM
**Modification Complexity**: trivial
**Library Compatibility**: lightgbm ✓

## Principle

LightGBM uses two key innovations for speed: Gradient-based One-Side Sampling (GOSS) keeps instances with large gradients and randomly samples those with small gradients, reducing data size while maintaining accuracy. Exclusive Feature Bundling (EFB) bundles mutually exclusive sparse features into single features, reducing dimensionality. Unlike XGBoost's depth-wise growth, LightGBM grows trees leaf-wise, expanding the leaf with the highest loss reduction. This yields deeper, more complex trees that often achieve lower error with fewer iterations. The relationship between num_leaves and max_depth is approximately: num_leaves ~ 2^max_depth.

## Usage

```python
import lightgbm as lgb
from sklearn.model_selection import train_test_split

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2)

# Identify categorical columns by name or index
cat_features = ["category_col_a", "category_col_b"]

# --- Regression ---
reg = lgb.LGBMRegressor(
    n_estimators=3000, learning_rate=0.05, num_leaves=63,
    min_child_samples=20, subsample=0.8, colsample_bytree=0.8,
    reg_alpha=0.1, reg_lambda=1.0,
    boosting_type="gbdt",  # or "dart", "goss"
    verbosity=-1,
)
reg.fit(X_train, y_train, eval_set=[(X_val, y_val)],
        categorical_feature=cat_features,
        callbacks=[lgb.early_stopping(50), lgb.log_evaluation(100)])

# --- Classification ---
clf = lgb.LGBMClassifier(
    objective="binary",  # or "multiclass" with num_class
    n_estimators=3000, learning_rate=0.05, num_leaves=63,
    min_child_samples=20, subsample=0.8, colsample_bytree=0.8,
    reg_alpha=0.1, reg_lambda=1.0,
    verbosity=-1,
)
clf.fit(X_train, y_train, eval_set=[(X_val, y_val)],
        categorical_feature=cat_features,
        callbacks=[lgb.early_stopping(50), lgb.log_evaluation(100)])

# --- GOSS boosting (faster, less data used) ---
goss_model = lgb.LGBMRegressor(
    boosting_type="goss", n_estimators=3000, learning_rate=0.05,
    num_leaves=63, top_rate=0.2, other_rate=0.1,
)
```

## Recommended Hyperparameters

| Parameter | Range | Notes |
|-----------|-------|-------|
| num_leaves | 31-255 | Primary complexity control; ~2^max_depth |
| learning_rate | 0.01-0.3 | Lower values need more iterations |
| n_estimators | 100-5000 | Use early stopping |
| min_child_samples | 5-100 | Minimum data in a leaf; higher = less overfit |
| subsample (bagging_fraction) | 0.6-1.0 | Requires bagging_freq > 0 |
| colsample_bytree (feature_fraction) | 0.5-1.0 | Per-tree feature sampling |
| reg_alpha (lambda_l1) | 0-10 | L1 regularization |
| reg_lambda (lambda_l2) | 0-10 | L2 regularization |

## When to Use

- Large datasets (>100K rows) where training speed matters
- Datasets with categorical features (native support avoids one-hot explosion)
- High-dimensional sparse data (EFB bundles features automatically)
- When GOSS boosting can trade slight accuracy for significant speedup

## When NOT to Use

- Very small datasets (<1K rows): leaf-wise growth can overfit aggressively
- When interpretability of tree structure is critical (leaf-wise produces asymmetric trees)

## Notes

- Set `categorical_feature` param to use native categorical handling; columns must be pandas Categorical dtype or specified by name/index.
- `subsample` (bagging_fraction) only activates when `bagging_freq` > 0 (or use the sklearn API which sets it automatically).
- DART boosting (Dropouts meet Multiple Additive Regression Trees) adds dropout to boosting for regularization but is slower to train.
- For very large datasets, use `bin_construct_sample_cnt` to control histogram binning sample size.
- `is_unbalance=True` or `scale_pos_weight` for imbalanced classification.
- Feature importance: `model.feature_importances_` (split or gain based via `importance_type`).
