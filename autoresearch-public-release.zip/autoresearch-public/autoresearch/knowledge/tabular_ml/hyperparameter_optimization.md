# Optuna-Based Hyperparameter Optimization for GBDT

**Summary**: Systematic HPO using Optuna with TPE/CMA-ES samplers, pruning, and multi-objective support for GBDT models.
**Paper**: https://arxiv.org/abs/1907.10902
**Code**: https://github.com/optuna/optuna
**Modification Complexity**: moderate
**Library Compatibility**: sklearn ✓ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
Tree-structured Parzen Estimator (TPE) models the search space as two density functions (good/bad trials) and samples parameters that maximize the ratio. CMA-ES is preferred for purely continuous spaces. Pruning stops unpromising trials early using intermediate validation scores, saving compute. Multi-objective optimization (e.g., accuracy vs inference time) returns a Pareto front.

## Usage
```python
import optuna
from optuna.pruners import HyperbandPruner
from sklearn.model_selection import StratifiedKFold
import lightgbm as lgb

def objective(trial):
    params = {
        "learning_rate": trial.suggest_float("learning_rate", 1e-3, 0.3, log=True),
        "num_leaves": trial.suggest_int("num_leaves", 16, 255),
        "max_depth": trial.suggest_int("max_depth", 3, 12),
        "min_child_samples": trial.suggest_int("min_child_samples", 5, 100),
        "subsample": trial.suggest_float("subsample", 0.5, 1.0),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1.0),
        "reg_alpha": trial.suggest_float("reg_alpha", 1e-8, 10.0, log=True),
        "reg_lambda": trial.suggest_float("reg_lambda", 1e-8, 10.0, log=True),
    }
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    scores = []
    for fold, (train_idx, val_idx) in enumerate(cv.split(X, y)):
        dtrain = lgb.Dataset(X[train_idx], y[train_idx])
        dval = lgb.Dataset(X[val_idx], y[val_idx])
        model = lgb.train(params, dtrain, num_boost_round=2000,
                          valid_sets=[dval], callbacks=[
                              lgb.early_stopping(50),
                              optuna.integration.LightGBMPruningCallback(trial, "rmse"),
                          ])
        scores.append(model.best_score["valid_0"]["rmse"])
    return sum(scores) / len(scores)

study = optuna.create_study(direction="minimize",
                            sampler=optuna.samplers.TPESampler(seed=42),
                            pruner=HyperbandPruner(max_resource=2000))
study.optimize(objective, n_trials=100, timeout=3600)
best_params = study.best_params
```

## Recommended Hyperparameters
- **n_trials**: 50-200 (diminishing returns beyond 200)
- **Sampler**: TPE for mixed spaces (default); CMA-ES for continuous-only
- **Pruner**: HyperbandPruner (aggressive), MedianPruner (conservative)
- **Search space design**: log-uniform for learning_rate and regularization; int for depth/leaves; uniform for fractions (subsample, colsample)

## When to Use
- Default or manually-set hyperparameters have not been systematically tuned
- Validation score plateau suggests significant room for improvement
- Compute budget allows at least 50 trials with cross-validation

## When NOT to Use
- Model already well-tuned via prior HPO or domain expertise
- Compute budget is very limited (fewer than 20 trials is unreliable)
- The bottleneck is feature engineering or data quality, not model capacity

## Notes
- Always fix random seeds in the sampler and CV splits for reproducibility.
- Use `study.enqueue_trial({"learning_rate": 0.1, ...})` to seed the study with known-good defaults.
- For multi-objective (e.g., accuracy + speed): use `optuna.create_study(directions=["minimize", "minimize"])` and inspect the Pareto front via `study.best_trials`.
