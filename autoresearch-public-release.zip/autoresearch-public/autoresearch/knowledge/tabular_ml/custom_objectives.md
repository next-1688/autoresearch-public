# Custom Objective Functions and Eval Metrics for GBDT

**Summary**: Implementing custom loss functions (gradient + hessian) and evaluation metrics for XGBoost, LightGBM, and CatBoost.
**Paper**: N/A
**Code**: N/A
**Modification Complexity**: moderate to complex
**Library Compatibility**: sklearn ✗ | xgboost ✓ | lightgbm ✓ | catboost ✓

## Principle
GBDT models optimize by computing first-order (gradient) and second-order (hessian) derivatives of the loss function at each boosting step. Custom objectives let you align training directly with the evaluation metric or domain-specific goals. A custom eval metric is simpler (just computes a score) and is used for early stopping and monitoring without affecting the gradient update.

## Usage
```python
import numpy as np

# --- Tweedie loss (zero-inflated continuous targets) ---
# Built-in: xgb objective="reg:tweedie", tweedie_variance_power=1.5
# LightGBM: objective="tweedie", tweedie_variance_power=1.5

# --- Custom quantile loss for XGBoost ---
def quantile_obj(y_true, y_pred, alpha=0.9):
    residual = y_true - y_pred
    grad = np.where(residual > 0, -alpha, -(alpha - 1.0))
    hess = np.ones_like(y_pred)  # constant hessian
    return grad, hess

# --- Zero-Inflated Poisson custom objective (LightGBM) ---
def zip_objective(y_true, y_pred):
    """Approximate ZIP: upweight non-zero samples in Poisson loss."""
    y_pred = np.clip(y_pred, -20, 20)
    mu = np.exp(y_pred)
    weight = np.where(y_true > 0, 2.0, 1.0)
    grad = weight * (mu - y_true)
    hess = weight * mu
    return grad, hess

# --- Focal loss objective for binary classification (XGBoost) ---
def focal_obj(y_true, y_pred, gamma=2.0):
    p = 1.0 / (1.0 + np.exp(-y_pred))
    g1 = p - y_true
    g2 = p * (1.0 - p)
    focal_w = (y_true * (1 - p) ** gamma + (1 - y_true) * p ** gamma)
    grad = focal_w * g1
    hess = focal_w * (g2 * (1 + gamma * (2 * p - 1) * g1 / (focal_w + 1e-8)))
    hess = np.clip(hess, 1e-6, None)  # numerical stability
    return grad, hess

# --- Using custom objective + eval metric in XGBoost ---
import xgboost as xgb

def custom_rmse_eval(y_pred, dtrain):
    y_true = dtrain.get_label()
    rmse = np.sqrt(np.mean((y_true - y_pred) ** 2))
    return "custom_rmse", rmse

model = xgb.train(
    params={"disable_default_eval_metric": 1},
    dtrain=dtrain,
    num_boost_round=2000,
    evals=[(dval, "val")],
    obj=lambda y_pred, dtrain: quantile_obj(dtrain.get_label(), y_pred, alpha=0.9),
    custom_metric=custom_rmse_eval,
    early_stopping_rounds=50,
)

# --- LightGBM custom objective ---
lgb_model = lgb.train(
    params={"metric": "None"},
    train_set=dtrain,
    valid_sets=[dval],
    fobj=zip_objective,
    feval=lambda y_pred, dval: ("zip_rmse",
           np.sqrt(np.mean((dval.get_label() - y_pred) ** 2)), False),
    num_boost_round=2000,
    callbacks=[lgb.early_stopping(50)],
)
```

## Recommended Hyperparameters
- **Tweedie variance_power**: 1.0 (Poisson-like) to 2.0 (Gamma-like); tune via CV, 1.5 is a good default for zero-inflated data
- **Quantile alpha**: match the desired quantile (0.5 = median, 0.9 = 90th percentile)
- **Focal gamma**: 1.0-3.0; higher values focus more on hard examples
- **Learning rate**: reduce by 30-50% vs default when using custom objectives (gradients may have different scale)

## When to Use
- Standard MSE/logloss does not match the competition evaluation metric
- Zero-inflated or heavy-tailed targets need specialized distributional assumptions (Tweedie, ZIP)
- Domain-specific costs: asymmetric penalties, quantile predictions, ranking gains
- Focal loss when easy examples dominate and the model under-fits hard cases

## When NOT to Use
- Standard regression/classification loss already aligns well with the eval metric
- The custom objective is numerically unstable (flat hessian, extreme gradients)
- A simpler approach (sample_weight, built-in Tweedie) achieves the same effect

## Notes
- Always clip gradients and hessians for numerical stability. Hessian must be strictly positive.
- XGBoost note: `obj` receives `(y_pred, DMatrix)` -- extract labels via `dtrain.get_label()`. LightGBM `fobj` receives `(y_true, y_pred)`.
- When using a custom objective, you must also provide a custom eval metric -- the default metric may not be meaningful.
- Test the gradient numerically: compare `obj(y, p)` against finite differences of your loss to catch sign/scale bugs.
