# XGBoost Gradient Boosted Trees

**Summary**: Scalable gradient boosting with regularization, GPU support, and flexible objective functions.
**Paper**: https://arxiv.org/abs/1603.02754
**Code**: https://github.com/dmlc/xgboost
**Modification Complexity**: trivial
**Library Compatibility**: xgboost ✓

## Principle

XGBoost builds an ensemble of decision trees sequentially, where each new tree corrects the residual errors of the previous ensemble. It uses second-order Taylor expansion of the loss function for split finding, combined with L1 (reg_alpha) and L2 (reg_lambda) regularization on leaf weights to control model complexity. Depth-wise tree growth with max_depth control prevents overfitting. Approximate split finding via histogram binning (tree_method='hist' or 'gpu_hist') enables efficient training on large datasets.

## Usage

```python
import xgboost as xgb
from sklearn.model_selection import train_test_split

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2)

# --- Regression ---
reg = xgb.XGBRegressor(
    n_estimators=3000, learning_rate=0.05, max_depth=6,
    subsample=0.8, colsample_bytree=0.8,
    reg_alpha=0.1, reg_lambda=1.0, min_child_weight=5,
    tree_method="gpu_hist",  # GPU acceleration
    early_stopping_rounds=50,
)
reg.fit(X_train, y_train, eval_set=[(X_val, y_val)], verbose=100)

# --- Classification ---
clf = xgb.XGBClassifier(
    objective="binary:logistic",  # or "multi:softprob"
    n_estimators=3000, learning_rate=0.05, max_depth=6,
    subsample=0.8, colsample_bytree=0.8,
    reg_alpha=0.1, reg_lambda=1.0, min_child_weight=5,
    tree_method="gpu_hist",
    early_stopping_rounds=50,
)
clf.fit(X_train, y_train, eval_set=[(X_val, y_val)], verbose=100)

# --- Ranking (LambdaMART) ---
ranker = xgb.XGBRanker(
    objective="rank:ndcg", n_estimators=1000, learning_rate=0.1,
    max_depth=6, tree_method="gpu_hist",
)
ranker.fit(X_train, y_train, group=train_groups,
           eval_set=[(X_val, y_val)], eval_group=[val_groups])
```

## Recommended Hyperparameters

| Parameter | Range | Notes |
|-----------|-------|-------|
| max_depth | 3-10 | Start with 6; lower = less overfit |
| learning_rate (eta) | 0.01-0.3 | Lower values need more n_estimators |
| n_estimators | 100-5000 | Always use early stopping |
| subsample | 0.6-1.0 | Row sampling per tree |
| colsample_bytree | 0.5-1.0 | Feature sampling per tree |
| min_child_weight | 1-10 | Higher = more conservative |
| reg_alpha (L1) | 0-10 | Sparse feature selection |
| reg_lambda (L2) | 0.1-10 | Leaf weight shrinkage |

## When to Use

- Tabular data with structured/numerical features
- Mid-size datasets (10K-10M rows)
- Need strong baseline with well-understood tuning knobs
- Ranking tasks (LambdaMART objective)
- When GPU acceleration is available (tree_method='gpu_hist')

## When NOT to Use

- Many high-cardinality categorical features without encoding (CatBoost handles natively)
- Need native categorical feature support without manual encoding
- Very small datasets where simpler models suffice

## Notes

- Always use early stopping; set n_estimators high and let validation loss decide when to stop.
- tree_method='hist' is fast on CPU; 'gpu_hist' for GPU. Avoid 'exact' on large data.
- For missing values, XGBoost learns optimal split direction automatically -- no imputation needed.
- scale_pos_weight can handle class imbalance for binary classification.
- Feature importance available via `model.feature_importances_` or `xgb.plot_importance()`.
