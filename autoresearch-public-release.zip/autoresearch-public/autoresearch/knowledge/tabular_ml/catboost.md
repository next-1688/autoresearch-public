# CatBoost with Ordered Boosting

**Summary**: Gradient boosting with native categorical handling, ordered boosting to prevent target leakage, and symmetric trees.
**Paper**: https://arxiv.org/abs/1706.09516
**Code**: https://github.com/catboost/catboost
**Modification Complexity**: trivial
**Library Compatibility**: catboost ✓

## Principle

CatBoost addresses two core problems in gradient boosting. First, it handles categorical features natively using target statistics (ordered target encoding) with various CtrTypes (Counter, Borders, Buckets, BinarizedTargetMeanValue), eliminating the need for manual encoding. Second, Ordered Boosting prevents target leakage that occurs in standard gradient boosting: residuals used to fit each tree are computed on a random permutation ordering, so each example's gradient is estimated only from examples that precede it in the permutation. This reduces overfitting, especially on small-to-medium datasets. CatBoost also builds symmetric (oblivious) decision trees where the same split condition is used across an entire level, yielding faster inference and implicit regularization.

## Usage

```python
from catboost import CatBoostRegressor, CatBoostClassifier, Pool

# Specify categorical column indices or names
cat_features = [0, 3, 7]  # or ["col_a", "col_d", "col_h"]

train_pool = Pool(X_train, y_train, cat_features=cat_features)
val_pool = Pool(X_val, y_val, cat_features=cat_features)

# --- Regression ---
reg = CatBoostRegressor(
    iterations=3000, learning_rate=0.05, depth=6,
    l2_leaf_reg=3.0, random_strength=1.0,
    bagging_temperature=1.0,
    task_type="GPU",  # GPU training support
    early_stopping_rounds=50, verbose=100,
)
reg.fit(train_pool, eval_set=val_pool)

# --- Classification ---
clf = CatBoostClassifier(
    iterations=3000, learning_rate=0.05, depth=6,
    l2_leaf_reg=3.0, random_strength=1.0,
    bagging_temperature=1.0,
    auto_class_weights="Balanced",  # handle imbalance
    task_type="GPU",
    early_stopping_rounds=50, verbose=100,
)
clf.fit(train_pool, eval_set=val_pool)

# --- Minimal setup (strong defaults, no tuning) ---
quick_model = CatBoostClassifier(cat_features=cat_features, verbose=0)
quick_model.fit(X_train, y_train, eval_set=(X_val, y_val))
```

## Recommended Hyperparameters

| Parameter | Range | Notes |
|-----------|-------|-------|
| iterations | 100-5000 | Use early stopping |
| learning_rate | 0.01-0.3 | Auto-set if not specified |
| depth | 4-10 | Symmetric tree depth; 6 is a good default |
| l2_leaf_reg | 1-10 | L2 regularization on leaf values |
| random_strength | 0.5-5 | Randomness for scoring splits |
| bagging_temperature | 0-10 | Controls Bayesian bootstrap intensity; 1 = standard |
| border_count | 32-255 | Number of splits per numerical feature |
| min_data_in_leaf | 1-50 | Minimum samples per leaf |

## When to Use

- Many categorical features (native handling outperforms manual encoding)
- Small-to-medium datasets where overfitting risk is high (ordered boosting helps)
- Need a strong model with minimal hyperparameter tuning (excellent defaults)
- When robustness matters more than squeezing every last millisecond of training time

## When NOT to Use

- Pure numerical features with no categoricals (XGBoost or LightGBM are equally good and potentially faster)
- Very large datasets (>10M rows) where training speed is critical (LightGBM is typically faster)
- Need asymmetric tree structures for finer-grained splits

## Notes

- CatBoost's defaults are strong out of the box; often competitive without any tuning.
- Categorical features should NOT be one-hot encoded before passing to CatBoost; pass raw values and specify `cat_features`.
- `text_features` param handles raw text columns via built-in text processing.
- `random_strength` controls the amount of randomness used when scoring candidate splits, acting as an additional regularizer.
- Feature importance via `model.get_feature_importance()` supports PredictionValuesChange, LossFunctionChange, and ShapValues.
- SHAP values are natively supported: `model.get_feature_importance(type="ShapValues")`.
- For very large data with GPU, set `max_ctr_complexity=1` to reduce memory usage from categorical combinations.
