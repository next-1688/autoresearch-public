"""Baseline: predict the training mean for every row.

Deliberately the weakest honest model — a constant. Its RMSE is roughly the
standard deviation of y, so any model that learns anything should come in clearly
below it. Every experiment starts as a copy of this file.

It also saves `artifacts/model.joblib` and writes `artifacts/infer.py`, which is
what makes the model runnable on rows it has not seen. Keep doing that: the final
held-out score comes from running `infer.py` on features the search never had, so
a model that only ever wrote a submission cannot be scored at the end.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import pandas as pd
from sklearn.dummy import DummyRegressor

#: Everything the model may read. `id` is a key, `y` is the label.
FEATURES = ["x0", "x1", "x2", "x3", "x4"]

INFER_SOURCE = '''"""Load the saved model and predict for whatever features are handed in.

The framework runs this to score the accepted model on held-out rows, so it must
work on any frame with the feature columns — never assume the val file.
"""

import argparse
from pathlib import Path

import joblib
import pandas as pd

FEATURES = ["x0", "x1", "x2", "x3", "x4"]

parser = argparse.ArgumentParser()
parser.add_argument("--features", required=True)
parser.add_argument("--out", required=True)
args = parser.parse_args()

model = joblib.load(Path(__file__).with_name("model.joblib"))
features = pd.read_csv(args.features)
out = Path(args.out)
out.parent.mkdir(parents=True, exist_ok=True)
pd.DataFrame(
    {"id": features["id"], "y_pred": model.predict(features[FEATURES])}
).to_csv(out, index=False)
print(f"wrote {len(features)} predictions to {out}")
'''


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train", required=True)
    parser.add_argument("--val", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    train = pd.read_csv(args.train)
    val = pd.read_csv(args.val)

    model = DummyRegressor(strategy="mean").fit(train[FEATURES], train["y"])
    print(f"train rows: {len(train)}")
    print(f"constant prediction: {float(train['y'].mean()):.6f}")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"id": val["id"], "y_pred": model.predict(val[FEATURES])}).to_csv(
        out, index=False
    )
    print(f"wrote {len(val)} predictions to {out}")

    artifacts = Path("artifacts")
    artifacts.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, artifacts / "model.joblib")
    (artifacts / "infer.py").write_text(INFER_SOURCE, encoding="utf-8")
    print(f"wrote {artifacts / 'model.joblib'} and {artifacts / 'infer.py'}")


if __name__ == "__main__":
    main()
