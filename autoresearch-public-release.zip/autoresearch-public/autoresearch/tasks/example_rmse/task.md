# 示例任务：合成数据回归（RMSE，越小越好）

> 标准模板：五段结构——任务定义 / 优化指标 / 数据 / 代码位置 / 人工先验。
> 本文档是一个可直接运行的合成数据示例，不对应任何实际业务场景。

## 1. 任务定义

给定 5 个合成数值特征 `x0..x4`，预测由合成数据生成器构造的目标值 `y`。

标准表格回归任务，方法自由（模型、特征变换、正则化、集成方式不限）。

候选被接受的条件：**严格优于当前最优模型**（即 RMSE 更小）。

## 2. 优化指标

- 指标: rmse
- 方向: 越小越好

```
rmse = sqrt( mean( (y_pred - y_true)^2 ) )
```

在验证集上计算，逐行等权，无分组、无加权。

## 3. 数据

- 训练数据: `data/train.csv`
- 验证数据: `data/val.csv`

| 文件 | 内容 | 谁能看 |
|---|---|---|
| `data/train.csv` | `id, x0..x4, y` | 你（训练用） |
| `data/val.csv` | `id, x0..x4` | 你（推理用，**没有 y**） |
| 验证集答案 | `id, y` | 供 `eval.py` 评测使用，禁止用于训练 |

**特征含义**：`x0..x4` 是合成数值特征，`y` 是对应的合成回归目标；`id` 仅用于对齐提交，不入模。

`val.csv` 不含 `y` 列，答案独立存放，文件工具不允许读取。文件布局并非操作系统隔离；运行任意代码时仍须遵守禁止读取答案的规则，严格隔离需另设评测环境。

## 4. 代码位置

- baseline 代码: `train.py`
- 训练命令: `{python} train.py --train {train} --val {val} --out {submission}`
- 评测命令: `{python} eval.py --submission {submission} --metrics-out {metrics_out}`

`train.py` 用训练集 `y` 的均值作预测，任何真正学到东西的模型都应明显低于它。

**提交格式**：`./submission/submission.csv`，两列：

```
id,y_pred
0,12.34
1,45.67
```

`id` 必须与 `val.csv` 一一对应，缺行、多行、有 NaN 判为无效。

**交付物**：每个实验还必须产出 `./artifacts/model.joblib`（存盘模型）与 `./artifacts/infer.py`（载入模型、对任意特征表出预测）：

```bash
python artifacts/infer.py --features <特征文件> --out <submission.csv>
```

缺一个就不予接纳：存不下、重载后预测变了的模型无法上线。

## 5. 人工先验

- 训练要快（秒级），把时间花在想法上。
- 均值预测的 RMSE 约等于 `y` 的标准差，这是任何模型的第一个基准。
