"""Generate the synthetic regression data. Run once: `python make_data.py`.

The validation labels go into a directory of their own, not next to the features.
Two reasons, and the second is the one that matters: what the agent is handed
simply does not contain them, so no rule has to be obeyed for the split to hold —
and the agent is told where the features are, which means anything sitting beside
them is one `ls` away from being read. Only `eval.py` knows about `.labels/`.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

DATA_DIR = Path(__file__).parent / "data"
LABELS_DIR = Path(__file__).parent / ".labels"
N_FEATURES = 5
SPLITS = {"train": 4000, "val": 1000}
SEED = 20260810


def main() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    LABELS_DIR.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED)

    # A signal a linear model can partly capture and a tree can capture better:
    # two linear terms, one interaction, one threshold, plus noise. Enough
    # structure that "beat the mean" is easy and "beat a good model" is not.
    weights = rng.normal(size=N_FEATURES)
    offset = 0
    for split, n_rows in SPLITS.items():
        x = rng.normal(size=(n_rows, N_FEATURES))
        y = (
            x @ weights
            + 1.5 * x[:, 0] * x[:, 1]
            + 2.0 * (x[:, 2] > 0.5)
            + rng.normal(scale=0.5, size=n_rows)
            + 10.0
        )
        ids = np.arange(offset, offset + n_rows)
        offset += n_rows

        features = pd.DataFrame(
            {"id": ids, **{f"x{i}": x[:, i] for i in range(N_FEATURES)}}
        )
        truth = pd.DataFrame({"id": ids, "y": y})

        if split == "train":
            features.merge(truth, on="id").to_csv(
                DATA_DIR / "train.csv", index=False
            )
        else:
            features.to_csv(DATA_DIR / f"{split}.csv", index=False)
            truth.to_csv(LABELS_DIR / f"{split}_truth.csv", index=False)
        print(f"{split}: {n_rows} rows, y std={y.std():.4f}")

    print(f"wrote {DATA_DIR} and {LABELS_DIR}")


if __name__ == "__main__":
    main()
