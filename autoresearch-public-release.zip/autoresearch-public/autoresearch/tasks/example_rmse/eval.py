"""Score a submission. Prints `rmse: <value>` for the framework to read.

Run by the framework with cwd = this directory, never from inside an agent's
workspace, so the agent cannot edit its own ruler.

**This script is where the labels live.** Their location is not passed in and
appears in no configuration file: the framework injects the task document into five
agent prompts, and it cannot leak a path it never holds. All it knows is which
submission to read.

The deliverable check is here for the same kind of reason. What makes a model
shippable is this task's rule — the framework would have to be told what a
model looks like for every modality it might run. Violations go out as
`artifact_issues`, which blocks promotion without invalidating a score that is
otherwise real.

Invalid submissions exit non-zero rather than printing a lenient score: a run
that could not really be measured must not compete with runs that could.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

#: Beside this script, not beside the features. Anything sitting next to the data
#: the agent was told about is one `ls` away from being read.
LABELS = Path(__file__).parent / ".labels" / "val_truth.csv"

#: What an experiment must leave behind to be worth promoting. A model that scores
#: well but cannot be reloaded and re-run is not a result.
REQUIRED_ARTIFACTS = ("model.joblib", "infer.py")


def artifact_issues(submission_path: Path) -> list[str]:
    """Deliverable problems in the experiment that produced this submission."""
    artifacts = submission_path.parent.parent / "artifacts"
    issues: list[str] = []
    for name in REQUIRED_ARTIFACTS:
        path = artifacts / name
        if not path.is_file():
            issues.append(f"missing artifacts/{name}")
        elif path.stat().st_size <= 0:
            issues.append(f"empty artifacts/{name}")
    return issues


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--submission", required=True, type=Path)
    parser.add_argument(
        "--metrics-out", type=Path, help="where to write the full metrics JSON"
    )
    args = parser.parse_args()

    try:
        submission = pd.read_csv(args.submission)
    except Exception as exc:
        print(f"error: cannot read submission: {exc}", file=sys.stderr)
        return 1
    truth = pd.read_csv(LABELS)

    missing = {"id", "y_pred"} - set(submission.columns)
    if missing:
        print(f"error: submission missing columns {sorted(missing)}", file=sys.stderr)
        return 1

    if submission["id"].duplicated().any():
        print("error: submission has duplicate ids", file=sys.stderr)
        return 1

    merged = truth.merge(submission, on="id", how="left", validate="one_to_one")
    if len(merged) != len(truth):
        print(
            f"error: expected {len(truth)} rows, matched {len(merged)}", file=sys.stderr
        )
        return 1
    if merged["y_pred"].isna().any():
        n = int(merged["y_pred"].isna().sum())
        print(f"error: {n} ids have no finite prediction", file=sys.stderr)
        return 1
    if not np.isfinite(merged["y_pred"].to_numpy()).all():
        print("error: submission contains non-finite predictions", file=sys.stderr)
        return 1

    error = merged["y_pred"].to_numpy() - merged["y"].to_numpy()
    rmse = float(np.sqrt(np.mean(error**2)))
    issues = artifact_issues(args.submission)

    if args.metrics_out is not None:
        args.metrics_out.parent.mkdir(parents=True, exist_ok=True)
        args.metrics_out.write_text(
            json.dumps(
                {
                    "rmse": rmse,
                    "artifact_issues": issues,
                    "diagnostics": {
                        "rows": int(len(merged)),
                        "mae": float(np.mean(np.abs(error))),
                    },
                },
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )

    for issue in issues:
        print(f"artifact issue: {issue}", file=sys.stderr)
    print(f"rows: {len(merged)}")
    print(f"mae: {float(np.mean(np.abs(error))):.12f}")
    # The line the framework reads. Raw value, no percent sign, last occurrence.
    print(f"rmse: {rmse:.12f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
