# AutoResearch

以信息为中心的多智能体自动科研框架。给定一份任务文档（目标、指标、数据、baseline 代码），框架自主完成：复现 baseline → 提出假设 → 设计并执行实验 / 诊断 → 任务脚本评测 → 沉淀知识 → 循环，直到预算耗尽。

也支持旧版 MLE-bench 比赛 ID 入口，无需为每场比赛编写 `task.md`。见下方「MLE-bench 与消融实验」。

## 架构

一个 Planner 主导每轮循环，其余角色都是它的执行单元：

| 角色 | 职责 |
|---|---|
| Planner | 全局规划：读历史与知识，提出假设，决定本轮动作（实验 / 诊断，并行 / 串行 / 组合），产出并审查计划 |
| Executor | 按计划实现并运行实验，产出交付物，触发受保护评测 |
| AnalysisAgent | 诊断：自行编写代码计算证据（分布、坏例、漂移、稳健性），不产出模型 |
| Summarizer | 把一次实验/诊断压缩成结构化摘要（L1） |
| KnowledgeManager | 汇总本轮摘要为条目化知识（L2，本轮） |
| KnowledgePromoter | 跨轮提炼，形成持久知识（L3，跨轮） |

**通用任务评测流程**：验证集答案存放在任务目录的 `.labels/` 下，由任务自己的 `eval.py` 读取。文件工具拒绝访问 `.labels/`；候选分数由评测命令重新计算。这些措施用于防止误操作，不代表任意 Shell/Python 代码无法访问答案，详见下方安全边界。MLE-bench 使用下文单列的旧版比赛评分流程。

## 运行安全边界

本地 runner 会执行模型生成的代码，**不是操作系统沙箱**。请只在专用容器、虚拟机或独立账户中运行，避免挂载宿主凭证目录、个人文件和生产数据。当前实现不阻止任意代码访问当前账户可读写的文件或网络；文件工具也不防御并发恶意代码替换文件的竞态。

- Bash、Python、baseline 和评测子进程只继承明确允许的计算环境变量（例如 PATH、CUDA 和线程设置）。LLM、搜索及其他服务密钥及代理认证配置不会自动传入；子进程使用工作区内独立的 `.runtime/` home、缓存和临时目录，不自动读取宿主 home 下的配置。完整允许列表见 `runner/environment.py`。
- 文件读写和目录工具检查符号链接的真实目标。写入仅限各自工作目录，并遵守受保护路径规则；读取只允许工作目录、框架明确授权的共享输入/任务数据/知识库，拒绝 `.labels`、`.env`、`.git` 等私有路径。
- 上述限制仅减少凭证意外继承和文件工具越界。任意 Shell/Python 代码仍可能读取磁盘上的 `.env`、进程信息或宿主文件。严格隔离评测答案需要独立执行身份或评测服务，不能只依赖目录布局。
- 对话和执行日志可能包含模型看到的数据及代码输出，分享前应检查内容。

## 快速开始

要求 Python 3.11（`>=3.11,<3.12`），依赖由 uv 管理：

```bash
cd autoresearch
uv sync
```

在项目根目录创建 `.env`（模板见 `.env.example`，已被 .gitignore 忽略）：

| 变量 | 用途 |
|---|---|
| `LLM_API_KEY` | OpenAI 兼容端点的 API Key（必填） |
| `WEB_SEARCH_API_KEY` | web 搜索工具（可选） |

```bash
# 校验任务可运行：跑一次 baseline，无 LLM 调用
uv run autoresearch --task-dir tasks/example_rmse --check-only

# 完整运行（默认 12h 预算）
uv run autoresearch --task-dir tasks/example_rmse
```

## MLE-bench 与消融实验

支持通过比赛 ID 创建任务、读取 MLE-bench Registry 数据与评分接口、加载比赛提示词，
并提供三个可组合的消融开关。比赛运行接入当前 incumbent、API/token 统计与 L3 流程。
本适配保留下文说明的旧版评分流程；与官方 benchmark 协议的差异应在实验报告中注明。

在 Linux x86_64 / Python 3.11 的训练机上，先完成上面的 `uv sync`，配置 `.env`
中的 `LLM_API_KEY`，并把 `config/default_config.yaml` 的模型地址和名称换成可用值。
MLE-bench 按需安装到**同一个** Python 环境：

```bash
# 已有官方 MLE-bench checkout 时直接使用它；否则先执行：
git clone https://github.com/openai/mle-bench.git /path/to/mle-bench

# 以下命令在本项目 autoresearch/ 目录中执行
uv pip install -e /path/to/mle-bench

# 先配置 Kaggle 凭证并在网页接受目标比赛规则，然后下载/准备数据
uv run --no-sync mlebench prepare \
  -c spooky-author-identification --data-dir /data/mle-bench
```

安装额外的本地 MLE-bench 后使用 `uv run --no-sync`，避免 uv 自动同步时移除不在本项目
锁文件内的 MLE-bench 包。安装与数据准备方式参见[官方 README](https://github.com/openai/mle-bench#readme)。
不要把 MLE-bench 源码目录和数据目录混淆：`--bench-dir` 应指向 `prepare --data-dir`
使用的数据根目录，其下是 `<competition-id>/prepared/public/` 等目录。

```bash
# 检查包、比赛 ID、数据和工作区，不调用 LLM，也不启动训练
uv run --no-sync autoresearch --bench mlebench \
  --competition-id spooky-author-identification \
  --bench-dir /data/mle-bench --check-only

# 完整方法：默认最多 2 个并发 Executor
uv run --no-sync autoresearch --bench mlebench \
  --competition-id spooky-author-identification \
  --bench-dir /data/mle-bench --workspace workspace_full_r1

# 消融示例：只保留方案构建/改进
uv run --no-sync autoresearch --bench mlebench \
  --competition-id spooky-author-identification \
  --bench-dir /data/mle-bench \
  --config config/ablation_2_solution_only.yaml \
  --workspace workspace_solution_only_r1
```

`--bench-dir` 优先于 `.env`/环境中的 `MLEBENCH_DATA_DIR`；两者都省略时使用官方
Registry 的默认数据目录。通用任务原有的 `--task-dir` 入口继续可用，两种入口互斥。
`--check-only --check-submission /path/to/submission.csv` 可额外验证同一提交连续评分两次
结果是否一致。未准备好但已有本地原始 zip 的数据可自动完成旧版准备流程；没有本地
zip 时会提示上述 `mlebench prepare` 命令，不会在搜索过程中自动下载。

| 配置文件 | 开关 | 实际效果 |
|---|---|---|
| `default_config.yaml` | 全部 false | 完整方法，Executor 上限保留为 2 |
| `ablation_1_single_executor.yaml` | `single_executor: true` | 全 run 同时最多 1 个 Executor，多个后台批次也共享限额；Analysis 可继续运行 |
| `ablation_2_solution_only.yaml` | `solution_only: true` | 移除 Analysis；移除 EDA-first、独立诊断和独立特征探索指导，保留模型/训练/损失/增强/调参/集成等方案实验 |
| `ablation_3_no_knowledge_mgmt.yaml` | `no_knowledge_mgmt: true` | 移除 Summarizer/KM；不加载、注入、保存或晋升 L2/L3，由 Planner 直接读结果；静态技术卡仍可使用 |

三个开关可在 `ablation:` 下独立组合；也适用于通用任务。示例配置通过 `extends`
继承 `default_config.yaml`。若另有本地模型配置，可创建自己的 YAML，`extends: your.local.yaml`
后再覆盖所需开关。未传 `--method-label` 时根据开关自动生成标签，显式标签只影响命名；
日志同时记录真实开关、实际并发度、启用的组件，避免只改标签却没有消融。

MLE-bench 每次运行的文件保存于：

```text
<workspace>/mlebench/<competition-id>/<timestamp>/
├── input/                     # 只链接 prepared/public，zip 在工作区内展开
├── working/expXXX_*/           # 计划、train.py、提交、模型和逐实验 API 用量
├── working/diag_*/            # 诊断证据
├── accepted/                  # 被接受的模型快照
├── final -> accepted/...      # 最终交付物（含 submission/submission.csv）
├── final_report.json
├── run_metadata.json
├── api_costs.jsonl
├── activity_events.jsonl
└── api_usage_summary.json
```

每种方法、每次独立重复都使用**新的 workspace 根目录**。复用相同目录会允许当前框架
从该比赛之前的最佳快照继续，并在知识管理开启时读入 L3，影响独立比较。首次生成的
baseline 单独计数，候选改进计入 experiments；已有的统计与 CSV 导出命令保持可用。
CSV 另含 benchmark、competition_id、evaluation_protocol、score_split。

**评分口径**：旧实现会在搜索期间用私有答案评分，并把分数用于候选选择；本次恢复
保留该行为，标记为 `evaluation_protocol=mlebench_legacy_test_feedback`、`score_split=test`。
`eval` 默认使用 test，显式 dev 会被拒绝。Planner/Executor 仍应从公开训练集建立本地
验证/CV 做调参。最终报告中的分数是搜索反馈，不能写成独立测试成绩；若比较的基线只
允许最终一次官方评分，需要先统一评测协议。私有答案不链接到 input，也不进入提示词，
但本地 Shell/Python 仍不是强隔离沙箱。

批量准备自己选定的比赛（脚本不内置或猜测论文的 15 个任务）：

```bash
MLEBENCH_DATA_DIR=/data/mle-bench PYTHON=.venv/bin/python \
  bash scripts/mlebench_prepare_ablation.sh leaf-classification spooky-author-identification
```

## 通用任务配置

一个任务就是一个目录：

```
tasks/<name>/
├── task.md        # 任务文档（唯一任务契约）
├── data/          # train / val 数据
└── eval.py        # 评测脚本：持有答案（.labels/）
```

`task.md` 整篇注入 Planner，框架同时从其中带标签的行解析字段：`指标`、`方向`、`训练数据`、`验证数据`、`评测命令` 必填；`baseline代码` 与 `训练命令` 成对可选，缺省时第一轮由框架生成 baseline（`baseline_generation` 模式）。标签中英文皆可，命令支持 `{python}` `{train}` `{val}` `{submission}` `{incumbent}` `{metrics_out}` 占位符。

以 `tasks/example_rmse/`（标准模板，可直接运行）为起点编写新任务，结构与措辞以该模板为准。

外部数据应在独立的准备步骤中物化到本地 `data/`，任务脚本消费已准备好的数据。

## 续跑

```bash
uv run autoresearch --task-dir tasks/example_rmse \
    --incumbent-from workspace/example_rmse/<上次时间戳>/final
```

不指定 `--incumbent-from` 时，同任务的后续 run 自动从历史 `final` 快照中选分数最优者作为初始 incumbent；L3 知识（`workspace/<task>/task_knowledge.json`）跨轮自动加载，无需参数。

## 运行产物

`workspace/<task>/<时间戳>/` 下：

```
run.log / metrics.jsonl / history.jsonl    # 日志与每轮决策历史
knowledge.json                             # L2 本轮知识
llm_conversations.jsonl / api_costs.jsonl  # 对话与费用
accepted/ + final                          # 被接纳的候选与最终快照（续跑入口）
final_report.json                          # 本轮总结
```

## API 用量与实验数量统计

每次完整运行自动在自己的时间戳目录下保存统计。内部每个候选实验保存在
`working/expXXX_名称/` 下。用 `--method-label` 标记论文中的方法或消融版本：

```bash
uv run autoresearch --task-dir tasks/example_rmse --method-label full
```

`--method-label` 只设置报告标签，不改变算法或关闭任何组件。消融使用上面的 `ablation`
开关；不传标签时自动按启用的开关命名。
已有的历史模型与 L3 知识加载行为保持原有设置；是否加载、初始分数、L3 条数会写入元数据。
需要独立冷启动比较时，可为每个方法/重复运行指定一个新的 `--workspace` 根目录。

新增记录：

| 文件 | 内容 |
|---|---|
| `run_metadata.json` | 运行 ID、任务、方法标签、模型、预算、硬件、历史模型和 L3 载入情况、运行状态与最终成绩；不保存服务密钥 |
| `api_costs.jsonl` | 每次框架 LLM 调用的唯一 ID、Agent、阶段、候选实验与执行 ID、成功/失败、耗时、token 和可选估算费用 |
| `activity_events.jsonl` | Agent 开始/结束、规划等待、调用开始、评测和接纳事件 |
| `api_usage_summary.json` | 整次运行、公共开销、各 Agent/阶段/候选实验的汇总，含失败和未结束的调用 |
| `working/<实验>/api_usage.json` | 此候选目录的累计用量、按 Agent 的明细和每次执行的状态；后续 Summarizer 调用也会累加 |

统计口径：

- **调用次数**：每次进入 `BaseLLM.chat()` 计一次，包括框架发起的重试；SDK 内部的 HTTP 重试不单独计数。上下文压缩、诊断、知识维护及运行结束后的 L3 晋升均计入总量。生成代码或评测子进程绕过此入口调用外部模型时，需要自行接入同一记录机制。
- **外部用量**：兼容已有的可选 `subprocess_tokens.jsonl`，在收尾和离线汇总时合并、去重，并用 `externally_reported_calls` 单独标识；没有阶段计时事件的外部调用不能恢复活动时间。
- **Token**：依据服务端返回的 usage，分别累计输入、输出和总量。缓存和推理 token 作为分项，避免重复累加。没有返回的用量标记为 `null`，并增加 `usage_missing_calls`；汇总值是已知用量，`tokens_complete=false` 表示存在缺失。流式中断可能拿不到最终 usage。
- **费用**：默认 `null`，不使用模型名称猜测价格。可在模型配置中填写 `pricing.input_per_million`、`pricing.output_per_million`，以及可选的缓存单价；单位均为 USD/百万 token。有缺失用量或未知价格时，总费用仍为 `null`。
- **完成实验数**：每次 Executor 执行获得有效、有限的评测分数计一次，是否被接纳另列。同一次执行反复评测不增加实验数；同一目录再次启动 Executor 会获得新的执行 ID。使用最后一次评测的有效性，不读取旧执行遗留的分数充数。baseline 复现/生成和诊断单列，同时提供包含 baseline 的完成数。
- **时间**：`wall_clock_seconds` 是本次运行的墙钟时间，包含初始化与收尾。`active_seconds` 是各阶段累计 Agent 活动时间，规划中的子任务派发/等待区间被扣除；并发活动会重叠，所以不能把活动时间相加当作墙钟时间。阶段时间占比以累计活动时间为分母。`revision` 特指知识管理与晋升，角色映射保存在元数据中。
- **中断**：成功、失败或可捕获的中断都会保存汇总。突然终止后，日志里尚无结束记录的调用/任务保留为进行中；`measurement_complete=false` 提醒记录未完整结束，不将未知 token 记成零。

重跑完成后，汇总多个运行目录：

```bash
uv run autoresearch-usage workspace --output reports/usage
# 也可传多个 workspace 或单次运行目录：
uv run autoresearch-usage workspace_full workspace_no_l3 --output reports/usage
```

输出 `runs.csv`（每次完整运行一行）、`phases.csv`（阶段调用/token/时间占比）、
`experiments.csv`（每次候选执行与诊断的状态）。工具从原始 JSONL 重新汇总，
即使缓存的汇总 JSON 未及时刷新，也能恢复已落盘的数据；不会补估缺失 token。
也可从仓库根运行 `python -m autoresearch.utils.summarize_usage <workspace> --output <目录>`。
不同任务的成绩保留在各自行中，不对不同指标直接求平均。

流式 usage 和 token 明细字段参考 [OpenAI Docs](https://developers.openai.com/api/reference/resources/chat/subresources/completions/streaming-events)。

## 配置

`config/default_config.yaml`：

- `models` / `roles`：模型池与角色到模型的映射（`planner` / `code_generator` / `evaluator` / `analysis` / `distiller` / `promoter`），各角色可独立换模型。
- `budget`：`total_time_seconds`（总预算）、`max_concurrent`（并行实验数）、`analysis_max_concurrent`（并行诊断数）。
- `runner` / `hardware` / `task`：看门狗、计算档位、诊断 agent 开关。
- `web_search`：可选的通用 JSON 搜索接口，协议见下。

搜索接口通过 `Authorization: Bearer <WEB_SEARCH_API_KEY>` 认证，接收
`{"query": "search terms", "max_results": 10}`，返回
`{"results": [{"title": "...", "url": "https://...", "snippet": "..."}]}`。
请配置兼容该协议的 `web_search.url`；未配置地址或密钥时工具返回配置提示。

## 减少执行上下文的重复传输

Executor 优先定位函数或报错位置，用 `file_read(offset, limit)` 读相关代码，
用 `file_edit` 作局部修改。文件读取默认最多200行、12000字符；需要整体结构时
可显式增大 `limit`，单次仍保留100000字符上限。

保存脚本后调用 `python_run` 时优先传路径，例如：

```json
{"path": "train.py", "timeout": 7200}
```

`path` 和 `code` 二选一。原来的内联 `code` 调用继续兼容。路径模式保留 dry-run →
正式执行、看门狗及单次超时限制，并保留入口脚本的 `__file__`、`sys.argv[0]` 和
同目录导入；不会用启动包装代码覆盖入口文件，包括入口叫 `runfile.py` 的情况。

Python 和 Bash 返回精简的首尾输出、退出状态及日志路径，完整捕获结果保存在实验
目录的 `tool_logs/` 下；Python 的 dry-run 和正式执行分别保存日志。必要时按范围读取
完整日志。`stdout.log` / `stderr.log` 仍保留用于现有汇总流程。

上下文压缩统一计算正文和工具参数，并按完整的工具调用/结果组保留近期历史。
摘要失败时使用有界的本地参考摘要；无效压缩仅在上下文继续增长后重试，不会永久
停止自动压缩。原始调用记录和工具日志保持完整。

默认配置已开启 Executor 的32K软预算，压缩目标为16K；三个继承默认配置的消融
配置同步生效。自定义配置也应包含下列设置。设 `soft_limit_tokens: null` 可恢复
原触发阈值；未包含该节且未继承默认配置的旧配置继续使用原阈值：

```yaml
executor_context:
  soft_limit_tokens: 32000
  target_tokens: 16000
  tail_tokens: 8000
  summary_tokens: 2000
```

这是对上下文字符数估算的软预算，不改变模型的真实上下文窗口。系统/任务指令始终
保留；必要指令本身很大时，整理后的上下文可能高于目标值。设置会写入
`run_metadata.json` 的 `executor_context` 字段。Planner、模型、实验总时长、并行数、
知识管理与评估规则沿用本次配置。

修改前后使用相同任务、模型、硬件、时间和并行设置比较输入/输出、缓存分项、
有效实验数与最终成绩。缓存用量为0时还需核对原始 usage：缺少缓存明细不等于
服务端确认未命中缓存；节省比例以实际运行结果为准。

## 许可证

本项目采用 [MIT License](LICENSE) 开源，允许商业使用、修改和分发。分发软件副本或其重要部分时，须保留版权声明和许可声明。软件按原样提供，不提供任何担保；完整条款见许可证。

## 开发验证与构建

在 `autoresearch/` 下运行 `uv run --extra dev pytest -m 'not packaging'` 执行回归测试；`uv run --extra dev pytest -m packaging` 构建并检查发布包。`uv build` 会生成包含许可证、配置、提示词和示例任务的源码包与 wheel。仓库根目录和本目录的 `LICENSE` 内容须保持一致。
