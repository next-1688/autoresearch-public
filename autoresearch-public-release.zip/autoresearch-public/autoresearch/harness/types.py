from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ToolResult:
    success: bool
    output: str
    error: str | None = None


@dataclass
class ToolContext:
    working_dir: Path
    agent_name: str
    iteration: int
    budget_remaining_seconds: float
    # Per-single-run execution cap (seconds) for the owning agent, if any.
    # Set for the executor; None for agents without a python_run cap. Used by
    # python_run to hard-cap a single execution at the per-experiment window.
    execution_timeout: float | None = None


@dataclass
class AgentResult:
    success: bool
    final_response: str
    iterations_used: int
    messages: list[dict] = field(default_factory=list)
    artifacts: dict = field(default_factory=dict)
