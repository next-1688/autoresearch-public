from __future__ import annotations

import logging
from pathlib import Path

from jinja2 import (
    ChoiceLoader,
    Environment,
    FileSystemLoader,
    PrefixLoader,
    select_autoescape,
)

logger = logging.getLogger(__name__)

_TEMPLATE_DIR = Path(__file__).parent.parent / "prompts"


class PromptRenderer:
    """Render role templates; benchmark overrides may extend framework/<role>."""

    def __init__(self, task_prompts_dir: Path | None = None) -> None:
        framework = FileSystemLoader(str(_TEMPLATE_DIR))
        loaders = [FileSystemLoader(str(task_prompts_dir))] if task_prompts_dir else []
        loaders.extend([framework, PrefixLoader({"framework": framework})])
        self._env = Environment(
            loader=ChoiceLoader(loaders),
            autoescape=select_autoescape([]),
            trim_blocks=True,
            lstrip_blocks=True,
            keep_trailing_newline=True,
        )

    def render(self, template_name: str, **kwargs) -> str:
        try:
            template = self._env.get_template(template_name)
            return template.render(**kwargs).strip()
        except Exception as e:
            logger.error("Failed to render template '%s': %s", template_name, e)
            raise
