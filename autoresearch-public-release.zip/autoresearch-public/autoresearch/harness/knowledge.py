from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# Claim lifecycle status (Iris "information management"):
#   active      — the claim holds under its stated scope
#   qualified   — later evidence narrowed the scope; still useful, but bounded
#   invalidated — the claim was contradicted / no longer applies; kept as a
#                 record so the search does not re-propose a refuted direction
VALID_STATUSES = ("active", "qualified", "invalidated")

# Relation types among claims (Iris R_t): a claim may support, conflict with,
# or be associated with another claim.
VALID_RELATIONS = ("support", "conflict", "association")


def _cid_pattern(prefix: str) -> re.Pattern[str]:
    return re.compile(rf"^{re.escape(prefix)}(\d+)$")


@dataclass
class TaskInsight:
    """L2 cross-experiment task-knowledge claim (Iris-style claim record).

    A claim carries a stable id ``cid`` (e.g. "C3", used to reference it in
    relations even as positional order changes), its applicability ``scope``,
    a lifecycle ``status``, and two evidence-pointer sets: ``evidence``
    supports the claim (E+) and ``refuting_evidence`` contradicts/narrows it (E-).
    """

    insight: str  # the claim text
    confidence: float
    scope: str = ""  # applicability scope; "" means general / task-wide
    status: str = "active"  # one of VALID_STATUSES
    evidence: list[str] = field(default_factory=list)  # E+ supporting pointers
    refuting_evidence: list[str] = field(default_factory=list)  # E- pointers
    cid: str = ""  # stable claim id, assigned by the store (e.g. "C3")

    def __post_init__(self) -> None:
        if self.status not in VALID_STATUSES:
            logger.warning("Unknown status %r, defaulting to 'active'", self.status)
            self.status = "active"


@dataclass
class Relation:
    """A directed relation between two claims (Iris R_t)."""

    source: str  # cid
    target: str  # cid
    type: str  # one of VALID_RELATIONS


@dataclass
class InsightOperation:
    """A single incremental operation on the L2 knowledge store."""

    type: str  # "add" | "update" | "invalidate" | "delete"
    target_id: int | None = None  # 1-indexed, for update/invalidate/delete
    insight: str = ""
    confidence: float = 0.5
    scope: str = ""
    status: str = "active"
    evidence: list[str] = field(default_factory=list)
    refuting_evidence: list[str] = field(default_factory=list)


class KnowledgeStore:
    """Stores L2 task-knowledge claims plus relations, injected into Planner prompts.

    Claims are revisable: they carry scope and status so that contradicted
    findings are *invalidated* (retained as a record) rather than silently
    deleted, and narrowed findings are *qualified* rather than dropped. Claims
    also form a relation graph (support / conflict / association) so the
    Planner can see which findings reinforce or contradict one another. This
    mirrors the Iris information-management design, where task knowledge is a
    set of claim records with explicit scope, provenance, status, and relations.

    Uses incremental operations (add/update/invalidate/delete) instead of full
    replacement to prevent accidental data loss from LLM output errors.
    """

    def __init__(
        self,
        max_items: int | None = 8,
        max_invalidated: int = 6,
        *,
        cid_prefix: str = "C",
        label: str = "Cross-Experiment Task Knowledge (L2 Memory)",
    ) -> None:
        """
        ``max_items=None`` leaves active/qualified claims uncapped.

        ``cid_prefix`` namespaces the claim ids. Two stores that both start
        numbering at 1 would hand out the same ids, and because ``Relation``
        references claims *by cid*, merging or displaying them together would
        silently point relations at the wrong claim. The run-local L2 store keeps
        ``C``; a longer-lived store must pass a different prefix (``T`` for the
        task-level L3 store).
        """
        self.insights: list[TaskInsight] = []
        self.relations: list[Relation] = []
        self._max_items = max_items  # cap on active + qualified claims; None = uncapped
        self._max_invalidated = max_invalidated  # cap on retained refuted claims
        self._cid_prefix = cid_prefix
        self._cid_re = _cid_pattern(cid_prefix)
        self._label = label
        self._next_cid = 1  # monotonic counter for stable claim ids

    # --- helpers -----------------------------------------------------------

    @property
    def max_items(self) -> int | None:
        """Cap on active/qualified claims; ``None`` means uncapped.

        Exposed because the knowledge_manager prompt renders its capacity rule from
        it: the same template serves the capped L2 store and the uncapped L3 one, and
        hardcoding "12" told the L3 promoter it had a ceiling it does not have.
        """
        return self._max_items

    def active_count(self) -> int:
        """Number of non-invalidated (active + qualified) claims."""
        return sum(1 for i in self.insights if i.status != "invalidated")

    def get_by_cid(self, cid: str) -> TaskInsight | None:
        for ins in self.insights:
            if ins.cid == cid:
                return ins
        return None

    def _ensure_cids(self) -> None:
        """Assign a stable cid to any claim that lacks one."""
        for ins in self.insights:
            if not ins.cid:
                ins.cid = f"{self._cid_prefix}{self._next_cid}"
                self._next_cid += 1

    def _prune_relations(self) -> None:
        """Drop relations that reference a claim no longer present, and dedupe."""
        live_cids = {i.cid for i in self.insights}
        seen: set[tuple[str, str, str]] = set()
        kept: list[Relation] = []
        for r in self.relations:
            key = (r.source, r.target, r.type)
            if r.source in live_cids and r.target in live_cids and key not in seen:
                seen.add(key)
                kept.append(r)
        self.relations = kept

    def _enforce_capacity(self) -> None:
        """Assign cids, keep each group within its cap, and prune stale relations.

        Active/qualified claims are sorted to the front by confidence; retained
        invalidated claims follow. Each group is capped independently so a burst
        of active claims cannot evict the "do not re-propose" memory, and vice
        versa. IDs (1-indexed into ``self.insights``) therefore keep active
        claims at the low indices. Relations are pruned to surviving claims.

        With ``max_items=None`` the active group is never truncated; the sort is
        still applied so the highest-confidence claims stay at the low indices.
        """
        self._ensure_cids()
        live = [i for i in self.insights if i.status != "invalidated"]
        dead = [i for i in self.insights if i.status == "invalidated"]
        live.sort(key=lambda i: i.confidence, reverse=True)
        dead.sort(key=lambda i: i.confidence, reverse=True)
        kept_live = live if self._max_items is None else live[: self._max_items]
        self.insights = kept_live + dead[: self._max_invalidated]
        self._prune_relations()

    # --- relations ---------------------------------------------------------

    def add_relation(self, source: str, target: str, rel_type: str) -> tuple[bool, str]:
        """Record a relation between two existing claims (by cid)."""
        if rel_type not in VALID_RELATIONS:
            return False, f"Invalid relation {rel_type!r}. Must be one of: {', '.join(VALID_RELATIONS)}"
        if source == target:
            return False, "A claim cannot relate to itself."
        if self.get_by_cid(source) is None:
            return False, f"Claim {source} not found."
        if self.get_by_cid(target) is None:
            return False, f"Claim {target} not found."
        for r in self.relations:
            if r.source == source and r.target == target and r.type == rel_type:
                return False, f"Relation already exists: {source} {rel_type} {target}"
        self.relations.append(Relation(source=source, target=target, type=rel_type))
        return True, f"Linked: {source} {rel_type} {target}"

    def remove_relation(self, source: str, target: str, rel_type: str | None = None) -> tuple[bool, str]:
        """Remove relation(s) between two claims. If rel_type is None, remove all."""
        before = len(self.relations)
        self.relations = [
            r for r in self.relations
            if not (
                r.source == source
                and r.target == target
                and (rel_type is None or r.type == rel_type)
            )
        ]
        removed = before - len(self.relations)
        if removed == 0:
            return False, f"No matching relation between {source} and {target}."
        return True, f"Removed {removed} relation(s) between {source} and {target}."

    # --- mutation ----------------------------------------------------------

    def apply_operations(self, operations: list[InsightOperation]) -> None:
        """Apply incremental operations. Unmentioned claims are preserved."""
        if not operations:
            return

        delete_ids: set[int] = set()

        for op in operations:
            if op.type == "delete" and op.target_id is not None:
                idx = op.target_id - 1  # 1-indexed → 0-indexed
                if 0 <= idx < len(self.insights):
                    delete_ids.add(idx)
                else:
                    logger.warning("L2 delete: target_id %d out of range (1..%d), skipping",
                                   op.target_id, len(self.insights))

            elif op.type == "invalidate" and op.target_id is not None:
                idx = op.target_id - 1
                if 0 <= idx < len(self.insights):
                    ins = self.insights[idx]
                    ins.status = "invalidated"
                    if op.refuting_evidence:
                        # de-duplicate while preserving order
                        merged = ins.refuting_evidence + [
                            e for e in op.refuting_evidence if e not in ins.refuting_evidence
                        ]
                        ins.refuting_evidence = merged
                else:
                    logger.warning("L2 invalidate: target_id %d out of range (1..%d), skipping",
                                   op.target_id, len(self.insights))

            elif op.type == "update" and op.target_id is not None:
                idx = op.target_id - 1
                if 0 <= idx < len(self.insights):
                    # Preserve the stable cid across a full-field replacement.
                    cid = self.insights[idx].cid
                    self.insights[idx] = TaskInsight(
                        insight=op.insight[:800],
                        confidence=op.confidence,
                        scope=op.scope,
                        status=op.status,
                        evidence=op.evidence,
                        refuting_evidence=op.refuting_evidence,
                        cid=cid,
                    )
                else:
                    logger.warning("L2 update: target_id %d out of range (1..%d), skipping",
                                   op.target_id, len(self.insights))

            elif op.type == "add":
                self.insights.append(TaskInsight(
                    insight=op.insight[:800],
                    confidence=op.confidence,
                    scope=op.scope,
                    status=op.status,
                    evidence=op.evidence,
                    refuting_evidence=op.refuting_evidence,
                ))

        if delete_ids:
            self.insights = [ins for i, ins in enumerate(self.insights) if i not in delete_ids]

        self._enforce_capacity()

    # --- rendering ---------------------------------------------------------

    def format_for_prompt(self) -> str:
        """Format task knowledge (claims + relations) for LLM prompts.

        Active/qualified claims are shown with cid, scope, status, and evidence.
        Invalidated claims are listed compactly as a "do not re-propose" tail.
        Relations among present claims are listed at the end.
        """
        if not self.insights:
            return ""

        live = [i for i in self.insights if i.status != "invalidated"]
        dead = [i for i in self.insights if i.status == "invalidated"]

        lines = [f"## {self._label}"]

        if live:
            lines.append("### Active / qualified claims")
            for i, ins in enumerate(live, 1):
                support = ", ".join(ins.evidence[:5]) or "none"
                head = f"{i}. [{ins.cid}] [{ins.confidence:.2f}] ({ins.status}) {ins.insight}"
                lines.append(head)
                detail = f"   scope: {ins.scope or 'general'} | supports: {support}"
                if ins.refuting_evidence:
                    detail += f" | refutes: {', '.join(ins.refuting_evidence[:5])}"
                lines.append(detail)

        if dead:
            lines.append("### Invalidated claims — do NOT re-propose these directions")
            for ins in dead:
                refuted = ", ".join(ins.refuting_evidence[:5]) or "later evidence"
                lines.append(f"- [{ins.cid}] {ins.insight} (refuted by: {refuted})")

        if self.relations:
            lines.append("### Relations between claims")
            for r in self.relations:
                lines.append(f"- {r.source} {r.type} {r.target}")

        return "\n".join(lines)

    # --- persistence -------------------------------------------------------

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "claims": [
                {
                    "cid": i.cid,
                    "insight": i.insight,
                    "confidence": i.confidence,
                    "scope": i.scope,
                    "status": i.status,
                    "evidence": i.evidence,
                    "refuting_evidence": i.refuting_evidence,
                }
                for i in self.insights
            ],
            "relations": [
                {"source": r.source, "target": r.target, "type": r.type}
                for r in self.relations
            ],
            "next_cid": self._next_cid,
            "cid_prefix": self._cid_prefix,
        }
        path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    def load(self, path: Path) -> None:
        if not path.exists():
            return
        data = json.loads(path.read_text(encoding="utf-8"))

        # Backward compatible: the oldest format was a bare list of claims with
        # only insight/confidence/evidence; the previous format was the same
        # list without relations. The current format is a dict with "claims".
        if isinstance(data, list):
            claims_data = data
            relations_data: list = []
            next_cid = None
        else:
            claims_data = data.get("claims", [])
            relations_data = data.get("relations", [])
            next_cid = data.get("next_cid")
            # A file written by a store with a different cid namespace is not
            # ours. Loading it would mix two id spaces into one relation graph,
            # so fail loudly instead of corrupting both. Files predating this
            # field carry no prefix and are treated as the legacy "C" space.
            recorded_prefix = data.get("cid_prefix", "C")
            if recorded_prefix != self._cid_prefix:
                raise ValueError(
                    f"knowledge file {path} was written with cid_prefix="
                    f"{recorded_prefix!r} but this store uses {self._cid_prefix!r}; "
                    "refusing to merge two claim-id namespaces"
                )

        self.insights = [
            TaskInsight(
                insight=item["insight"],
                confidence=item["confidence"],
                scope=item.get("scope", ""),
                status=item.get("status", "active"),
                evidence=item.get("evidence", []),
                refuting_evidence=item.get("refuting_evidence", []),
                cid=item.get("cid", ""),
            )
            for item in claims_data
        ]
        self.relations = [
            Relation(source=r["source"], target=r["target"], type=r["type"])
            for r in relations_data
            if r.get("type") in VALID_RELATIONS
        ]

        # Restore the cid counter so newly added claims never collide with
        # existing ids (whether loaded from a next_cid field or inferred).
        # Only ids in this store's own prefix namespace advance the counter; a
        # foreign-prefixed cid means the file belongs to another store and must
        # not silently drive this one's numbering.
        max_n = 0
        for ins in self.insights:
            m = self._cid_re.match(ins.cid or "")
            if m:
                max_n = max(max_n, int(m.group(1)))
        self._next_cid = max(next_cid or 1, max_n + 1)

        self._enforce_capacity()
