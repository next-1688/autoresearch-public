from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ErrorType(Enum):
    RATE_LIMIT = "rate_limit"
    AUTH = "auth"
    NETWORK = "network"
    SERVER = "server"
    CONTEXT_LENGTH = "context_length"
    UNKNOWN = "unknown"


@dataclass
class RetryStrategy:
    max_retries: int
    base_delay: float
    exponential: bool = True

    def delay_for_attempt(self, attempt: int) -> float:
        if self.exponential:
            return self.base_delay * (2 ** attempt)
        return self.base_delay * (attempt + 1)


RETRY_STRATEGIES: dict[ErrorType, RetryStrategy] = {
    ErrorType.RATE_LIMIT: RetryStrategy(max_retries=5, base_delay=2.0, exponential=True),
    ErrorType.AUTH: RetryStrategy(max_retries=1, base_delay=0.5, exponential=False),
    ErrorType.NETWORK: RetryStrategy(max_retries=3, base_delay=1.0, exponential=False),
    ErrorType.SERVER: RetryStrategy(max_retries=3, base_delay=2.0, exponential=True),
    ErrorType.CONTEXT_LENGTH: RetryStrategy(max_retries=0, base_delay=0.0),
    ErrorType.UNKNOWN: RetryStrategy(max_retries=0, base_delay=0.0),
}


def classify_error(error: Exception) -> ErrorType:
    msg = str(error).lower()
    if "429" in msg or "rate" in msg or "throttl" in msg:
        return ErrorType.RATE_LIMIT
    if "401" in msg or "403" in msg or "unauthorized" in msg or "forbidden" in msg:
        return ErrorType.AUTH
    if "timeout" in msg or "connection" in msg or "connect" in msg:
        return ErrorType.NETWORK
    if "500" in msg or "502" in msg or "503" in msg or "service unavailable" in msg:
        return ErrorType.SERVER
    if "context_length" in msg or "maximum context" in msg or "too long" in msg:
        return ErrorType.CONTEXT_LENGTH
    return ErrorType.UNKNOWN
