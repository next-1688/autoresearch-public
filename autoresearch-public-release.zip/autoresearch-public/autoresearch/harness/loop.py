from __future__ import annotations

import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

from .error import RETRY_STRATEGIES, ErrorType, classify_error
from .telemetry import agent_activity, scheduling_wait
from .types import AgentResult, ToolContext

if TYPE_CHECKING:
    from ..llm.base import BaseLLM, LLMResponse
    from .agent import BaseReActAgent

logger = logging.getLogger(__name__)

FINISH_TOOL_NAME = "finish"

# Marker prefix for the rolling time/budget message injected before every LLM
# call. Used to find-and-replace the previous one so context does not bloat.
BUDGET_MARKER = "[Time & Budget]"


class AgentLoop:
    """Core ReAct (Reasoning + Acting) loop: model call → tool dispatch → repeat."""

    def run(self, agent: BaseReActAgent) -> AgentResult:
        with agent_activity(agent.name, agent.working_dir) as outcome:
            result = self._run(agent)
            outcome["success"] = result.success
            return result

    def _run(self, agent: BaseReActAgent) -> AgentResult:
        messages = agent.build_initial_messages()
        tool_schemas = agent.tool_registry.get_schemas()

        trace_path = self._init_trace(agent, messages)

        iterations_used = 0
        recent_calls: list[tuple[str, str]] = []

        for iteration in range(agent.max_iterations):
            iterations_used = iteration + 1

            budget_remaining = agent.get_budget_remaining()
            if budget_remaining <= 0:
                logger.warning("[%s] time budget exhausted", agent.name)
                result = AgentResult(
                    success=False,
                    final_response="Time budget exhausted",
                    iterations_used=iterations_used,
                    messages=messages,
                )
                self._finalize_trace(trace_path, agent, result)
                return result

            logger.info(
                "[%s] iteration %d/%d (budget: %.0fs remaining)",
                agent.name, iterations_used, agent.max_iterations, budget_remaining,
            )

            if agent.context_manager.should_compress(messages):
                logger.info("[%s] triggering context compression", agent.name)
                messages = agent.context_manager.compress(messages, agent.compression_llm)

            # Inject a fresh time/budget status on EVERY iteration, AFTER
            # compression so it is the most-salient (last) user message and is
            # never eaten by compression. Rolling: the previous one is removed so
            # context does not grow.
            self._inject_budget_status(agent, messages, trace_path, budget_remaining)

            response = self._call_llm(agent.llm, messages, tool_schemas)
            if response is None:
                if agent.context_manager.should_compress(messages) or len(messages) > 10:
                    logger.info("[%s] LLM call failed, attempting compression retry", agent.name)
                    messages = agent.context_manager.compress(messages, agent.compression_llm)
                    response = self._call_llm(agent.llm, messages, tool_schemas)
                if response is None:
                    result = AgentResult(
                        success=False,
                        final_response="LLM call failed after retries",
                        iterations_used=iterations_used,
                        messages=messages,
                    )
                    self._finalize_trace(trace_path, agent, result)
                    return result

            if response.usage:
                estimated = agent.context_manager.estimate_tokens(messages)
                actual = response.usage.get("prompt_tokens", 0)
                if actual > 0:
                    agent.context_manager.calibrate(estimated, actual)

            assistant_msg: dict = {"role": "assistant", "content": response.content or ""}
            if response.tool_calls:
                assistant_msg["tool_calls"] = response.tool_calls
            messages.append(assistant_msg)
            self._append_trace(trace_path, assistant_msg)

            if not response.tool_calls:
                nudge_msg = {
                    "role": "user",
                    "content": (
                        "[System Notice] You replied with text but did not call any tool. "
                        "You must use tools to take actions. "
                        "When you are done, call the `finish` tool with your final result."
                    ),
                }
                messages.append(nudge_msg)
                self._append_trace(trace_path, nudge_msg)
                continue

            ctx = ToolContext(
                working_dir=agent.working_dir,
                agent_name=agent.name,
                iteration=iteration,
                budget_remaining_seconds=agent.get_budget_remaining(),
                execution_timeout=getattr(agent, "execution_timeout", None),
            )

            finish_result = None
            for tc in response.tool_calls:
                fn = tc.get("function", {})
                fn_name = fn.get("name", "")
                fn_args = fn.get("arguments", "{}")
                tc_id = tc.get("id", "")

                with scheduling_wait(agent.name == "planner" and fn_name in {"task_spawn", "task_join"}):
                    tool_result = agent.tool_registry.execute(fn_name, fn_args, ctx)
                tool_msg = {
                    "role": "tool",
                    "tool_call_id": tc_id,
                    "name": fn_name,
                    "content": tool_result.output,
                }
                messages.append(tool_msg)
                self._append_trace(trace_path, tool_msg)

                if fn_name == FINISH_TOOL_NAME:
                    finish_result = tool_result

                recent_calls.append((fn_name, fn_args))
                if len(recent_calls) > 10:
                    recent_calls.pop(0)

            if finish_result is not None:
                agent_result = AgentResult(
                    success=finish_result.success,
                    final_response=finish_result.output,
                    iterations_used=iterations_used,
                    messages=messages,
                )
                self._finalize_trace(trace_path, agent, agent_result)
                return agent_result

            nudge = self._check_repetition(recent_calls)
            if nudge:
                nudge_msg = {"role": "user", "content": nudge}
                messages.append(nudge_msg)
                self._append_trace(trace_path, nudge_msg)

        result = AgentResult(
            success=False,
            final_response=f"Iteration budget exhausted ({agent.max_iterations} iterations)",
            iterations_used=iterations_used,
            messages=messages,
        )
        self._finalize_trace(trace_path, agent, result)
        return result

    def _inject_budget_status(
        self,
        agent: BaseReActAgent,
        messages: list[dict],
        trace_path: Path | None,
        budget_remaining: float,
    ) -> None:
        """Append a fresh, rolling time/budget message before the LLM call.

        Removes the previously-injected budget message (matched by BUDGET_MARKER)
        so exactly one exists and it is always the last, most-salient user
        message. Only ever removes a standalone user message → tool_call/tool
        pairing is never disturbed.
        """
        for i in range(len(messages) - 1, -1, -1):
            m = messages[i]
            if (
                m.get("role") == "user"
                and isinstance(m.get("content"), str)
                and m["content"].startswith(BUDGET_MARKER)
            ):
                messages.pop(i)
                break

        total = agent._budget_total or 0
        elapsed = total - budget_remaining
        elapsed_pct = (elapsed / total * 100) if total > 0 else 0
        lines = [
            f"{BUDGET_MARKER} Current time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}.",
            f"Experiment budget: {elapsed_pct:.0f}% elapsed "
            f"({elapsed:.0f}s / {total:.0f}s used). "
            f"Remaining: {budget_remaining:.0f}s ({budget_remaining / 3600:.1f}h).",
        ]
        cap = getattr(agent, "execution_timeout", None)
        if cap:
            lines.append(
                f"Per-run limit: each `python_run` is capped at {cap:.0f}s "
                f"(~{cap / 60:.0f} min). A single run exceeding this is KILLED and "
                f"its progress is LOST unless you checkpoint incrementally. Size "
                f"each run (folds/epochs/steps) to finish and save within this cap."
            )
        budget_msg = {"role": "user", "content": " ".join(lines)}
        messages.append(budget_msg)
        self._append_trace(trace_path, budget_msg)

    def _call_llm(
        self,
        llm: BaseLLM,
        messages: list[dict],
        tools: list[dict],
    ) -> LLMResponse | None:
        max_attempts = 6
        last_exc = None
        for attempt in range(max_attempts):
            try:
                return llm.chat(messages, tools=tools or None)
            except Exception as e:
                last_exc = e
                error_type = classify_error(e)
                strategy = RETRY_STRATEGIES.get(error_type, RETRY_STRATEGIES[ErrorType.UNKNOWN])

                if error_type == ErrorType.CONTEXT_LENGTH:
                    logger.error("Context length exceeded, cannot retry: %s", e)
                    return None

                if attempt >= strategy.max_retries:
                    break

                delay = strategy.delay_for_attempt(attempt)
                logger.warning(
                    "LLM call failed (attempt %d, %s, delay=%.1fs): %s",
                    attempt + 1, error_type.value, delay, e,
                )
                time.sleep(delay)

        logger.error("LLM call failed after retries: %s", last_exc)
        return None

    def _init_trace(self, agent: BaseReActAgent, initial_messages: list[dict]) -> Path | None:
        """Create trace file outside the agent's working dir to avoid polluting the workspace."""
        try:
            # Walk up to find workspace root (parent of "working/")
            trace_dir = agent.working_dir
            for _ in range(5):
                if trace_dir.name == "working":
                    trace_dir = trace_dir.parent / "traces"
                    break
                trace_dir = trace_dir.parent
            else:
                trace_dir = agent.working_dir.parent / "traces"

            trace_dir.mkdir(parents=True, exist_ok=True)
            # Use working_dir relative name to disambiguate sub-agents
            agent_label = agent.working_dir.name if agent.working_dir.name != "working" else "root"
            trace_path = trace_dir / f"{agent.name}_{agent_label}.jsonl"
            with open(trace_path, "w", encoding="utf-8") as f:
                for msg in initial_messages:
                    f.write(json.dumps(msg, ensure_ascii=False) + "\n")
            return trace_path
        except Exception as e:
            logger.warning("[%s] failed to init trace: %s", agent.name, e)
            return None

    def _append_trace(self, trace_path: Path | None, *messages: dict) -> None:
        """Append messages to the trace file (called after each iteration)."""
        if trace_path is None:
            return
        try:
            with open(trace_path, "a", encoding="utf-8") as f:
                for msg in messages:
                    f.write(json.dumps(msg, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def _finalize_trace(
        self, trace_path: Path | None, agent: BaseReActAgent, result: AgentResult,
    ) -> None:
        """Write a final status line to the trace."""
        if trace_path is None:
            return
        try:
            with open(trace_path, "a", encoding="utf-8") as f:
                f.write(json.dumps({
                    "_meta": "trace_end",
                    "agent": agent.name,
                    "success": result.success,
                    "iterations_used": result.iterations_used,
                    "final_response_preview": result.final_response[:500],
                }, ensure_ascii=False) + "\n")
            logger.info(
                "[%s] trace complete: %s (%d iterations)",
                agent.name, trace_path, result.iterations_used,
            )
        except Exception as e:
            logger.warning("[%s] failed to finalize trace: %s", agent.name, e)

    def _check_repetition(self, recent_calls: list[tuple[str, str]]) -> str | None:
        if len(recent_calls) < 3:
            return None
        last_three = recent_calls[-3:]
        if all(c == last_three[0] for c in last_three):
            name, _ = last_three[0]
            return (
                f"[System Notice] You have called '{name}' with the same arguments "
                f"3 times consecutively. Please try a different approach or tool."
            )
        return None
