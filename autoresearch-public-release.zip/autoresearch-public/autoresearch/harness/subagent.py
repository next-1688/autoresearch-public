from __future__ import annotations

import json
import logging
from concurrent.futures import (
    ThreadPoolExecutor,
    TimeoutError as FuturesTimeoutError,
    as_completed,
)
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import threading
from typing import TYPE_CHECKING, Callable
import uuid

from .types import AgentResult

if TYPE_CHECKING:
    from .agent import BaseReActAgent

logger = logging.getLogger(__name__)

_SUMMARY_AGENT_NAMES = {"summarizer", "analysis"}
_SUMMARY_INDEX_NAME = ".summaries.jsonl"
_RESPONSE_ARTIFACT_LOCK = threading.Lock()


@dataclass
class SubAgentSpec:
    """Specification for spawning a sub-agent."""
    agent_factory: Callable[[], BaseReActAgent]
    label: str = ""


class SubAgentManager:
    """Manages parallel sub-agent lifecycle with ThreadPoolExecutor."""

    def __init__(self, max_workers: int = 3, timeout_per_agent: int = 3600) -> None:
        if max_workers < 1:
            raise ValueError("max_workers must be at least 1")
        self.max_workers = max_workers
        self.timeout_per_agent = timeout_per_agent
        # Multiple background batches share this limit. A pool per batch alone
        # let single_executor=True still run several executors simultaneously.
        self._slots = threading.BoundedSemaphore(max_workers)

    def _batch_deadline(self, n_specs: int) -> float:
        """Wall-clock backstop for a whole spawn_parallel batch.

        Threads can't be force-killed, so this is the only guarantee that
        spawn_parallel returns even if a sub-agent hangs outside a bounded
        subprocess (e.g. a stuck LLM call or GPU-lock starvation). Each
        concurrent wave gets a full per-agent window, plus one spare wave, so
        legitimately long or queued agents are never cut off — it fires only on
        a true hang.
        """
        workers = max(1, min(self.max_workers, n_specs))
        waves = (n_specs + workers - 1) // workers  # ceil division
        return self.timeout_per_agent * (waves + 1)

    def spawn_parallel(self, specs: list[SubAgentSpec]) -> list[AgentResult]:
        if not specs:
            return []

        results: list[AgentResult | None] = [None] * len(specs)
        deadline = self._batch_deadline(len(specs))

        # NOTE: no `with` block — its __exit__ calls shutdown(wait=True), which
        # would re-block on a hung thread and defeat the deadline. We manage the
        # pool manually and shut it down non-blocking in `finally`.
        pool = ThreadPoolExecutor(max_workers=min(self.max_workers, len(specs)))
        future_to_idx = {}
        try:
            for idx, spec in enumerate(specs):
                future = pool.submit(self._run_single, spec)
                future_to_idx[future] = idx

            try:
                for future in as_completed(future_to_idx, timeout=deadline):
                    idx = future_to_idx[future]
                    label = specs[idx].label or f"agent-{idx}"
                    try:
                        result = future.result(timeout=30)
                        results[idx] = result
                        logger.info(
                            "Sub-agent '%s' completed: success=%s, iterations=%d",
                            label, result.success, result.iterations_used,
                        )
                    except (FuturesTimeoutError, TimeoutError):
                        results[idx] = AgentResult(
                            success=False,
                            final_response=f"Sub-agent '{label}' timed out",
                            iterations_used=0,
                        )
                        logger.warning("Sub-agent '%s' timed out", label)
                    except Exception as e:
                        results[idx] = AgentResult(
                            success=False,
                            final_response=f"Sub-agent '{label}' failed: {e}",
                            iterations_used=0,
                        )
                        logger.exception("Sub-agent '%s' failed", label)
            except (FuturesTimeoutError, TimeoutError):
                # Batch deadline hit. Stop waiting on stragglers instead of
                # blocking forever. Abandoned threads keep running in the
                # background (they exit on their own subprocess/LLM timeout);
                # we just stop waiting and report them as failed here.
                stuck = [
                    specs[i].label or f"agent-{i}"
                    for i, r in enumerate(results) if r is None
                ]
                logger.error(
                    "Batch deadline (%.0fs) exceeded; abandoning %d unfinished "
                    "sub-agent(s): %s",
                    deadline, len(stuck), ", ".join(stuck),
                )
                for i, r in enumerate(results):
                    if r is None:
                        label = specs[i].label or f"agent-{i}"
                        results[i] = AgentResult(
                            success=False,
                            final_response=(
                                f"Sub-agent '{label}' abandoned: batch deadline "
                                f"{deadline:.0f}s exceeded (still running in background)."
                            ),
                            iterations_used=0,
                        )
        finally:
            # Cancel queued-but-unstarted futures; never wait on running ones.
            pool.shutdown(wait=False, cancel_futures=True)

        return [r or AgentResult(success=False, final_response="unknown error", iterations_used=0)
                for r in results]

    def _run_single(self, spec: SubAgentSpec) -> AgentResult:
        if not self._slots.acquire(timeout=self.timeout_per_agent):
            return AgentResult(success=False, final_response="Timed out waiting for an available sub-agent slot", iterations_used=0)
        try:
            return self._run_with_slot(spec)
        finally:
            self._slots.release()

    def _run_with_slot(self, spec: SubAgentSpec) -> AgentResult:
        label = spec.label or "unnamed"
        logger.info("Starting sub-agent '%s'", label)
        try:
            agent = spec.agent_factory()
            result = agent.run()
            try:
                result.artifacts.update(_persist_agent_response(agent, result))
            except Exception as e:
                logger.warning(
                    "Failed to persist final response for sub-agent '%s': %s",
                    label, e,
                )
            return result
        except Exception as e:
            logger.exception("Sub-agent '%s' crashed", label)
            return AgentResult(
                success=False,
                final_response=f"Sub-agent crashed: {e}",
                iterations_used=0,
            )


def _summary_root(working_dir: Path) -> Path:
    """Return the run's planner working directory for the summary index."""
    for parent in (working_dir, *working_dir.parents):
        if parent.name == "working":
            return parent
    return working_dir.parent


def _relpath(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def _persist_agent_response(agent: BaseReActAgent, result: AgentResult) -> dict[str, str]:
    """Persist a sub-agent's full final response as a first-class artifact.

    All sub-agents get an immutable, agent-specific final response file.
    Summary-producing agents (summarizer/analysis) additionally write an
    immutable summary file and append a small observability index entry under
    `working/.summaries.jsonl`.
    """
    working_dir = agent.working_dir
    working_dir.mkdir(parents=True, exist_ok=True)
    root = _summary_root(working_dir)
    root.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now(timezone.utc)
    stamp = timestamp.strftime("%Y%m%dT%H%M%S%fZ")
    nonce = uuid.uuid4().hex[:8]

    # Agent-specific immutable names avoid clobbering when executor,
    # summarizer, and/or analysis operate on the same experiment directory or
    # the same plan directory is reused across iterations.
    final_name = f"{agent.name}_final_response_{stamp}_{nonce}.txt"
    final_path = working_dir / final_name
    final_path.write_text(result.final_response or "", encoding="utf-8")

    artifacts: dict[str, str] = {
        "final_response_path": str(final_path),
    }

    if agent.name in _SUMMARY_AGENT_NAMES:
        summary_path = working_dir / f"{agent.name}_summary_{stamp}_{nonce}.txt"
        summary_path.write_text(result.final_response or "", encoding="utf-8")
        artifacts["summary_path"] = str(summary_path)

        record = {
            "timestamp": timestamp.isoformat().replace("+00:00", "Z"),
            "agent": agent.name,
            "working_dir": _relpath(working_dir, root),
            "summary_path": artifacts["summary_path"],
            "final_response_path": artifacts["final_response_path"],
            "success": result.success,
            "iterations_used": result.iterations_used,
        }
        index_path = root / _SUMMARY_INDEX_NAME
        with _RESPONSE_ARTIFACT_LOCK:
            with open(index_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        artifacts["summary_index_path"] = str(index_path)

    return artifacts
