from __future__ import annotations

import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING

from .context import ContextManager
from .loop import AgentLoop
from .prompt import PromptRenderer
from .tool import ToolRegistry
from .types import AgentResult

if TYPE_CHECKING:
    from ..llm.base import BaseLLM


class BaseReActAgent(ABC):
    """Base class for all ReAct agents in the AutoResearch framework."""

    name: str
    template_name: str
    max_iterations: int = 30
    # Per-single-run execution cap (seconds), surfaced to the loop's time
    # injection and into ToolContext. Only the executor sets it; other agents
    # leave it None (no python_run cap to advertise).
    execution_timeout: float | None = None

    def __init__(
        self,
        llm: BaseLLM,
        working_dir: Path,
        *,
        compression_llm: BaseLLM | None = None,
        model_context_length: int = 200_000,
        context_options: dict | None = None,
        prompt_renderer: PromptRenderer | None = None,
        budget_start_time: float | None = None,
        budget_total_seconds: float = 10800,
    ) -> None:
        self.llm = llm
        self.compression_llm = compression_llm or llm
        self.working_dir = working_dir
        self.context_manager = ContextManager(
            model_context_length=model_context_length,
            **(context_options or {}),
        )
        self.prompt_renderer = prompt_renderer or PromptRenderer()
        self.tool_registry = ToolRegistry()
        self._budget_start = budget_start_time or time.time()
        self._budget_total = budget_total_seconds

        self._register_tools()

    @abstractmethod
    def _register_tools(self) -> None:
        """Register agent-specific tools into self.tool_registry."""

    @abstractmethod
    def get_runtime_context(self) -> dict:
        """Collect runtime parameters for Jinja2 template rendering."""

    def get_system_prompt(self) -> str:
        ctx = self.get_runtime_context()
        return self.prompt_renderer.render(self.template_name, **ctx)

    def get_budget_remaining(self) -> float:
        elapsed = time.time() - self._budget_start
        return max(0.0, self._budget_total - elapsed)

    def build_initial_messages(self) -> list[dict]:
        system_prompt = self.get_system_prompt()
        user_message = self.get_user_message()
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ]

    @abstractmethod
    def get_user_message(self) -> str:
        """Return the initial user message for this agent's task."""

    def run(self) -> AgentResult:
        loop = AgentLoop()
        return loop.run(self)
