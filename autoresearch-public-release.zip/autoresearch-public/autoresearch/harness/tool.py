from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod

from .types import ToolContext, ToolResult

logger = logging.getLogger(__name__)


class Tool(ABC):
    name: str
    description: str
    parameters_schema: dict

    @abstractmethod
    def execute(self, args: dict, context: ToolContext) -> ToolResult: ...

    def to_openai_schema(self) -> dict:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters_schema,
            },
        }


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def get_schemas(self) -> list[dict]:
        return [t.to_openai_schema() for t in self._tools.values()]

    def execute(self, name: str, args_json: str, ctx: ToolContext) -> ToolResult:
        tool = self._tools.get(name)
        if tool is None:
            available = ", ".join(sorted(self._tools.keys()))
            return ToolResult(
                success=False,
                output=f"Unknown tool '{name}'. Available tools: {available}",
                error="unknown_tool",
            )

        try:
            args = coerce_tool_args(args_json, tool.parameters_schema)
        except (json.JSONDecodeError, ValueError) as e:
            return ToolResult(
                success=False,
                output=f"Invalid arguments for '{name}': {e}",
                error="invalid_args",
            )

        try:
            return tool.execute(args, ctx)
        except Exception as e:
            logger.warning("Tool '%s' execution error: %s", name, e, exc_info=True)
            return ToolResult(
                success=False,
                output=f"Tool execution error: {e}",
                error="execution_error",
            )


def coerce_tool_args(args_json: str, schema: dict) -> dict:
    """Parse JSON arguments and coerce types to match schema.

    Handles common LLM quirks: stringified ints/bools, bare scalars
    where arrays are expected.
    """
    if not args_json or args_json.strip() == "":
        return {}
    args = json.loads(args_json)
    if not isinstance(args, dict):
        return {"input": args}

    properties = schema.get("properties", {})
    for key, value in list(args.items()):
        if key not in properties:
            continue
        prop = properties[key]
        expected = prop.get("type", "string")

        if expected == "integer" and isinstance(value, str):
            try:
                args[key] = int(value)
            except ValueError:
                pass
        elif expected == "number" and isinstance(value, str):
            try:
                args[key] = float(value)
            except ValueError:
                pass
        elif expected == "boolean" and isinstance(value, str):
            args[key] = value.lower() in ("true", "1", "yes")
        elif expected == "array" and not isinstance(value, list):
            args[key] = [value]

    return args
