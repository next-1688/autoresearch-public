"""An index of the raw evidence a run has produced, for the knowledge roles.

Iris's information management selects evidence before revising knowledge:
``Z_t = SelectEvidence(E_{t+1}, S_{t+1}, K_t)`` — the summaries locate what is
relevant, and the corresponding raw observations are consulted when needed. Our
Knowledge Manager had neither half of that. The planner spawns it with only the
current round's summary paths (two, in practice), so ``S`` was never the
accumulated set, and its prompt told it to read files only when a summary was
truncated, so ``E`` was never reached at all.

The consequence was not subtle. A regularity that only exists *across* experiments
— a diagnostic that never moves while the metric does, an overlap rate that caps
how far any change can move the metric, a noise floor estimated from per-day counts
— is invisible two summaries at a time, and every such finding was missing from L2.

This module supplies the locator. It lists which evidence files exist per
experiment and nothing more: the roles already hold an unrestricted ``file_read``
and a readonly ``bash``, so what they lacked was knowing what is there, not
permission to open it. Deliberately no file contents — a run's summaries run to
~25KB each, so inlining a dozen of them would cost more context than the entire
rest of the prompt, and would decide for the model what is worth reading.
"""

from __future__ import annotations

from pathlib import Path

# Per experiment, the files worth pointing at. Ordered most- to least-decisive so
# the rendered line reads as a drilling order rather than a directory dump.
_EVIDENCE_FILES = (
    "metrics.json",
    "decision.json",
    "artifacts/model_meta.json",
    "stdout.log",
)

# Summaries are timestamped, so they are matched by glob rather than by name.
_SUMMARY_GLOB = "*summary*.txt"


def _describe(exp_dir: Path) -> str | None:
    """One line for one experiment, or None if it holds no evidence yet.

    Never raises. This is called from ``get_runtime_context()`` while building a
    system prompt, so an unreadable directory must cost that one line, not the whole
    agent — a manifest is a convenience, and no finding is worth failing the run for.
    """
    found = []
    for name in _EVIDENCE_FILES:
        try:
            if (exp_dir / name).is_file():
                found.append(name)
        except OSError:
            continue
    # Name the summaries outright: they are timestamped, so a glob pattern would
    # leave the reader to go looking. One is the normal case; more than one means the
    # experiment was re-summarised.
    try:
        summaries = sorted(p.name for p in exp_dir.glob(_SUMMARY_GLOB))
    except OSError:
        summaries = []
    found.extend(summaries[:2])
    if len(summaries) > 2:
        found.append(f"(+{len(summaries) - 2} more summaries)")
    if not found:
        return None
    return f"  {exp_dir.name}/  ->  {', '.join(found)}"


def _section(title: str, root: Path) -> list[str]:
    try:
        if not root.is_dir():
            return []
        children = sorted(d for d in root.iterdir() if not d.name.startswith("."))
    except OSError:
        return []
    lines = []
    for child in children:
        try:
            if not child.is_dir():
                continue
        except OSError:
            continue
        line = _describe(child)
        if line:
            lines.append(line)
    if not lines:
        return []
    return [f"{title} (`{root}`):", *lines]


def build_evidence_manifest(experiments_root: Path) -> str:
    """Index the run's raw evidence, as a prompt-ready block.

    ``experiments_root`` is the directory holding one subdirectory per experiment —
    the ``working/`` dir that both the Knowledge Manager and the promoter already
    receive as their ``working_dir``. The sibling ``accepted/`` is indexed too, so
    the incumbent chain is reachable and not just the latest attempts.

    Returns ``""`` when there is nothing to point at, which the template treats as
    "omit the section" rather than rendering an empty heading.
    """
    experiments_root = Path(experiments_root)
    blocks = _section("Experiments attempted", experiments_root)
    accepted = _section("Accepted / incumbent chain", experiments_root.parent / "accepted")
    if not blocks and not accepted:
        return ""
    parts = [b for b in (blocks, accepted) if b]
    return "\n\n".join("\n".join(p) for p in parts)
