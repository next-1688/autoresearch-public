"""Run-local research accounting. JSONL is the source of truth; JSON is a view.

Calls count BaseLLM.chat attempts (including framework retries, excluding SDK
HTTP retries). Token sums contain only reported usage, never local estimates.
Activity time is accumulated agent time, with planner dispatch/join waits paused;
it is deliberately distinct from run wall-clock time when agents overlap.
"""

from __future__ import annotations

import contextvars
import json
import logging
import math
import os
import threading
import time
import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)
PHASES = {
    "planner": "planning",
    "analysis": "epistemic_actions",
    "executor": "interventions",
    "summarizer": "summarization",
    "knowledge_manager": "revision",
    "knowledge_promoter": "revision",
}
CALL_SCOPE = (
    "BaseLLM.chat attempts; framework retries included; SDK HTTP retries excluded"
)


def timestamp() -> str:
    return datetime.now(UTC).isoformat()


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        temporary.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    records = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
            if not isinstance(record, dict):
                raise TypeError("expected an object")
            records.append(record)
        except (ValueError, TypeError):
            logger.warning("Ignoring invalid JSONL row %s:%d", path, number)
    return records


def usage_fields(usage: dict, input_includes_cache: bool = True) -> dict:
    def count(key: str) -> int | None:
        value = usage.get(key)
        return (
            value
            if isinstance(value, int) and not isinstance(value, bool) and value >= 0
            else None
        )

    ti, to = count("prompt_tokens"), count("completion_tokens")
    cr, cw = count("cache_read_input_tokens"), count("cache_creation_input_tokens")
    if ti is not None and not input_includes_cache:
        ti += (cr or 0) + (cw or 0)
    total = count("total_tokens")
    if ti is not None and to is not None:
        # Cache/reasoning counts are breakdowns, not additional output tokens.
        total = total if input_includes_cache and total is not None else ti + to
    return {
        "input_tokens": ti,
        "output_tokens": to,
        "total_tokens": total,
        "cache_read_tokens": cr,
        "cache_creation_tokens": cw,
        "reasoning_tokens": count("reasoning_tokens"),
        "usage_status": "reported"
        if ti is not None and to is not None
        else "partial"
        if usage
        else "missing",
    }


def aggregate_calls(records: list[dict]) -> dict:
    result: dict[str, Any] = {
        "calls": len(records),
        "successful_calls": 0,
        "failed_calls": 0,
        "in_progress_calls": 0,
        "usage_missing_calls": 0,
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "cache_read_tokens": 0,
        "cache_creation_tokens": 0,
        "reasoning_tokens": 0,
        "llm_elapsed_seconds": 0.0,
        "known_cost": 0.0,
        "cost_incomplete_calls": 0,
    }
    for record in records:
        status = record.get("status", "succeeded")
        key = {"succeeded": "successful_calls", "failed": "failed_calls"}.get(
            status, "in_progress_calls"
        )
        result[key] += 1
        if record.get("usage_status", "reported") != "reported":
            result["usage_missing_calls"] += 1
        for key in (
            "input_tokens",
            "output_tokens",
            "cache_read_tokens",
            "cache_creation_tokens",
            "reasoning_tokens",
        ):
            result[key] += record.get(key) or 0
        total = record.get("total_tokens")
        result["total_tokens"] += (
            total
            if total is not None
            else (
                (record.get("input_tokens") or 0) + (record.get("output_tokens") or 0)
            )
        )
        result["llm_elapsed_seconds"] += record.get("elapsed_seconds") or 0
        cost = record.get("call_cost")
        if cost is None:
            result["cost_incomplete_calls"] += 1
        else:
            result["known_cost"] += cost
    result["tokens_complete"] = result["usage_missing_calls"] == 0
    result["externally_reported_calls"] = sum(
        bool(r.get("external_source")) for r in records
    )
    result["total_cost"] = (
        round(result["known_cost"], 6) if result["cost_incomplete_calls"] == 0 else None
    )
    # Compatibility with the existing per-agent/per-experiment cost logger.
    result["cost"] = result["total_cost"]
    return result


def external_usage_records(path: Path, epoch: float, monotonic: float) -> list[dict]:
    """Adapt the pre-existing optional subprocess usage log without estimating usage."""
    records = []
    for index, record in enumerate(read_jsonl(path)):
        identifier = (
            record.get("call_id")
            or uuid.uuid5(
                uuid.NAMESPACE_URL,
                f"{path.name}:{index}:{json.dumps(record, sort_keys=True)}",
            ).hex
        )
        ti, to = record.get("input_tokens"), record.get("output_tokens")
        records.append(
            {
                **record,
                "call_id": str(identifier),
                "external_source": path.name,
                "agent": record.get("agent", "external"),
                "experiment": record.get("experiment", "root"),
                "phase": record.get("phase", PHASES.get(record.get("agent"), "other")),
                "status": record.get("status", "succeeded"),
                "usage_status": record.get(
                    "usage_status",
                    "reported" if ti is not None and to is not None else "missing",
                ),
                "ended_epoch": record.get("ended_epoch", epoch),
                "ended_monotonic": record.get("ended_monotonic", monotonic),
            }
        )
    return records


@dataclass(frozen=True)
class UsageContext:
    agent: str = "unknown"
    experiment: str = "root"
    phase: str = "other"
    activity_id: str | None = None
    attempt_id: str | None = None
    recorder: UsageRecorder | None = None


_context: contextvars.ContextVar[UsageContext | None] = contextvars.ContextVar(
    "usage_context", default=None
)
_recorder: UsageRecorder | None = None


def current_context() -> UsageContext:
    return _context.get() or UsageContext()


def set_context_tags(agent: str, experiment: str = "root") -> None:
    _context.set(UsageContext(agent, experiment, PHASES.get(agent, "other")))


def get_recorder(working_dir: Path | None = None) -> UsageRecorder | None:
    recorder = current_context().recorder or _recorder
    if recorder is not None and working_dir is not None:
        try:
            working_dir.resolve().relative_to(recorder.root)
        except ValueError:
            return None
    return recorder


def set_recorder(recorder: UsageRecorder | None) -> None:
    global _recorder
    _recorder = recorder


class UsageRecorder:
    def __init__(self, root: Path, metadata: dict | None = None):
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.metadata = {
            "schema_version": 1,
            "run_id": uuid.uuid4().hex,
            "started_at": timestamp(),
            "started_epoch": time.time(),
            "status": "running",
            "call_count_scope": CALL_SCOPE,
            "token_scope": "provider-reported usage; missing usage is unknown",
            "phase_definition": PHASES,
            "activity_time_definition": "summed agent time excluding planner task_spawn/task_join waits; overlapping agents accumulate",
            **(metadata or {}),
        }
        self.calls: dict[str, dict] = {}
        self.activities: dict[str, dict] = {}
        self.last_epoch = self.metadata["started_epoch"]
        self.last_monotonic = time.perf_counter()
        self.update_metadata()

    def _append(self, filename: str, record: dict) -> None:
        with (self.root / filename).open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
            handle.flush()

    def update_metadata(self, **fields) -> None:
        with self.lock:
            self.metadata.update(fields)
            atomic_json(self.root / "run_metadata.json", self.metadata)
            self._publish()

    def _apply_event(self, event: dict) -> None:
        self.last_epoch = max(self.last_epoch, event["epoch"])
        monotonic = event.get("monotonic", event["epoch"])
        self.last_monotonic = max(self.last_monotonic, monotonic)
        kind = event["event"]
        identifier = event.get("activity_id")
        if kind == "llm_call_started":
            self.calls[event["call_id"]] = {
                **event,
                "status": "running",
                "usage_status": "missing",
            }
        elif kind == "activity_started":
            self.activities[identifier] = {
                **event,
                "status": "running",
                "active_seconds": 0.0,
                "active_since": monotonic,
                "evaluation_count": 0,
                "completed": False,
                "accepted": False,
            }
        elif identifier in self.activities:
            activity = self.activities[identifier]
            if kind in ("activity_paused", "activity_finished"):
                since = activity.get("active_since")
                if since is not None:
                    activity["active_seconds"] += max(0, monotonic - since)
                activity["active_since"] = None
            if kind == "activity_resumed":
                activity["active_since"] = monotonic
            elif kind == "activity_finished":
                activity.update(status=event["status"], ended_epoch=event["epoch"])
            elif kind == "evaluation":
                activity["evaluation_count"] += 1
                score = event.get("score")
                activity["completed"] = (
                    bool(event.get("valid"))
                    and isinstance(score, (int, float))
                    and math.isfinite(score)
                )
                activity["last_score"] = score
            elif kind == "decision":
                activity["accepted"] = bool(event.get("accepted"))

    def event(self, event: str, **fields) -> None:
        context = current_context()
        record = {
            "event": event,
            "timestamp": timestamp(),
            "epoch": time.time(),
            "monotonic": time.perf_counter(),
            "run_id": self.metadata["run_id"],
            "agent": context.agent,
            "experiment": context.experiment,
            "phase": context.phase,
            "activity_id": context.activity_id,
            "attempt_id": context.attempt_id,
            **fields,
        }
        try:
            with self.lock:
                self._append("activity_events.jsonl", record)
                self._apply_event(record)
                self._publish(record.get("experiment"))
        except Exception:
            logger.warning("Failed to persist research activity", exc_info=True)

    def record_call(self, record: dict) -> None:
        try:
            with self.lock:
                self._append("api_costs.jsonl", record)
                self.calls[record["call_id"]] = record
                self.last_epoch = max(self.last_epoch, record["ended_epoch"])
                self.last_monotonic = max(
                    self.last_monotonic, record["ended_monotonic"]
                )
                self._publish(record.get("experiment"))
        except Exception:
            logger.warning("Failed to persist API usage", exc_info=True)

    def import_usage(self, path: Path) -> None:
        for record in external_usage_records(
            path, self.last_epoch, self.last_monotonic
        ):
            with self.lock:
                if record["call_id"] not in self.calls:
                    record.setdefault("run_id", self.metadata["run_id"])
                    self.record_call(record)

    def summary(self, *, live: bool = True) -> dict:
        with self.lock:
            records = list(self.calls.values())
            result = {**aggregate_calls(records), "metadata": dict(self.metadata)}
            for group, field in (
                ("by_agent", "agent"),
                ("by_experiment", "experiment"),
                ("by_phase", "phase"),
            ):
                keys = {record.get(field, "other") for record in records}
                result[group] = {
                    key: aggregate_calls(
                        [r for r in records if r.get(field, "other") == key]
                    )
                    for key in sorted(keys)
                }
            running = live and self.metadata["status"] == "running"
            now = time.time() if running else self.last_epoch
            now_monotonic = time.perf_counter() if running else self.last_monotonic
            activities = []
            for activity in self.activities.values():
                snapshot = dict(activity)
                since = snapshot.pop("active_since", None)
                if since is not None:
                    snapshot["active_seconds"] += max(0, now_monotonic - since)
                activities.append(snapshot)
            for activity in activities:
                phase = result["by_phase"].setdefault(
                    activity["phase"], aggregate_calls([])
                )
                phase["active_seconds"] = (
                    phase.get("active_seconds", 0) + activity["active_seconds"]
                )
            total_active = sum(
                p.get("active_seconds", 0) for p in result["by_phase"].values()
            )
            for phase in result["by_phase"].values():
                phase["active_seconds"] = phase.get("active_seconds", 0)
                phase["call_share"] = (
                    phase["calls"] / result["calls"] if result["calls"] else 0
                )
                phase["activity_time_share"] = (
                    phase["active_seconds"] / total_active if total_active else 0
                )
            result["wall_clock_seconds"] = max(
                0,
                max(now, self.metadata.get("ended_epoch", 0))
                - self.metadata["started_epoch"],
            )
            result["cumulative_activity_seconds"] = total_active
            result["activities"] = activities
            result["in_progress_activities"] = sum(
                a["status"] == "running" for a in activities
            )
            result["measurement_complete"] = (
                self.metadata["status"] != "running"
                and result["in_progress_activities"] == 0
                and result["in_progress_calls"] == 0
            )
            for key, selected in (
                (
                    "experiments",
                    [
                        a
                        for a in activities
                        if a["agent"] == "executor"
                        and a.get("mode")
                        not in {"supplied_baseline_reproduction", "baseline_generation"}
                    ],
                ),
                (
                    "baselines",
                    [
                        a
                        for a in activities
                        if a["agent"] == "executor"
                        and a.get("mode")
                        in {"supplied_baseline_reproduction", "baseline_generation"}
                    ],
                ),
                ("diagnostics", [a for a in activities if a["agent"] == "analysis"]),
            ):
                result[key] = {
                    "started": len(selected),
                    "completed": sum(
                        a["status"] != "running"
                        and (
                            a["completed"]
                            if a["agent"] == "executor"
                            else a["status"] == "succeeded"
                        )
                        for a in selected
                    ),
                    "failed": sum(
                        a["status"] != "running"
                        and not (
                            a["completed"]
                            if a["agent"] == "executor"
                            else a["status"] == "succeeded"
                        )
                        for a in selected
                    ),
                    "in_progress": sum(a["status"] == "running" for a in selected),
                    "accepted": sum(a["accepted"] for a in selected),
                    "execution_failed": sum(
                        a["status"] in {"failed", "interrupted"} for a in selected
                    ),
                }
            result["completed_experiments_including_baseline"] = (
                result["experiments"]["completed"] + result["baselines"]["completed"]
            )
            result["public_overhead"] = aggregate_calls(
                [r for r in records if r.get("experiment", "root") == "root"]
            )
            return result

    def _publish(self, experiment: str | None = None) -> None:
        summary = self.summary()
        atomic_json(self.root / "api_usage_summary.json", summary)
        if experiment and experiment != "root" and Path(experiment).name == experiment:
            records = [
                r for r in self.calls.values() if r.get("experiment") == experiment
            ]
            per_experiment = {
                **aggregate_calls(records),
                "run_id": self.metadata["run_id"],
                "experiment": experiment,
                "by_agent": {
                    agent: aggregate_calls(
                        [r for r in records if r.get("agent") == agent]
                    )
                    for agent in sorted({r.get("agent", "unknown") for r in records})
                },
                "activities": [
                    a for a in summary["activities"] if a["experiment"] == experiment
                ],
            }
            atomic_json(
                self.root / "working" / experiment / "api_usage.json", per_experiment
            )

    def finish(self, status: str) -> None:
        self.event("run_finished", run_status=status)
        self.update_metadata(
            status=status, ended_at=timestamp(), ended_epoch=time.time()
        )


def load_run_summary(root: Path) -> dict:
    """Replay persisted facts without writing or extending an interrupted run's time."""
    recorder = UsageRecorder.__new__(UsageRecorder)
    recorder.root = root.resolve()
    recorder.lock = threading.RLock()
    recorder.metadata = json.loads(
        (root / "run_metadata.json").read_text(encoding="utf-8")
    )
    recorder.calls, recorder.activities = {}, {}
    recorder.last_epoch = recorder.metadata["started_epoch"]
    recorder.last_monotonic = 0.0
    for event in read_jsonl(root / "activity_events.jsonl"):
        recorder._apply_event(event)
    for record in read_jsonl(root / "api_costs.jsonl"):
        recorder.calls[record["call_id"]] = record
        recorder.last_epoch = max(recorder.last_epoch, record["ended_epoch"])
        recorder.last_monotonic = max(
            recorder.last_monotonic, record.get("ended_monotonic", 0)
        )
    for record in external_usage_records(
        root / "subprocess_tokens.jsonl", recorder.last_epoch, recorder.last_monotonic
    ):
        recorder.calls.setdefault(record["call_id"], record)
    return recorder.summary(live=False)


@contextmanager
def agent_activity(
    agent: str, working_dir: Path, mode: str | None = None
) -> Iterator[dict]:
    recorder = get_recorder(working_dir)
    context = current_context()
    experiment = working_dir.name if working_dir.name != "working" else "root"
    if (
        context.recorder is recorder
        and context.activity_id
        and context.agent == agent
        and context.experiment == experiment
    ):
        yield {}  # The executor factory owns the wider cleanup/evaluation span.
        return
    activity_id = uuid.uuid4().hex
    attempt_id = activity_id if agent == "executor" else None
    token = _context.set(
        UsageContext(
            agent,
            experiment,
            PHASES.get(agent, "other"),
            activity_id,
            attempt_id,
            recorder,
        )
    )
    outcome: dict = {}
    if recorder:
        recorder.event("activity_started", mode=mode)
    try:
        yield outcome
    except BaseException as exc:
        outcome["status"] = (
            "interrupted" if not isinstance(exc, Exception) else "failed"
        )
        raise
    finally:
        if recorder:
            recorder.event(
                "activity_finished",
                status=outcome.get(
                    "status", "succeeded" if outcome.get("success", False) else "failed"
                ),
            )
        _context.reset(token)


@contextmanager
def scheduling_wait(enabled: bool) -> Iterator[None]:
    recorder = get_recorder()
    if enabled and recorder:
        recorder.event("activity_paused")
    try:
        yield
    finally:
        if enabled and recorder:
            recorder.event("activity_resumed")
