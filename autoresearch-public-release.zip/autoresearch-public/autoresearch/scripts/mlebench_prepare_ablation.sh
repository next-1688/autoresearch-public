#!/usr/bin/env bash
# Prepare only the competition IDs explicitly supplied by the operator.
# Usage: MLEBENCH_DATA_DIR=/data/mlebench bash scripts/mlebench_prepare_ablation.sh ID [ID ...]
# PYTHON can point at the same Python environment that runs autoresearch.
set -euo pipefail

if [[ $# -eq 0 || -z "${MLEBENCH_DATA_DIR:-}" ]]; then
    echo "Usage: MLEBENCH_DATA_DIR=/data/mlebench [PYTHON=.venv/bin/python] bash $0 ID [ID ...]" >&2
    exit 2
fi

python_bin="${PYTHON:-python}"
failed=0
for competition_id in "$@"; do
    if [[ ! "$competition_id" =~ ^[a-zA-Z0-9][a-zA-Z0-9_-]*$ ]]; then
        echo "Invalid competition ID: $competition_id" >&2
        failed=1
        continue
    fi
    if ! "$python_bin" -m mlebench.cli prepare -c "$competition_id" --data-dir "$MLEBENCH_DATA_DIR"; then
        echo "Preparation failed: $competition_id; check credentials, data and competition rules:" >&2
        echo "https://www.kaggle.com/c/$competition_id/rules" >&2
        failed=1
    fi
done
exit "$failed"
