from __future__ import annotations

import inspect
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

from ..harness.telemetry import current_context, get_recorder
from ..harness.tool import Tool
from ..harness.types import ToolContext, ToolResult

if TYPE_CHECKING:
    from ..task.adapter import TaskAdapter


def resolve_run_root(working_dir: Path) -> Path:
    path = working_dir.resolve()
    for parent in (path, *path.parents):
        if parent.name == "working":
            return parent.parent
    return path


def build_metrics_record(
    task: "TaskAdapter",
    working_dir: Path,
    split: str,
    result: dict,
    *,
    agent_name: str = "",
    iteration: int = 0,
) -> dict:
    metric_name = task.metric_name
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "agent_name": agent_name,
        "iteration": iteration,
        "experiment_dir": working_dir.name,
        "experiment_path": str(working_dir.resolve()),
        "split": split,
        "metric": metric_name,
        "score": result.get("score"),
        "valid": bool(result.get("valid")),
        "details": result.get("details", ""),
    }
    # Name the score under the task's own metric so downstream readers can look
    # it up without knowing the task. `score` above stays for generic consumers.
    if metric_name != "score":
        record[metric_name] = result.get(metric_name, result.get("score"))
        record[task.baseline_metric_key] = result.get(task.baseline_metric_key)

    # Whatever the task's evaluator reported, kept. This used to be a
    # whitelist of the slots a task was allowed to fill, which meant every field
    # not on the list was dropped without a word — and the framework has no way
    # to know which field is the decisive one for a task it does not
    # understand. `setdefault` rather than assignment: the keys above are the
    # framework's own judgement (`valid` and `score` above all), and an evaluator
    # must not be able to overwrite the verdict on itself. Same guard as the
    # merge in task/generic.py's `evaluate`.
    for key, value in result.items():
        record.setdefault(key, value)

    return record


def write_metrics_record(
    task: "TaskAdapter",
    working_dir: Path,
    split: str,
    result: dict,
    *,
    agent_name: str = "",
    iteration: int = 0,
) -> dict:
    record = build_metrics_record(
        task,
        working_dir,
        split,
        result,
        agent_name=agent_name,
        iteration=iteration,
    )
    usage_context = current_context()
    record["attempt_id"] = usage_context.attempt_id
    recorder = get_recorder(working_dir)
    if recorder:
        recorder.event("evaluation", score=record.get("score"), valid=record["valid"], split=split)
    run_root = resolve_run_root(working_dir)
    line = json.dumps(record, ensure_ascii=False)

    try:
        run_root.mkdir(parents=True, exist_ok=True)
        with (run_root / "metrics.jsonl").open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

    try:
        if working_dir.resolve() != run_root.resolve():
            working_dir.mkdir(parents=True, exist_ok=True)
            with (working_dir / "metrics.jsonl").open("a", encoding="utf-8") as f:
                f.write(line + "\n")
            (working_dir / "metrics.json").write_text(
                json.dumps(record, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
    except Exception:
        pass

    return record


class TaskEvalTool(Tool):
    name = "eval"
    description = (
        "Evaluate the current task workspace on a split. "
        "Use this instead of shell commands for benchmark evaluation."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "split": {
                "type": "string",
                "description": "Evaluation split to run, usually dev or test.",
                "enum": ["dev", "test"],
            },
        },
    }

    def __init__(self, task: TaskAdapter) -> None:
        self._task = task
        self._supports_limit = "limit" in inspect.signature(task.evaluate).parameters
        # Restrict the split enum to the splits this task allows during
        # iteration (held-out splits like 'test' are hidden from the loop).
        split_schema = {
            "type": "string",
            "description": "Evaluation split to run, usually dev or test.",
            "enum": ["dev", "test"],
        }
        allowed = getattr(task, "allowed_eval_splits", None)
        if allowed:
            split_schema = {
                "type": "string",
                "description": (
                    "Evaluation split to run. Only "
                    f"{sorted(allowed)} are available during optimization."
                ),
                "enum": sorted(allowed),
            }

        properties = {"split": split_schema}
        if self._supports_limit:
            properties["limit"] = {
                "type": "integer",
                "minimum": 1,
                "description": (
                    "Optional positive cap on the number of examples to evaluate. "
                    "Use small limits for cheap diagnostics."
                ),
            }
        self.parameters_schema = {
            "type": "object",
            "properties": properties,
        }

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        split = args.get("split", getattr(self._task, "search_eval_split", "dev"))
        limit = args.get("limit")

        # Enforce split policy: held-out splits (e.g. test) are not available
        # during iteration — they are evaluated externally after optimization.
        allowed = getattr(self._task, "allowed_eval_splits", None)
        if allowed and split not in allowed:
            return ToolResult(
                success=False,
                output=(
                    f"Split '{split}' is not available during optimization. "
                    f"Allowed: {sorted(allowed)}. The test set is held out and is "
                    "only evaluated externally after the run finishes — optimize "
                    "on dev without overfitting to it."
                ),
                error="split_not_allowed",
            )

        if limit is not None:
            if not self._supports_limit:
                return ToolResult(
                    success=False,
                    output="This task's eval tool does not support `limit`.",
                    error="limit_not_supported",
                )
            try:
                limit = int(limit)
            except (TypeError, ValueError):
                return ToolResult(
                    success=False,
                    output="`limit` must be a positive integer.",
                    error="invalid_limit",
                )
            if limit <= 0:
                return ToolResult(
                    success=False,
                    output="`limit` must be a positive integer.",
                    error="invalid_limit",
                )

        env_error = self._check_env(context.working_dir)
        if env_error:
            return ToolResult(success=False, output=env_error, error="missing_env")

        validation = self._task.validate_workspace_changes(context.working_dir)
        if not validation.get("valid", False):
            return ToolResult(
                success=False,
                output=f"Workspace validation failed: {validation.get('details', '')}",
                error="workspace_policy",
            )

        if limit is None:
            result = self._task.evaluate(
                context.working_dir,
                split=split,
                execution_timeout=context.execution_timeout,
            )
        else:
            result = self._task.evaluate(
                context.working_dir,
                split=split,
                limit=limit,
                execution_timeout=context.execution_timeout,
            )
        post_validation = self._task.validate_workspace_changes(context.working_dir)
        if not post_validation.get("valid", False):
            return ToolResult(
                success=False,
                output=f"Workspace validation failed after evaluation: {post_validation.get('details', '')}",
                error="workspace_policy",
            )

        score = result.get("score")
        valid = bool(result.get("valid"))
        details = result.get("details", "")
        self._append_metrics(context, split, result)

        parts = [f"valid: {valid}"]
        if score is not None:
            parts.append(f"score: {score}")
        if details:
            parts.append(f"details:\n{details}")

        return ToolResult(success=valid, output="\n".join(parts))

    def _append_metrics(self, context: ToolContext, split: str, result: dict) -> None:
        write_metrics_record(
            self._task,
            context.working_dir,
            split,
            result,
            agent_name=context.agent_name,
            iteration=context.iteration,
        )

    @staticmethod
    def _resolve_run_root(working_dir: Path) -> Path:
        return resolve_run_root(working_dir)

    def _check_env(self, workspace_dir: Path) -> str:
        env = dict(os.environ)
        env_path = workspace_dir / ".env"
        if env_path.exists():
            for line in env_path.read_text(encoding="utf-8", errors="replace").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                env[key.strip()] = value.strip()

        missing = [
            f"{name} ({desc})"
            for name, desc in self._task.get_env_requirements().items()
            if not env.get(name)
        ]
        if not missing:
            return ""
        return "Missing required environment variables: " + ", ".join(missing)
