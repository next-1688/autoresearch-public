"""Knowledge store CRUD tools — Iris-style revisable task-knowledge claims.

Claims carry a ``scope`` (applicability), a ``status`` (active/qualified/
invalidated), and two evidence sets: supporting (E+) and refuting (E-).
Contradicted claims are *invalidated* (retained as a record) rather than
deleted, so the search does not re-propose a refuted direction.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ..harness.knowledge import VALID_RELATIONS, VALID_STATUSES
from ..harness.tool import Tool
from ..harness.types import ToolContext, ToolResult

if TYPE_CHECKING:
    from ..harness.knowledge import KnowledgeStore

logger = logging.getLogger(__name__)


def _format_insight(idx: int, ins) -> str:
    support = ", ".join(ins.evidence) if ins.evidence else "none"
    refute = ", ".join(ins.refuting_evidence) if ins.refuting_evidence else "none"
    return (
        f"[{idx}] cid={ins.cid} (confidence={ins.confidence:.2f}, status={ins.status}) {ins.insight}\n"
        f"     scope: {ins.scope or 'general'}\n"
        f"     supports (E+): {support}\n"
        f"     refutes  (E-): {refute}"
    )


# Reference to a claim, accepted as either form:
#   - a stable cid ("C4") — preferred, survives re-sorting;
#   - a 1-indexed position ("2" or 2) — legacy, goes stale on the next mutation.
_TARGET_ID_SCHEMA = {
    "type": ["string", "integer"],
    "description": (
        "Stable cid of the claim (e.g. 'C4', shown as cid=... in knowledge_list). "
        "PREFER the cid: claims are re-sorted by confidence on every add/update, "
        "so the bracketed [N] position from an earlier knowledge_list may point at "
        "a different claim by now. A 1-indexed position is still accepted for "
        "compatibility, but is only safe immediately after a knowledge_list."
    ),
}


def _resolve_target(store, raw) -> tuple[int, str]:
    """Resolve a claim reference to its current 1-indexed position.

    Returns ``(position, "")`` on success, or ``(0, error_message)``. Callers pass
    the position into ``InsightOperation.target_id``, which stays 1-indexed so the
    L2/L3 replay path is unchanged.
    """
    n = len(store.insights)
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return 0, "Empty claim reference. Pass a cid (e.g. 'C4') or a 1-indexed position."
        # A bare number as a string is a position, not a cid.
        if not text.lstrip("-").isdigit():
            for pos, ins in enumerate(store.insights, 1):
                if ins.cid.lower() == text.lower():
                    return pos, ""
            known = ", ".join(i.cid for i in store.insights) or "none"
            return 0, f"Claim {raw!r} not found. Known cids: {known}"
        raw = int(text)
    if not isinstance(raw, int) or isinstance(raw, bool):
        return 0, f"Invalid claim reference {raw!r}. Pass a cid (e.g. 'C4') or a 1-indexed position."
    if raw < 1 or raw > n:
        return 0, f"Claim [{raw}] not found. Valid range: 1-{n}"
    return raw, ""


class KnowledgeListTool(Tool):
    name = "knowledge_list"
    description = (
        "List all current task-knowledge claims. Returns numbered claims with "
        "confidence, status (active/qualified/invalidated), scope, and the "
        "supporting (E+) and refuting (E-) evidence sets."
    )
    parameters_schema = {
        "type": "object",
        "properties": {},
    }

    def __init__(self, store: KnowledgeStore) -> None:
        self._store = store

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        if not self._store.insights:
            return ToolResult(
                success=True,
                output="Knowledge store is empty. No claims have been recorded yet.",
            )
        lines = [_format_insight(i + 1, ins) for i, ins in enumerate(self._store.insights)]
        out = (
            f"{len(self._store.insights)} claims "
            f"({self._store.active_count()} active/qualified):\n\n"
            + "\n\n".join(lines)
        )
        if self._store.relations:
            rel_lines = [f"  {r.source} {r.type} {r.target}" for r in self._store.relations]
            out += "\n\nRelations:\n" + "\n".join(rel_lines)
        return ToolResult(success=True, output=out)


class KnowledgeAddTool(Tool):
    name = "knowledge_add"
    description = (
        "Add a new task-knowledge claim. Claims must be comparative findings "
        "across 2+ experiments. Optionally set an applicability scope."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "insight": {
                "type": "string",
                "description": (
                    "The claim text: the finding and what it implies for later rounds. "
                    "Max 800 chars — anything past that is cut from the tail, so put "
                    "the implication before the supporting detail."
                ),
            },
            "confidence": {
                "type": "number",
                "description": "Confidence level 0.0-1.0",
            },
            "evidence": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Supporting evidence (E+). Each entry is an experiment ID/name; when the "
                    "claim rests on a specific artifact, append its path as a provenance pointer, "
                    "e.g. 'exp3:working/exp3/artifacts/confusion.csv'. This lets later roles "
                    "drill from the claim down to the raw evidence."
                ),
            },
            "scope": {
                "type": "string",
                "description": "Applicability scope of the claim (e.g. 'rare classes only'). Omit for a general/task-wide claim.",
            },
        },
        "required": ["insight", "confidence", "evidence"],
    }

    def __init__(self, store: KnowledgeStore) -> None:
        self._store = store

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        from ..harness.knowledge import TaskInsight

        # ``max_items=None`` means uncapped — the L3 task store is built that way,
        # so there is no ceiling to compare against. Guarding on None is not
        # defensive polish: without it every L3 add raised TypeError, and the
        # store could never accept its first claim.
        cap = self._store._max_items
        if cap is not None and self._store.active_count() >= cap:
            return ToolResult(
                success=False,
                output=f"Knowledge store is at capacity ({cap} active/qualified "
                       f"claims). Invalidate a contradicted claim with knowledge_invalidate, or "
                       f"delete a low-value one with knowledge_delete, before adding.",
            )

        insight = TaskInsight(
            insight=args["insight"][:800],
            confidence=args["confidence"],
            scope=args.get("scope", ""),
            status="active",
            evidence=args.get("evidence", []),
        )
        self._store.insights.append(insight)
        self._store._enforce_capacity()
        # Report the stable cid, not the position: _enforce_capacity re-sorts by
        # confidence, so the position printed here is stale as soon as the next
        # claim is added. Reporting it invited later mutations at the wrong index.
        return ToolResult(
            success=True,
            output=(
                f"Added claim cid={insight.cid}: (confidence={insight.confidence:.2f}) "
                f"{insight.insight}\n(Reference it as cid={insight.cid} in "
                f"knowledge_update/invalidate/delete/link.)"
            ),
        )


class KnowledgeUpdateTool(Tool):
    name = "knowledge_update"
    description = (
        "Update an existing claim's text, confidence, scope, status, or evidence. "
        "Reference the claim by its stable cid from knowledge_list (e.g. 'C4'). To "
        "narrow a claim, set its scope and mark status='qualified'. Only fields you "
        "pass are changed."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "insight_id": _TARGET_ID_SCHEMA,
            "insight": {
                "type": "string",
                "description": "Updated claim text (optional)",
            },
            "confidence": {
                "type": "number",
                "description": "Updated confidence (optional)",
            },
            "scope": {
                "type": "string",
                "description": "Updated applicability scope (optional)",
            },
            "status": {
                "type": "string",
                "enum": list(VALID_STATUSES),
                "description": "Updated status: active | qualified | invalidated (optional)",
            },
            "evidence": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Updated supporting evidence (E+) list (optional). Each entry is an "
                    "experiment ID/name, optionally with a provenance path, e.g. "
                    "'exp3:working/exp3/artifacts/confusion.csv'."
                ),
            },
            "refuting_evidence": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Updated refuting evidence (E-) list (optional). Same format as evidence: "
                    "experiment ID/name, optionally with a provenance path to the artifact "
                    "that contradicts or narrows the claim."
                ),
            },
        },
        "required": ["insight_id"],
    }

    def __init__(self, store: KnowledgeStore) -> None:
        self._store = store

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        from ..harness.knowledge import InsightOperation

        insight_id, err = _resolve_target(self._store, args["insight_id"])
        if err:
            return ToolResult(success=False, output=err)
        idx = insight_id - 1

        status = args.get("status")
        if status is not None and status not in VALID_STATUSES:
            return ToolResult(
                success=False,
                output=f"Invalid status {status!r}. Must be one of: {', '.join(VALID_STATUSES)}",
            )

        old = self._store.insights[idx]
        cid = old.cid
        ops = [InsightOperation(
            type="update",
            target_id=insight_id,
            insight=args.get("insight", old.insight),
            confidence=args.get("confidence", old.confidence),
            scope=args.get("scope", old.scope),
            status=status if status is not None else old.status,
            evidence=args.get("evidence", old.evidence),
            refuting_evidence=args.get("refuting_evidence", old.refuting_evidence),
        )]
        self._store.apply_operations(ops)
        return ToolResult(
            success=True,
            output=(
                f"Updated claim cid={cid}: (confidence={ops[0].confidence:.2f}, "
                f"status={ops[0].status}) {ops[0].insight}\n"
                f"(Bracketed [N] positions may have shifted; cid={cid} stays valid.)"
            ),
        )


class KnowledgeInvalidateTool(Tool):
    name = "knowledge_invalidate"
    description = (
        "Mark a claim as invalidated when later evidence contradicts it or it no "
        "longer applies. The claim is RETAINED as a record (not deleted) so the "
        "search does not re-propose the refuted direction. Prefer this over "
        "knowledge_delete for any claim that was informative but proven wrong. "
        "Reference the claim by its stable cid from knowledge_list (e.g. 'C4')."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "insight_id": _TARGET_ID_SCHEMA,
            "refuting_evidence": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Evidence (E-): experiment IDs/names that contradict the claim; append a "
                    "provenance path when a specific artifact shows the contradiction, e.g. "
                    "'exp7:working/exp7/stdout.log'."
                ),
            },
        },
        "required": ["insight_id"],
    }

    def __init__(self, store: KnowledgeStore) -> None:
        self._store = store

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        from ..harness.knowledge import InsightOperation

        insight_id, err = _resolve_target(self._store, args["insight_id"])
        if err:
            return ToolResult(success=False, output=err)

        target = self._store.insights[insight_id - 1]
        claim_text, cid = target.insight, target.cid
        ops = [InsightOperation(
            type="invalidate",
            target_id=insight_id,
            refuting_evidence=args.get("refuting_evidence", []),
        )]
        self._store.apply_operations(ops)
        return ToolResult(
            success=True,
            output=(
                f"Invalidated claim cid={cid} (kept as a do-not-repeat record): "
                f"{claim_text[:100]}\n"
                f"(Bracketed [N] positions may have shifted; cid={cid} stays valid.)"
            ),
        )


class KnowledgeLinkTool(Tool):
    name = "knowledge_link"
    description = (
        "Record a relation between two claims, referenced by their stable cid "
        "(shown as cid=... in knowledge_list). relation is one of: support (the "
        "source reinforces the target), conflict (they contradict), association "
        "(related but neither confirms nor contradicts)."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "source_id": {
                "type": "string",
                "description": "cid of the source claim (e.g. 'C3')",
            },
            "target_id": {
                "type": "string",
                "description": "cid of the target claim (e.g. 'C5')",
            },
            "relation": {
                "type": "string",
                "enum": list(VALID_RELATIONS),
                "description": "support | conflict | association",
            },
        },
        "required": ["source_id", "target_id", "relation"],
    }

    def __init__(self, store: KnowledgeStore) -> None:
        self._store = store

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        ok, msg = self._store.add_relation(
            args["source_id"], args["target_id"], args["relation"]
        )
        return ToolResult(success=ok, output=msg)


class KnowledgeUnlinkTool(Tool):
    name = "knowledge_unlink"
    description = (
        "Remove relation(s) between two claims (by cid). If relation is omitted, "
        "all relations between the pair are removed."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "source_id": {
                "type": "string",
                "description": "cid of the source claim (e.g. 'C3')",
            },
            "target_id": {
                "type": "string",
                "description": "cid of the target claim (e.g. 'C5')",
            },
            "relation": {
                "type": "string",
                "enum": list(VALID_RELATIONS),
                "description": "Optional: only remove this relation type",
            },
        },
        "required": ["source_id", "target_id"],
    }

    def __init__(self, store: KnowledgeStore) -> None:
        self._store = store

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        ok, msg = self._store.remove_relation(
            args["source_id"], args["target_id"], args.get("relation")
        )
        return ToolResult(success=ok, output=msg)


class KnowledgeDeleteTool(Tool):
    name = "knowledge_delete"
    description = (
        "Permanently delete a claim. Use ONLY for duplicates or noise. For a "
        "claim contradicted by evidence, use knowledge_invalidate instead so the "
        "refuted direction is remembered. Reference the claim by its stable cid "
        "from knowledge_list (e.g. 'C4')."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "insight_id": _TARGET_ID_SCHEMA,
        },
        "required": ["insight_id"],
    }

    def __init__(self, store: KnowledgeStore) -> None:
        self._store = store

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        from ..harness.knowledge import InsightOperation

        insight_id, err = _resolve_target(self._store, args["insight_id"])
        if err:
            return ToolResult(success=False, output=err)

        target = self._store.insights[insight_id - 1]
        old_text, cid = target.insight, target.cid
        ops = [InsightOperation(type="delete", target_id=insight_id)]
        self._store.apply_operations(ops)
        return ToolResult(
            success=True,
            output=f"Deleted claim cid={cid}: {old_text[:100]}",
        )
