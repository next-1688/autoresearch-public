"""Python script execution tool with two-layer validation (dry-run → full).

Runs a quick dry-run first
to catch import errors, shape mismatches, and basic pipeline bugs before
committing to a full execution that may take tens of minutes.
"""

from __future__ import annotations

import logging
import threading
from contextlib import contextmanager
from pathlib import Path

from ..harness.tool import Tool
from ..harness.types import ToolContext, ToolResult
from ..utils.tool_output import log_reference, output_preview
from .file import _confine_to_workdir

logger = logging.getLogger(__name__)

MAX_OUTPUT_CHARS = 6000
DEFAULT_DRY_RUN_TIMEOUT = 300
MAX_EXECUTION_TIMEOUT = 14400

# How many python_run executions are in flight right now. Agents run as threads
# in one process, so a plain counter sees all of them.
#
# This exists for one reason: to make an OOM attributable. Experiments share the
# GPU on purpose — the framework no longer serializes them — so a run can die of
# a neighbour's memory rather than its own. An unattributed OOM reads as "my
# model was too big", the agent shrinks it, the summarizer records "the larger
# model was worse", and the planner narrows the search on a result that was
# really a collision. One number in the failure text is what stops that.
_inflight_lock = threading.Lock()
_inflight = 0


@contextmanager
def _inflight_execution():
    """Count this execution while it runs; report what it overlapped."""
    global _inflight
    with _inflight_lock:
        _inflight += 1
        started_beside = _inflight - 1
    try:
        yield lambda: (started_beside, max(_inflight - 1, 0))
    finally:
        with _inflight_lock:
            _inflight -= 1


class PythonRunTool(Tool):
    name = "python_run"
    description = (
        "Execute a saved Python script by path (preferred), or inline code. "
        "Automatically runs a quick dry-run first (DRY_RUN=1) to catch bugs, "
        "then runs the full execution if dry-run passes. "
        "Use this instead of bash for running ML experiments."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Existing script inside the working directory, e.g. train.py. Prefer this after writing/editing the file; do not resend its full code.",
            },
            "code": {
                "type": "string",
                "description": "Inline Python for a new or short script. Omit when path is provided.",
            },
            "timeout": {
                "type": "integer",
                "description": "Full execution timeout in seconds (default: 14400). Executor decides actual duration based on calibration.",
            },
            "dry_run_timeout": {
                "type": "integer",
                "description": "Dry-run timeout in seconds (default: 300). Increase for image tasks that need to load large models.",
            },
            "skip_dry_run": {
                "type": "boolean",
                "description": "Skip dry-run (default: false). Use only for quick non-training scripts.",
            },
        },
        "anyOf": [{"required": ["path"]}, {"required": ["code"]}],
    }

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        code = args.get("code", "")
        timeout = args.get("timeout", MAX_EXECUTION_TIMEOUT)
        dry_run_timeout = args.get("dry_run_timeout", DEFAULT_DRY_RUN_TIMEOUT)
        skip_dry_run = args.get("skip_dry_run", False)

        path = args.get("path")
        if path is not None and code:
            return ToolResult(success=False, output="Provide either path or code, not both.", error="ambiguous_input")
        entry_path: Path | None = None
        if path is not None:
            if not isinstance(path, str) or not path.strip():
                return ToolResult(success=False, output="path must name an existing Python script.", error="invalid_path")
            entry_path = _confine_to_workdir(path, context.working_dir)
            if entry_path is None:
                return ToolResult(success=False, output="Script path must stay inside the working directory and avoid private paths.", error="path_outside_workdir")
            if not entry_path.is_file():
                return ToolResult(success=False, output=f"Script not found: {path}", error="file_not_found")
            try:
                code = entry_path.read_text(encoding="utf-8")
            except (OSError, UnicodeError) as exc:
                return ToolResult(success=False, output=f"Cannot read script: {exc}", error="read_error")
        if not isinstance(code, str) or not code.strip():
            return ToolResult(success=False, output="Provide a script path or nonempty inline code.", error="empty_code")

        # Static syntax check before any execution
        import ast
        try:
            ast.parse(code)
        except SyntaxError as e:
            return ToolResult(
                success=False,
                output=f"[SYNTAX ERROR] Fix before running:\n{e}",
                error="syntax_error",
            )

        # Cap timeout
        timeout = min(timeout, MAX_EXECUTION_TIMEOUT)
        budget = context.budget_remaining_seconds
        if budget > 0 and timeout > budget:
            timeout = max(int(budget) - 30, 30)
        # Hard-cap a single execution at the owning agent's per-run window so the
        # kill window matches the execution_timeout the agent is told about. The
        # capped value flows to runner.run → AR_TIME_BUDGET, which the script reads.
        if context.execution_timeout and context.execution_timeout > 0:
            timeout = min(timeout, int(context.execution_timeout))

        from ..runner.local import LocalRunner
        runner = LocalRunner()

        def run_script(seconds: int, extra_env: dict | None = None):
            kwargs = {"extra_env": extra_env} if extra_env is not None else {}
            if entry_path is not None:
                kwargs["entry_path"] = entry_path
            return runner.run(code if entry_path is None else "", context.working_dir, seconds, **kwargs)

        def log_paths(result) -> list[str]:
            return [
                f"[full {stream}: {log_reference(path, context.working_dir)}]"
                for stream in ("stdout", "stderr")
                if getattr(result, stream, "") and (path := getattr(result, f"{stream}_path", None)) is not None
            ]

        with _inflight_execution() as neighbours:
            # === Layer 1: Dry-run validation ===
            if not skip_dry_run:
                dry_timeout = min(dry_run_timeout, timeout // 3)
                logger.info("[python_run] Dry-run validation (timeout=%ds)", dry_timeout)

                dry_result = run_script(dry_timeout, {"DRY_RUN": "1"})

                if dry_result.exit_code != 0:
                    stderr = output_preview(dry_result.stderr or "", MAX_OUTPUT_CHARS)
                    stdout = output_preview(dry_result.stdout or "", MAX_OUTPUT_CHARS)
                    parts = ["[DRY-RUN FAILED] Fix the bug before running the full experiment."]
                    if stdout:
                        parts.append(f"[stdout]\n{stdout}")
                    if stderr:
                        parts.append(f"[stderr]\n{stderr}")
                    parts.append(f"[exit_code: {dry_result.exit_code}]")
                    parts.append(f"[exec_time: {dry_result.exec_time:.1f}s]")
                    if dry_result.kill_reason:
                        parts.append(f"[killed: {dry_result.kill_reason}]")
                    parts.extend(log_paths(dry_result))
                    return ToolResult(success=False, output="\n".join(parts))

                logger.info("[python_run] Dry-run passed (%.1fs)", dry_result.exec_time)

            # === Layer 2: Full execution ===
            logger.info("[python_run] Full execution (timeout=%ds)", timeout)
            result = run_script(timeout)
            started_beside, still_running = neighbours()

        # Persist logs for SummaryAgent
        if result.stdout:
            (context.working_dir / "stdout.log").write_text(
                result.stdout, encoding="utf-8", errors="replace",
            )
        if result.stderr:
            (context.working_dir / "stderr.log").write_text(
                result.stderr, encoding="utf-8", errors="replace",
            )

        stdout = output_preview(result.stdout or "", MAX_OUTPUT_CHARS)
        stderr = output_preview(result.stderr or "", MAX_OUTPUT_CHARS)

        parts = []
        if stdout:
            parts.append(stdout)
        if stderr:
            parts.append(f"[stderr]\n{stderr}")
        parts.append(f"[exit_code: {result.exit_code}]")
        parts.append(f"[exec_time: {result.exec_time:.1f}s]")
        if result.submission_exists:
            parts.append(f"[submission: {result.submission_path}]")
        if result.kill_reason:
            parts.append(f"[killed: {result.kill_reason}]")
        if result.gpu_peak_memory_mb:
            parts.append(f"[gpu_peak: {result.gpu_peak_memory_mb}MB]")
        parts.extend(log_paths(result))

        # Actionable OOM remediation: if the run ran out of GPU memory, tell the
        # agent to shrink memory and NOT re-run the same config. Without this the
        # agent tends to retry the identical batch size and OOM in a loop.
        oom = bool(result.kill_reason and "OOM" in result.kill_reason) or bool(
            result.stderr and any(
                s in result.stderr
                for s in ("CUDA out of memory", "OutOfMemoryError", "out of memory")
            )
        )
        if oom:
            # Whether the card was shared decides which advice is correct, so say
            # which case this was. Told to shrink after a collision, the agent
            # would conclude its model is too big and hand back a finding about
            # model size that is really a finding about scheduling.
            if started_beside or still_running:
                parts.append(
                    f"[SHARED GPU] {started_beside} other execution(s) were already "
                    f"running when this one started; {still_running} still running "
                    "now. This OOM may be a collision rather than your model being "
                    "too big — do NOT record it as evidence about model size. "
                    "Before retrying, read the ACTUALLY FREE memory "
                    "(torch.cuda.mem_get_info()) and size the batch to that, not to "
                    "the card's total. If free memory is much smaller than the "
                    "card, a neighbour holds it: retry the same configuration later "
                    "rather than shrinking the model."
                )
            else:
                parts.append(
                    "[OOM REMEDIATION] The run exceeded GPU memory and nothing else "
                    "was running, so this is your configuration. Do NOT re-run it "
                    "unchanged — it will OOM again. Reduce memory BEFORE the next "
                    "run: (1) halve the batch size and NEVER set it above your "
                    "calibrated/plan batch; (2) if already small, lower image size, "
                    "use a smaller backbone, or enable gradient checkpointing; "
                    "(3) call torch.cuda.empty_cache() between attempts. Measure "
                    "peak VRAM with one real train step (fwd+bwd+optimizer.step) via "
                    "torch.cuda.max_memory_allocated() and keep it under ~85% of "
                    "free memory."
                )

        # Extract score for structured reporting
        score = self._extract_score(result.stdout or "")
        if score is not None:
            parts.append(f"[extracted_score: {score}]")

        # Auto-diagnostics (pure Python, no LLM)
        diag = self._run_diagnostics(result.stdout or "")
        if diag:
            parts.append(f"[diagnostics: {diag}]")

        return ToolResult(
            success=result.exit_code == 0,
            output="\n".join(parts),
        )

    @staticmethod
    def _run_diagnostics(stdout: str) -> str:
        try:
            from ..utils.diagnostics import parse_stdout_diagnostics
            diag = parse_stdout_diagnostics(stdout)
            if not diag:
                return ""
            parts = []
            if "fold_scores" in diag:
                scores = diag["fold_scores"]
                parts.append(f"fold_scores={[round(s,4) for s in scores]}")
            if "fold_variance" in diag:
                parts.append(f"fold_var={diag['fold_variance']:.6f}")
            if "train_val_gap" in diag:
                parts.append(f"train_val_gap={diag['train_val_gap']:.4f}")
            if "convergence_epoch" in diag:
                parts.append(f"converged_at_epoch={diag['convergence_epoch']}")
            return ", ".join(parts)
        except Exception:
            return ""

    @staticmethod
    def _extract_score(stdout: str) -> float | None:
        from ..utils.metric_extract import extract_score
        return extract_score(stdout)
