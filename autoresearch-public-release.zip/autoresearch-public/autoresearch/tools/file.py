from __future__ import annotations

import os
from pathlib import Path

from ..harness.tool import Tool
from ..harness.types import ToolContext, ToolResult

MAX_READ_CHARS = 100_000
DEFAULT_READ_LINES = 200
DEFAULT_READ_CHARS = 12_000
_PRIVATE_NAMES = frozenset({".labels", ".git", ".runtime", ".ssh", ".aws", ".netrc"})


def _denied_path(path: Path, deny_names: tuple[str, ...]) -> bool:
    return any(
        part in _PRIVATE_NAMES or part in deny_names
        or part == ".env" or (part.startswith(".env.") and part != ".env.example")
        for part in path.parts
    )


def _confine_to_workdir(
    path_str: str,
    working_dir: Path,
    read_root: Path | None = None,
    deny_names: tuple[str, ...] = (),
    allowed_read_paths: tuple[Path, ...] = (),
) -> Path | None:
    """Check real targets, including symlinks, against explicitly allowed paths.

    Extra read paths are granted by framework code, never inferred from links
    found in an experiment. They may name one data file or a shared directory.
    This is a file-tool policy, not a sandbox for concurrent arbitrary code.
    """
    try:
        base = working_dir.resolve()
        root = read_root.resolve() if read_root else base
        p = Path(path_str)
        candidate = p if p.is_absolute() else base / p
        resolved = candidate.resolve()
        if _denied_path(candidate, deny_names) or _denied_path(resolved, deny_names):
            return None
        if resolved == root or root in resolved.parents:
            return resolved
        for allowed in allowed_read_paths:
            if resolved == allowed or (allowed.is_dir() and allowed in resolved.parents):
                return resolved
    except (OSError, RuntimeError, ValueError):
        return None
    return None


class FileReadTool(Tool):
    name = "file_read"
    description = (
        "Read a text file, paginated by default (200 lines / 12000 chars). "
        "Locate a function or error first, then use offset and limit for the relevant range. "
        "Pass an explicit limit for a larger read when whole-file context is necessary."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "File path (relative to working directory or absolute)",
            },
            "offset": {
                "type": "integer",
                "description": "Line number to start reading from (0-based)",
            },
            "limit": {
                "type": "integer",
                "description": "Maximum lines to read (default 200); use explicit ranges after locating relevant code",
            },
        },
        "required": ["path"],
    }

    def __init__(
        self,
        read_root: Path | None = None,
        deny_names: tuple[str, ...] = (),
        allowed_read_paths: tuple[Path, ...] = (),
    ) -> None:
        self._read_root = read_root
        self._deny_names = deny_names
        self._allowed_read_paths = tuple(p.resolve() for p in allowed_read_paths)

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        path = _confine_to_workdir(
            args["path"], context.working_dir, self._read_root, self._deny_names,
            self._allowed_read_paths,
        )
        if path is None:
            return ToolResult(
                success=False,
                output=(
                    "Access denied: path is outside the readable area "
                    f"({self._read_root or context.working_dir})."
                ),
                error="path_outside_workdir",
            )
        if not path.exists():
            return ToolResult(success=False, output=f"File not found: {path}")
        if not path.is_file():
            return ToolResult(success=False, output=f"Not a file: {path}")

        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            return ToolResult(success=False, output=f"Error reading file: {e}")

        lines = content.splitlines(keepends=True)
        offset = args.get("offset", 0)
        limit = args.get("limit", DEFAULT_READ_LINES)
        if limit is None and isinstance(offset, int):
            limit = max(0, len(lines) - offset)
        if not isinstance(offset, int) or offset < 0 or not isinstance(limit, int) or limit < 0:
            return ToolResult(success=False, output="offset and limit must be nonnegative integers.", error="invalid_range")
        selected = lines[offset:offset + limit]
        text = "".join(selected)
        char_limit = MAX_READ_CHARS if "limit" in args else DEFAULT_READ_CHARS
        char_truncated = len(text) > char_limit
        if char_truncated:
            text = text[:char_limit] + "\n... [character cap reached; request a smaller line range]"
        if offset + len(selected) < len(lines):
            next_offset = offset if char_truncated else offset + len(selected)
            text += (
                f"\n[Partial read: {len(lines)} total lines. "
                f"Use file_read with offset={next_offset} and an explicit limit to continue or narrow the range.]"
            )

        return ToolResult(success=True, output=text)

    def _resolve_path(self, path_str: str, working_dir: Path) -> Path:
        p = Path(path_str)
        if p.is_absolute():
            return p
        return working_dir / p


def _path_matches(rel_path: str, policy_path: str) -> bool:
    policy_path = policy_path.rstrip("/")
    return rel_path == policy_path or rel_path.startswith(policy_path + "/")


class FileWriteTool(Tool):
    name = "file_write"
    description = "Write content to a file. Creates the file and parent directories if they don't exist."
    parameters_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "File path (relative to working directory or absolute)",
            },
            "content": {
                "type": "string",
                "description": "Content to write to the file",
            },
        },
        "required": ["path", "content"],
    }

    def __init__(
        self,
        protected_paths: list[str] | None = None,
        editable_paths: list[str] | None = None,
    ) -> None:
        self._protected = protected_paths or []
        self._editable = editable_paths or []

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        path, policy_error = self._checked_path(args["path"], context.working_dir)
        if policy_error:
            return ToolResult(success=False, output=policy_error, error="path_not_writable")

        content = args.get("content", "")

        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return ToolResult(success=True, output=f"Written {len(content)} chars to {path}")
        except Exception as e:
            return ToolResult(success=False, output=f"Error writing file: {e}")

    def _policy_error(self, rel_path: str) -> str:
        for p in self._protected:
            if _path_matches(rel_path, p):
                return f"BLOCKED: '{rel_path}' is a protected path and cannot be modified."
        if self._editable and not any(_path_matches(rel_path, p) for p in self._editable):
            allowed = ", ".join(self._editable)
            return f"BLOCKED: '{rel_path}' is outside editable paths: {allowed}"
        return ""

    def _checked_path(self, path_str: str, working_dir: Path) -> tuple[Path | None, str]:
        path = _confine_to_workdir(path_str, working_dir)
        if path is None:
            return None, "Access denied: writes must stay inside the workspace and avoid private paths."
        raw = self._resolve_path(path_str, working_dir.resolve())
        lexical = Path(os.path.abspath(raw))
        root = working_dir.resolve()
        try:
            lexical_rel = str(lexical.relative_to(root))
        except ValueError:
            # A caller may use the original spelling of a symlinked workspace
            # (e.g. /var vs /private/var on macOS). Preserve its relative policy.
            try:
                lexical_rel = str(lexical.relative_to(Path(os.path.abspath(working_dir))))
            except ValueError:
                return None, "Access denied: write path is outside the workspace."
        for rel in (lexical_rel, str(path.relative_to(root))):
            error = self._policy_error(rel)
            if error:
                return None, error
        # Also protect a directory reached through an alias inside the workspace.
        for protected in self._protected:
            target = (root / protected).resolve()
            if path == target or target in path.parents:
                return None, "Access denied: target is protected."
        return path, ""

    @staticmethod
    def _rel_path(path: Path, working_dir: Path) -> str:
        try:
            return str(path.resolve().relative_to(working_dir.resolve()))
        except ValueError:
            return str(path)

    def _resolve_path(self, path_str: str, working_dir: Path) -> Path:
        p = Path(path_str)
        if p.is_absolute():
            return p
        return working_dir / p


class FileEditTool(Tool):
    name = "file_edit"
    description = (
        "Edit a file by replacing a specific string with a new string. "
        "The old_string must match exactly (including whitespace/indentation)."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "File path",
            },
            "old_string": {
                "type": "string",
                "description": "The exact string to find and replace",
            },
            "new_string": {
                "type": "string",
                "description": "The replacement string",
            },
        },
        "required": ["path", "old_string", "new_string"],
    }

    def __init__(
        self,
        protected_paths: list[str] | None = None,
        editable_paths: list[str] | None = None,
    ) -> None:
        self._protected = protected_paths or []
        self._editable = editable_paths or []

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        old_string = args.get("old_string", "")
        new_string = args.get("new_string", "")

        path, policy_error = FileWriteTool(
            protected_paths=self._protected,
            editable_paths=self._editable,
        )._checked_path(args["path"], context.working_dir)
        if policy_error:
            return ToolResult(success=False, output=policy_error, error="path_not_writable")

        if not path.exists():
            return ToolResult(success=False, output=f"File not found: {path}")

        try:
            content = path.read_text(encoding="utf-8")
        except Exception as e:
            return ToolResult(success=False, output=f"Error reading file: {e}")

        count = content.count(old_string)
        if count == 0:
            return ToolResult(
                success=False,
                output=f"String not found in {path}. Make sure old_string matches exactly.",
            )
        if count > 1:
            return ToolResult(
                success=False,
                output=f"String found {count} times in {path}. Provide more context to make it unique.",
            )

        new_content = content.replace(old_string, new_string, 1)
        path.write_text(new_content, encoding="utf-8")
        return ToolResult(success=True, output=f"Edited {path}: replaced 1 occurrence")

    def _resolve_path(self, path_str: str, working_dir: Path) -> Path:
        p = Path(path_str)
        if p.is_absolute():
            return p
        return working_dir / p


class FileTreeTool(Tool):
    name = "file_tree"
    description = "List the directory tree structure. Shows files and subdirectories."
    parameters_schema = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Directory path (default: working directory)",
            },
            "max_depth": {
                "type": "integer",
                "description": "Maximum depth to traverse (default: 3)",
            },
        },
    }

    def __init__(
        self,
        read_root: Path | None = None,
        deny_names: tuple[str, ...] = (),
        allowed_read_paths: tuple[Path, ...] = (),
    ) -> None:
        self._read_root = read_root
        self._deny_names = deny_names
        self._allowed_read_paths = tuple(p.resolve() for p in allowed_read_paths)

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        path_str = args.get("path", ".")
        p = _confine_to_workdir(
            path_str, context.working_dir, self._read_root, self._deny_names,
            self._allowed_read_paths,
        )
        if p is None:
            return ToolResult(
                success=False,
                output=(
                    "Access denied: path is outside the readable area "
                    f"({self._read_root or context.working_dir})."
                ),
                error="path_outside_workdir",
            )
        max_depth = args.get("max_depth", 3)

        if not p.exists():
            return ToolResult(success=False, output=f"Directory not found: {p}")
        if not p.is_dir():
            return ToolResult(success=False, output=f"Not a directory: {p}")

        lines = []
        self._walk(p, lines, prefix="", depth=0, max_depth=max_depth,
                   working_dir=context.working_dir, seen=set())

        if len(lines) > 500:
            lines = lines[:500]
            lines.append("... (truncated)")

        return ToolResult(success=True, output="\n".join(lines))

    def _walk(
        self, path: Path, lines: list[str], prefix: str, depth: int, max_depth: int,
        working_dir: Path, seen: set[Path],
    ) -> None:
        if depth > max_depth:
            return
        real = path.resolve()
        if real in seen:
            return
        seen.add(real)

        try:
            entries = sorted(path.iterdir(), key=lambda e: (not e.is_dir(), e.name))
        except PermissionError:
            lines.append(f"{prefix}[permission denied]")
            return

        entries = [e for e in entries if _confine_to_workdir(
            str(e), working_dir, self._read_root, self._deny_names,
            self._allowed_read_paths,
        ) is not None]

        for i, entry in enumerate(entries):
            is_last = i == len(entries) - 1
            connector = "└── " if is_last else "├── "
            if entry.is_dir():
                lines.append(f"{prefix}{connector}{entry.name}/")
                if entry.name == "tool_logs":
                    lines[-1] += " (saved execution logs; inspect a returned log path as needed)"
                    continue
                extension = "    " if is_last else "│   "
                self._walk(entry, lines, prefix + extension, depth + 1, max_depth,
                           working_dir, seen)
            else:
                size = ""
                try:
                    s = entry.stat().st_size
                    if s > 1_000_000:
                        size = f" ({s // 1_000_000}MB)"
                    elif s > 1_000:
                        size = f" ({s // 1_000}KB)"
                except OSError:
                    pass
                lines.append(f"{prefix}{connector}{entry.name}{size}")
