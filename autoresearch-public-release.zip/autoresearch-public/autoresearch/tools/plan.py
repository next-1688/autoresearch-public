"""Plan management tools: write, read, and edit experiment plans."""

from __future__ import annotations

import re
from pathlib import Path

from ..harness.tool import Tool
from ..harness.types import ToolContext, ToolResult
from .file import _confine_to_workdir

PLAN_FILENAME = "plan.md"


class PlanWriteTool(Tool):
    name = "plan_write"
    description = (
        "Write an experiment plan to plan.md in the specified directory. "
        "Creates the directory if it doesn't exist. "
        "The plan should contain: hypothesis, approach, expected outcome, and risk notes."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "plan_dir": {
                "type": "string",
                "description": (
                    "Directory name for this plan (relative to working dir). "
                    "Will be created as a subdirectory."
                ),
            },
            "content": {
                "type": "string",
                "description": "The full plan content in markdown format",
            },
        },
        "required": ["plan_dir", "content"],
    }

    _EXP_DIR_RE = re.compile(r"^exp(\d{3})(?:_(.+))?$")

    @classmethod
    def _slugify_semantic(cls, value: str) -> str:
        semantic = Path(str(value or "experiment")).name.strip()
        match = cls._EXP_DIR_RE.match(semantic)
        if match:
            semantic = match.group(2) or "experiment"
        semantic = re.sub(r"[^\w.-]+", "_", semantic, flags=re.UNICODE).strip("._-")
        return semantic or "experiment"

    @classmethod
    def _next_exp_index(cls, working_dir: Path) -> int:
        max_index = 0
        if working_dir.exists():
            for child in working_dir.iterdir():
                if not child.is_dir():
                    continue
                match = cls._EXP_DIR_RE.match(child.name)
                if match:
                    max_index = max(max_index, int(match.group(1)))
        return max_index + 1

    @classmethod
    def _normalize_plan_dir_name(cls, requested_name: str, working_dir: Path) -> str:
        raw_name = Path(str(requested_name or "experiment")).name.strip() or "experiment"
        # Diagnostic plans are not candidate experiments and must retain the
        # prefix the planner prompts use to distinguish their evidence folders.
        if raw_name.startswith("diag_"):
            semantic = cls._slugify_semantic(raw_name)
            candidate, suffix = semantic, 2
            while (working_dir / candidate).exists():
                candidate = f"{semantic}_{suffix}"
                suffix += 1
            return candidate
        match = cls._EXP_DIR_RE.match(raw_name)
        if match and not (working_dir / raw_name).exists():
            return raw_name
        semantic = cls._slugify_semantic(raw_name)
        return f"exp{cls._next_exp_index(working_dir):03d}_{semantic}"

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        requested_plan_dir_name = args.get("plan_dir", "plan_default")
        plan_dir_name = self._normalize_plan_dir_name(requested_plan_dir_name, context.working_dir)
        content = args.get("content", "")

        plan_dir = _confine_to_workdir(plan_dir_name, context.working_dir)
        if plan_dir is None:
            return ToolResult(success=False, output="Plan directory is outside the workspace.")
        plan_path = _confine_to_workdir(str(plan_dir / PLAN_FILENAME), context.working_dir)
        if plan_path is None:
            return ToolResult(success=False, output="Plan file is outside the workspace.")
        plan_dir.mkdir(parents=True, exist_ok=True)

        # Symlink shared resources so executor can access ./input/.
        child_input = plan_dir / "input"
        input_candidates = [context.working_dir / "input", context.working_dir.parent / "input"]
        parent_input = next((p for p in input_candidates if p.exists()), None)
        if parent_input is not None and not child_input.exists():
            try:
                child_input.symlink_to(parent_input.resolve())
            except OSError:
                pass

        try:
            plan_path.write_text(content, encoding="utf-8")
            rename_note = ""
            if plan_dir_name != requested_plan_dir_name:
                rename_note = f"\nNormalized requested plan_dir {requested_plan_dir_name!r} to {plan_dir_name!r}."
            return ToolResult(
                success=True,
                output=(
                    f"Plan written to {plan_path} ({len(content)} chars)"
                    f"{rename_note}\nUse this exact plan_dir for task_spawn: {plan_dir_name}"
                ),
            )
        except Exception as e:
            return ToolResult(success=False, output=f"Error writing plan: {e}")


class PlanReadTool(Tool):
    name = "plan_read"
    description = "Read the plan.md file from a plan directory."
    parameters_schema = {
        "type": "object",
        "properties": {
            "plan_dir": {
                "type": "string",
                "description": "Directory name containing plan.md",
            },
        },
        "required": ["plan_dir"],
    }

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        plan_dir_name = args.get("plan_dir", "")
        plan_path = _confine_to_workdir(str(Path(plan_dir_name) / PLAN_FILENAME), context.working_dir)
        if plan_path is None:
            return ToolResult(success=False, output="Plan file is outside the workspace.")

        if not plan_path.exists():
            return ToolResult(
                success=False,
                output=f"Plan not found at {plan_path}",
            )

        try:
            content = plan_path.read_text(encoding="utf-8")
            return ToolResult(success=True, output=content)
        except Exception as e:
            return ToolResult(success=False, output=f"Error reading plan: {e}")


class PlanEditTool(Tool):
    name = "plan_edit"
    description = "Edit an existing plan.md by replacing a specific string."
    parameters_schema = {
        "type": "object",
        "properties": {
            "plan_dir": {
                "type": "string",
                "description": "Directory name containing plan.md",
            },
            "old_string": {
                "type": "string",
                "description": "The exact string to replace",
            },
            "new_string": {
                "type": "string",
                "description": "The replacement string",
            },
        },
        "required": ["plan_dir", "old_string", "new_string"],
    }

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        plan_dir_name = args.get("plan_dir", "")
        old_string = args.get("old_string", "")
        new_string = args.get("new_string", "")
        plan_path = _confine_to_workdir(str(Path(plan_dir_name) / PLAN_FILENAME), context.working_dir)
        if plan_path is None:
            return ToolResult(success=False, output="Plan file is outside the workspace.")

        if not plan_path.exists():
            return ToolResult(success=False, output=f"Plan not found at {plan_path}")

        try:
            content = plan_path.read_text(encoding="utf-8")
        except Exception as e:
            return ToolResult(success=False, output=f"Error reading plan: {e}")

        if old_string not in content:
            return ToolResult(
                success=False,
                output="String not found in plan. Make sure old_string matches exactly.",
            )

        new_content = content.replace(old_string, new_string, 1)
        plan_path.write_text(new_content, encoding="utf-8")
        return ToolResult(success=True, output=f"Plan edited: {plan_path}")
