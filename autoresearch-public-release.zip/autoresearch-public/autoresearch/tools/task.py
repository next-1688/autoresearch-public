"""Sub-agent spawning and finish tool.

The task tool lets PlannerAgent spawn Executor/Summary/KnowledgeManager sub-agents.
The finish tool lets any agent signal completion with a final result.
"""

from __future__ import annotations

import inspect
import logging
import threading
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Callable

from ..harness.tool import Tool
from ..harness.types import AgentResult, ToolContext, ToolResult
from .file import _confine_to_workdir

if TYPE_CHECKING:
    from ..harness.agent import BaseReActAgent
    from ..harness.subagent import SubAgentManager, SubAgentSpec

logger = logging.getLogger(__name__)


@dataclass
class _BackgroundJob:
    handle: str
    agent_type: str
    specs: list  # list[SubAgentSpec] — kept for labels/formatting
    future: Future = field(repr=False)


class BackgroundJobRegistry:
    """Shared registry backing non-blocking task_spawn + task_join.

    A job is one homogeneous batch (same shape as a single blocking task_spawn)
    whose ``spawn_parallel`` runs on a dispatch thread, so the planner can keep
    working — e.g. launch `analysis` diagnostics while an `executor` experiment
    trains — and collect the results later with ``task_join``. Each batch still
    runs on its own SubAgentManager pool, so executor and analysis overlap on
    their independent concurrency budgets.

    The dispatch threads only *wait* on their batch's agent pool, so a small
    dispatch pool is plenty. Each batch is self-bounded by SubAgentManager's
    deadline, so a job can never hang forever.
    """

    def __init__(self, max_dispatch: int = 8) -> None:
        self._pool = ThreadPoolExecutor(
            max_workers=max_dispatch, thread_name_prefix="bg-dispatch"
        )
        self._jobs: dict[str, _BackgroundJob] = {}
        self._lock = threading.Lock()
        self._counter = 0

    def submit(self, agent_type: str, specs: list, run: Callable[[], list]) -> str:
        """Register a batch running on a dispatch thread; return its handle."""
        with self._lock:
            self._counter += 1
            handle = f"job{self._counter:03d}_{agent_type}"
            future = self._pool.submit(run)
            self._jobs[handle] = _BackgroundJob(handle, agent_type, specs, future)
        return handle

    def outstanding(self) -> list[str]:
        with self._lock:
            return list(self._jobs)

    def take(self, handles: list[str]) -> tuple[list[_BackgroundJob], list[str]]:
        """Remove and return the named jobs; also report unknown handles.

        Waiting on the futures happens outside the lock in the caller.
        """
        found: list[_BackgroundJob] = []
        unknown: list[str] = []
        with self._lock:
            for h in handles:
                job = self._jobs.pop(h, None)
                if job is None:
                    unknown.append(h)
                else:
                    found.append(job)
        return found, unknown


class TaskSpawnTool(Tool):
    """Spawn sub-agent(s) in parallel.

    The agent_factory_map is injected at agent construction time and maps
    agent type names to factory functions.

    For executor/analysis/summarizer: factory(plan_dir: str) → BaseReActAgent
    For knowledge_manager: factory(input_text: str, summary_paths: list[str]) → BaseReActAgent
    """

    name = "task_spawn"
    # description + parameters_schema are built per-instance in __init__ so the
    # advertised agent_type enum reflects exactly the factories this task
    # provides (e.g. 'analysis' only appears when the task opted in). This keeps
    # the tool schema identical to the original for benches that don't use it.
    description = "Spawn one or more sub-agents in parallel. Returns when all complete."
    parameters_schema = {
        "type": "object",
        "properties": {"agent_type": {"type": "string"}},
        "required": ["agent_type"],
    }

    def __init__(
        self,
        subagent_manager: SubAgentManager,
        agent_factory_map: dict[str, Callable],
        manager_by_agent_type: dict[str, SubAgentManager] | None = None,
        background_registry: BackgroundJobRegistry | None = None,
    ) -> None:
        self._manager = subagent_manager
        self._manager_by_agent_type = manager_by_agent_type or {}
        self._factories = agent_factory_map
        self._bg = background_registry
        self.description, self.parameters_schema = self._build_schema(
            list(agent_factory_map), has_background=self._bg is not None
        )

    @staticmethod
    def _build_schema(available: list[str], has_background: bool = False) -> tuple[str, dict]:
        has_analysis = "analysis" in available
        # knowledge_manager may be ablated away; when it is, drop all KM-specific
        # description and parameters so the tool schema stays consistent (no
        # dangling references to an agent type the planner cannot spawn). When KM
        # is present this is a no-op — the schema is identical to the original.
        has_km = "knowledge_manager" in available
        plan_dir_types = [t for t in ("executor", "analysis", "summarizer") if t in available]

        desc_parts = [
            "Spawn one or more sub-agents in parallel. Blocks until all complete "
            "unless you pass `background: true`.\n\n",
            f"For {'/'.join(plan_dir_types)}: pass `plan_dirs` — each directory becomes a "
            "sub-agent's working directory, each should contain plan.md. ",
        ]
        if has_analysis:
            desc_parts.append(
                "'executor' runs experiments that produce a promotable candidate; 'analysis' "
                "runs diagnostics that explain something and produce no model. Analysis may "
                "write and run its own code (distribution and coverage checks, correlation or "
                "drift analysis, bad-case mining, parse verification, ...) unless this task "
                "narrowed its tool set — so a diagnostic is not limited "
                "to re-reading existing artifacts. Pass several plan_dirs for parallel "
                "multi-direction work. "
            )
        if has_background:
            desc_parts.append(
                "\n\nSet `background: true` to launch the batch WITHOUT waiting: it returns a "
                "job handle immediately so you can do other work. Collect the results later "
                "with `task_join`. Default (`background` omitted/false) blocks until complete, "
                "exactly as before. Always `task_join` every handle before you `finish`. "
            )
        if has_km:
            desc_parts.append(
                "\n\nFor knowledge_manager: pass `summary_paths` — paths returned by summarizer/"
                "analysis sub-agents — so KM can read complete summaries. `input_text` is still "
                "accepted for inline notes or backward compatibility. Only one KM agent is spawned."
            )

        type_help = "Type of sub-agent to spawn."
        if has_analysis:
            type_help += (
                " 'executor' runs an experiment and produces a promotable candidate. "
                "'analysis' runs a diagnostic: it computes evidence to explain something and "
                "produces no model and no submission — spawn several at once for "
                "multi-direction parallel analysis."
            )

        properties = {
            "agent_type": {
                "type": "string",
                "enum": available,
                "description": type_help,
            },
            "plan_dirs": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "List of plan directory paths (absolute or relative to working dir). "
                    f"Required for {', '.join(plan_dir_types)}. Pass multiple for parallel "
                    "execution or comparison."
                ),
            },
        }
        if has_background:
            properties["background"] = {
                "type": "boolean",
                "description": (
                    "If true, return a job handle immediately instead of waiting; collect "
                    "results later with task_join. Lets executor and analysis batches overlap. "
                    "Not supported for knowledge_manager. Default false (blocks)."
                ),
            }
        if has_km:
            properties["input_text"] = {
                "type": "string",
                "description": (
                    "Inline text input for knowledge_manager. Prefer `summary_paths` for "
                    "complete summaries; use this for short notes or backward compatibility."
                ),
            }
            properties["summary_paths"] = {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Summary artifact paths returned by summarizer/analysis sub-agents. "
                    "Paths are relative to the planner working directory unless absolute."
                ),
            }

        schema = {
            "type": "object",
            "properties": properties,
            "required": ["agent_type"],
        }
        return "".join(desc_parts), schema

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        agent_type = args.get("agent_type", "")
        background = bool(args.get("background", False))

        if agent_type not in self._factories:
            return ToolResult(
                success=False,
                output=f"Unknown agent type '{agent_type}'. Available: {list(self._factories.keys())}",
            )

        specs, err = self._build_specs(agent_type, args, context)
        if err is not None:
            return err

        manager = self._manager_by_agent_type.get(agent_type, self._manager)

        if background:
            if self._bg is None:
                return ToolResult(
                    success=False,
                    output="background execution is not available in this run; omit `background`.",
                )
            if agent_type == "knowledge_manager":
                return ToolResult(
                    success=False,
                    output="knowledge_manager cannot run in background; call it blocking.",
                )
            handle = self._bg.submit(
                agent_type, specs, lambda m=manager, s=specs: m.spawn_parallel(s)
            )
            logger.info(
                "Launched %d %s sub-agent(s) in background as %s",
                len(specs), agent_type, handle,
            )
            return ToolResult(
                success=True,
                output=(
                    f"Launched {len(specs)} {agent_type} sub-agent(s) in the background.\n"
                    f"job_handle: {handle}\n"
                    f'Collect results later with task_join(handles=["{handle}"]). '
                    f"You may keep working meanwhile (e.g. spawn analysis while this trains)."
                ),
            )

        logger.info("Spawning %d %s sub-agent(s)", len(specs), agent_type)
        results = manager.spawn_parallel(specs)
        output, all_success = _format_batch(specs, results)
        return ToolResult(success=all_success, output=output)

    def _build_specs(
        self, agent_type: str, args: dict, context: ToolContext
    ) -> tuple[list | None, ToolResult | None]:
        """Validate args and build sub-agent specs, or return (None, error)."""
        from ..harness.subagent import SubAgentSpec

        factory = self._factories[agent_type]
        specs: list = []

        if agent_type == "knowledge_manager":
            input_text = args.get("input_text", "")
            summary_paths = args.get("summary_paths", [])
            if isinstance(summary_paths, str):
                summary_paths = [summary_paths]
            if summary_paths and not isinstance(summary_paths, list):
                return None, ToolResult(
                    success=False,
                    output="`summary_paths` must be a list of file paths.",
                )
            if not input_text and not summary_paths:
                return None, ToolResult(
                    success=False,
                    output=(
                        "knowledge_manager requires `summary_paths` and/or `input_text` "
                        "(experiment summaries)."
                    ),
                )
            validated_summary_paths = []
            for path_str in summary_paths:
                if not isinstance(path_str, str):
                    return None, ToolResult(
                        success=False,
                        output=f"Invalid summary path (not a string): {path_str!r}",
                    )
                resolved = _confine_summary_path(path_str, context.working_dir)
                if resolved is None:
                    return None, ToolResult(
                        success=False,
                        output=f"Summary path is outside working directory: {path_str}",
                    )
                if not resolved.exists():
                    return None, ToolResult(
                        success=False,
                        output=f"Summary path not found: {resolved}",
                    )
                if not resolved.is_file():
                    return None, ToolResult(
                        success=False,
                        output=f"Summary path is not a file: {resolved}",
                    )
                validated_summary_paths.append(str(resolved))
            if validated_summary_paths and not _accepts_positional_args(factory, 2):
                return None, ToolResult(
                    success=False,
                    output=(
                        "Configured knowledge_manager factory does not support "
                        "`summary_paths`; update it to accept "
                        "(input_text, summary_paths)."
                    ),
                )
            specs.append(SubAgentSpec(
                agent_factory=(
                    lambda t=input_text, p=validated_summary_paths: (
                        _call_knowledge_manager_factory(factory, t, p)
                    )
                ),
                label="knowledge_manager",
            ))
            return specs, None

        plan_dirs = args.get("plan_dirs", [])
        if not plan_dirs:
            return None, ToolResult(
                success=False,
                output=f"'{agent_type}' requires `plan_dirs` (list of directories).",
            )
        for plan_dir in plan_dirs:
            full_dir = _confine_to_workdir(plan_dir, context.working_dir)
            if full_dir is None:
                return None, ToolResult(success=False, output="Plan directory is outside the working directory.")
            if not full_dir.exists():
                return None, ToolResult(
                    success=False,
                    output=f"Directory not found: {full_dir}",
                )
            specs.append(SubAgentSpec(
                agent_factory=lambda d=str(full_dir): factory(d),
                label=f"{agent_type}:{full_dir.name}",
            ))
        return specs, None


class TaskJoinTool(Tool):
    """Collect results of background task_spawn jobs.

    Shares one BackgroundJobRegistry with TaskSpawnTool. Blocks until the named
    jobs finish (each is self-bounded by the SubAgentManager deadline, so this
    cannot hang forever), then returns their aggregated results and removes them
    from the registry. With no `handles`, joins ALL outstanding jobs — the safe
    way to drain everything before finishing.
    """

    name = "task_join"
    description = (
        "Wait for background task_spawn jobs and return their results. Pass "
        "`handles` (the job_handle values returned by task_spawn background:true); "
        "omit it to join ALL outstanding jobs. Always join every handle before finish."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "handles": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Job handles to wait for. Omit or leave empty to join all "
                    "outstanding background jobs."
                ),
            },
        },
        "required": [],
    }

    def __init__(self, background_registry: BackgroundJobRegistry) -> None:
        self._bg = background_registry

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        handles = args.get("handles") or []
        if isinstance(handles, str):
            handles = [handles]
        if not handles:
            handles = self._bg.outstanding()
        if not handles:
            return ToolResult(success=True, output="No outstanding background jobs to join.")

        jobs, unknown = self._bg.take(handles)

        sections: list[str] = []
        all_success = not unknown
        for job in jobs:
            try:
                results = job.future.result()
            except Exception as e:  # dispatch itself failed (should be rare)
                sections.append(f"### {job.handle} ({job.agent_type}): dispatch failed: {e}")
                all_success = False
                continue
            output, ok = _format_batch(job.specs, results)
            all_success = all_success and ok
            sections.append(f"### {job.handle} ({job.agent_type}):\n{output}")

        if unknown:
            sections.append("Unknown/already-joined handles: " + ", ".join(unknown))

        return ToolResult(success=all_success, output="\n\n".join(sections))


class FinishTool(Tool):
    name = "finish"
    description = (
        "Signal that you have completed your task. "
        "Provide a final result/summary. This ends the agent loop."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "result": {
                "type": "string",
                "description": "Final result or summary of your work",
            },
            "success": {
                "type": "boolean",
                "description": "Whether the task was completed successfully (default: true)",
            },
        },
        "required": ["result"],
    }

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        result = args.get("result", "")
        success = args.get("success", True)
        return ToolResult(success=success, output=result)


def _format_batch(specs: list, results: list[AgentResult]) -> tuple[str, bool]:
    """Render a batch of sub-agent results; return (text, all_success).

    Shared by blocking task_spawn and task_join so their output is identical.
    """
    summary_parts = []
    all_success = True
    for i, result in enumerate(results):
        status = "SUCCESS" if result.success else "FAILED"
        if not result.success:
            all_success = False
        label = specs[i].label if i < len(specs) else f"agent-{i}"
        artifact_lines = []
        if result.artifacts.get("summary_path"):
            artifact_lines.append(f"  summary_path: {result.artifacts['summary_path']}")
        if result.artifacts.get("final_response_path"):
            artifact_lines.append(
                f"  final_response_path: {result.artifacts['final_response_path']}"
            )
        if result.artifacts.get("summary_index_path"):
            artifact_lines.append(
                f"  summary_index_path: {result.artifacts['summary_index_path']}"
            )
        artifact_text = "\n".join(artifact_lines)
        if artifact_text:
            artifact_text += "\n"
        summary_parts.append(
            f"[{status}] {label} (iterations={result.iterations_used}):\n"
            f"{artifact_text}"
            f"  preview: {result.final_response[:2000]}"
        )
    return "\n\n".join(summary_parts), all_success


def _confine_summary_path(path_str: str, working_dir: Path) -> Path | None:
    """Keep summary reads inside the working directory, including link targets."""
    return _confine_to_workdir(path_str, working_dir)


def _call_knowledge_manager_factory(
    factory: Callable,
    input_text: str,
    summary_paths: list[str],
) -> BaseReActAgent:
    """Call KM factories using the new two-arg API, with legacy fallback."""
    if summary_paths or _accepts_positional_args(factory, 2):
        return factory(input_text, summary_paths)
    return factory(input_text)


def _accepts_positional_args(factory: Callable, n: int) -> bool:
    try:
        signature = inspect.signature(factory)
    except (TypeError, ValueError):
        return True

    positional_count = 0
    for param in signature.parameters.values():
        if param.kind == inspect.Parameter.VAR_POSITIONAL:
            return True
        if param.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            positional_count += 1
    return positional_count >= n
