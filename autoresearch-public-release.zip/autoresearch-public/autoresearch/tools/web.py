"""Optional web search and page visit tools.

These standalone Tool subclasses can be registered by any agent. They are not
wired into the executor by default.

- ``WebSearchTool``: queries a configured JSON search endpoint, returns a
  list of {title, url, snippet}.
- ``WebVisitTool``: fetches page(s) and returns cleaned markdown via the
  ``defuddle`` CLI.

Config comes from the top-level ``web_search:`` section of
``config/default_config.yaml`` (``${...}`` env vars are expanded, ``.env`` is
loaded). A config dict may also be injected via the constructor, in which case
no file is read — this is the hook for future executor wiring.

Both tools memoize SUCCESSFUL results in a shared SQLite cache (path from
``$AR_WEB_CACHE``, else a per-process temp file); a transient failure is never
cached, so it can't poison a query. All network paths retry transient failures
(timeouts, 429, 5xx) with exponential backoff; permanent errors re-raise.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import random
import sqlite3
import subprocess
import threading
import time
from pathlib import Path

import requests
import yaml

from ..harness.tool import Tool
from ..harness.types import ToolContext, ToolResult

logger = logging.getLogger(__name__)

# ─── Limits ───────────────────────────────────────────────────────────────────
MAX_QUERIES = 5
MAX_VISIT_URLS = 3
MAX_VISIT_CONTENT_CHARS = 6000
VISIT_TIMEOUT = 30

# ─── Config loading ───────────────────────────────────────────────────────────
_CONFIG_CACHE: dict | None = None


def _find_config() -> Path:
    """Locate config/default_config.yaml. AUTORESEARCH_CONFIG wins; else walk up."""
    env = os.environ.get("AUTORESEARCH_CONFIG")
    if env and Path(env).is_file():
        return Path(env)
    here = Path(__file__).resolve()
    for parent in here.parents:
        cand = parent / "config" / "default_config.yaml"
        if cand.is_file():
            return cand
    return (Path(__file__).parent / "../config/default_config.yaml").resolve()


def _expand_env(obj):
    if isinstance(obj, dict):
        return {k: _expand_env(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_expand_env(v) for v in obj]
    if isinstance(obj, str) and obj.startswith("${") and obj.endswith("}"):
        return os.environ.get(obj[2:-1], "")
    return obj


def _load_web_search_config() -> dict:
    """Read the top-level ``web_search:`` section, expanding env vars. Cached."""
    global _CONFIG_CACHE
    if _CONFIG_CACHE is not None:
        return _CONFIG_CACHE

    config_path = _find_config()
    try:
        from dotenv import load_dotenv

        load_dotenv(config_path.parent.parent / ".env", override=False)
        load_dotenv(config_path.parent / ".env", override=False)
    except Exception:
        pass

    try:
        with open(config_path) as f:
            raw = yaml.safe_load(f) or {}
    except Exception as e:
        logger.warning("web tools: could not read config %s: %s", config_path, e)
        raw = {}

    _CONFIG_CACHE = _expand_env(raw.get("web_search", {})) or {}
    return _CONFIG_CACHE


# ─── Web result cache (shared SQLite; successes only) ─────────────────────────
_CACHE_LOCK = threading.Lock()
_WEB_CACHE_CONN: sqlite3.Connection | None = None


def _runtime_tmp_path(filename: str) -> str:
    root = Path(os.environ.get("AR_RUNTIME_DIR") or os.environ.get("TMPDIR") or "/tmp")
    root.mkdir(parents=True, exist_ok=True)
    return str(root / filename)


def _web_cache_path() -> str:
    return os.environ.get("AR_WEB_CACHE") or _runtime_tmp_path(
        f"web_tools_cache_{os.getpid()}.sqlite"
    )


def _web_cache() -> sqlite3.Connection:
    global _WEB_CACHE_CONN
    if _WEB_CACHE_CONN is not None:
        return _WEB_CACHE_CONN
    conn = sqlite3.connect(_web_cache_path(), check_same_thread=False, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=30000")
    conn.execute("CREATE TABLE IF NOT EXISTS cache (k TEXT PRIMARY KEY, v TEXT)")
    conn.commit()
    _WEB_CACHE_CONN = conn
    return conn


def _cache_get(kind: str, key: str):
    """Return the cached value for (kind, key), or None on miss. Never raises."""
    try:
        k = f"{kind}:{hashlib.sha256(key.encode()).hexdigest()}"
        with _CACHE_LOCK:
            row = _web_cache().execute("SELECT v FROM cache WHERE k=?", (k,)).fetchone()
        return json.loads(row[0]) if row else None
    except Exception:
        return None


def _cache_put(kind: str, key: str, value) -> None:
    """Store value under (kind, key). Best-effort — caching must never break a call."""
    try:
        k = f"{kind}:{hashlib.sha256(key.encode()).hexdigest()}"
        with _CACHE_LOCK:
            conn = _web_cache()
            conn.execute(
                "INSERT OR REPLACE INTO cache (k, v) VALUES (?, ?)",
                (k, json.dumps(value)),
            )
            conn.commit()
    except Exception:
        pass


# ─── Network retry (transient failures only) ──────────────────────────────────
_RETRY_DELAYS = [2, 4, 8]     # search: retry timeouts / 429 / 5xx
_VISIT_RETRY_DELAYS = [3]     # visits are slow (30s each) → retry once

_TRANSIENT_MARKERS = (
    "429", "500", "502", "503", "504",
    "rate limit", "ratelimit", "throttl", "overloaded",
    "timeout", "timed out", "temporarily", "connection",
)


def _is_transient(exc: Exception) -> bool:
    """True if `exc` is worth retrying (network blip, rate limit, 5xx)."""
    if isinstance(
        exc,
        (
            requests.exceptions.Timeout,
            requests.exceptions.ConnectionError,
            subprocess.TimeoutExpired,
        ),
    ):
        return True
    msg = str(exc).lower()
    return any(marker in msg for marker in _TRANSIENT_MARKERS)


def _retry_with_backoff(fn, delays=_RETRY_DELAYS):
    """Run fn(), retrying transient failures with exponential backoff + jitter.
    Permanent errors and the final attempt re-raise so callers handle them."""
    for attempt in range(len(delays) + 1):
        try:
            return fn()
        except Exception as e:
            if attempt == len(delays) or not _is_transient(e):
                raise
            delay = delays[attempt] + random.uniform(0, 1)
            logger.info(
                "web tools: transient error (%s), waiting %.1fs (attempt %d/%d)",
                type(e).__name__, delay, attempt + 1, len(delays),
            )
            time.sleep(delay)


# ─── Search implementation ────────────────────────────────────────────────────
def _run_web_search(queries: list[str], config: dict) -> str:
    url = config.get("url", "")
    api_key = config.get("api_key", "")
    max_results = config.get("max_results", 10)

    if not url or not api_key:
        return (
            "[ERROR] Web search not configured. Set the top-level `web_search` "
            "section (url + api_key) in config/default_config.yaml."
        )

    all_results = []
    for query in queries[:MAX_QUERIES]:
        cache_key = f"{url}|{max_results}|{query}"
        cached = _cache_get("search", cache_key)
        if cached is not None:
            all_results.extend(cached)
            continue

        payload = {
            "query": query,
            "max_results": max_results,
        }
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

        def _do_search():
            r = requests.post(url, json=payload, headers=headers, timeout=(5, 30))
            if r.status_code in (429, 500, 502, 503, 504):
                # Turn a retryable status into an exception so backoff catches it.
                raise requests.exceptions.HTTPError(f"{r.status_code} from search endpoint")
            r.raise_for_status()
            return r

        try:
            resp = _retry_with_backoff(_do_search)
            body = resp.json()
            items = body["results"][:max_results]
            results = [
                {
                    "title": item.get("title", ""),
                    "url": item.get("url", ""),
                    "snippet": item.get("snippet", ""),
                }
                for item in items
            ]
            all_results.extend(results)
            # Cache only NON-EMPTY results: an empty result list is more often a
            # soft rate-limit (HTTP 200, no data) than a genuine "no results".
            if results:
                _cache_put("search", cache_key, results)
        except (KeyError, IndexError, TypeError):
            all_results.append({"error": f"No results for '{query}'"})
        except Exception as e:
            # An HTTP error can include request information. Do not expose it
            # in tool output, where it may be recorded or sent to a model.
            all_results.append({"error": f"Search failed for '{query}': {type(e).__name__}"})
        time.sleep(0.3)

    if not all_results:
        return "No search results found."

    lines = []
    seen_urls = set()
    for i, r in enumerate(all_results, 1):
        if "error" in r:
            lines.append(f"{i}. [Error] {r['error']}")
            continue
        if r["url"] in seen_urls:
            continue
        seen_urls.add(r["url"])
        lines.append(f"{i}. {r['title']}")
        lines.append(f"   URL: {r['url']}")
        if r.get("snippet"):
            lines.append(f"   Snippet: {r['snippet'][:250]}")
        lines.append("")
    return "\n".join(lines)


# ─── Visit implementation ─────────────────────────────────────────────────────
def _run_web_visit(urls: list[str]) -> str:
    blocks = []
    for url in urls[:MAX_VISIT_URLS]:
        cached = _cache_get("visit", url)
        if cached is not None:
            blocks.append(f"=== {url} ===\n{cached[:MAX_VISIT_CONTENT_CHARS]}")
            continue
        try:
            result = _retry_with_backoff(
                lambda: subprocess.run(
                    ["defuddle", "parse", url, "--md"],
                    capture_output=True,
                    text=True,
                    timeout=VISIT_TIMEOUT,
                ),
                delays=_VISIT_RETRY_DELAYS,
            )
            if result.returncode == 0 and result.stdout.strip():
                full = result.stdout.strip()
                blocks.append(f"=== {url} ===\n{full[:MAX_VISIT_CONTENT_CHARS]}")
                _cache_put("visit", url, full)  # cache full text, successes only
            else:
                blocks.append(f"=== {url} ===\n[Failed to load page]")
        except subprocess.TimeoutExpired:
            blocks.append(f"=== {url} ===\n[Timeout loading page]")
        except FileNotFoundError:
            blocks.append(f"=== {url} ===\n[Error: defuddle not installed]")
        except Exception as e:
            blocks.append(f"=== {url} ===\n[Error: {e}]")
        time.sleep(0.3)

    return "\n\n".join(blocks) if blocks else "No URLs provided."


# ─── Tools ────────────────────────────────────────────────────────────────────
class WebSearchTool(Tool):
    name = "web_search"
    description = (
        "Search the web with one or more queries. Returns a list of results "
        "with title, URL, and snippet for each. Use 2-3 diverse queries to "
        "cover different angles of the question."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "queries": {
                "type": "array",
                "items": {"type": "string"},
                "description": "List of search queries (1-5).",
            }
        },
        "required": ["queries"],
    }

    def __init__(self, config: dict | None = None) -> None:
        # Injected config wins; otherwise read the top-level web_search section.
        self._config = config if config is not None else _load_web_search_config()

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        queries = args.get("queries", [])
        if isinstance(queries, str):
            queries = [queries]
        if not queries:
            return ToolResult(
                success=False,
                output="`queries` must be a non-empty list of search strings.",
                error="invalid_args",
            )
        output = _run_web_search(queries, self._config)
        success = not output.startswith("[ERROR]")
        return ToolResult(success=success, output=output,
                          error=None if success else "not_configured")


class WebVisitTool(Tool):
    name = "web_visit"
    description = (
        "Visit one or more web pages and return their cleaned text content. "
        "Use this to read pages identified from search results. Requires the "
        "`defuddle` CLI to be installed."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "urls": {
                "type": "array",
                "items": {"type": "string"},
                "description": "URLs to visit (1-3).",
            },
            "goal": {
                "type": "string",
                "description": "What you are looking for on these pages.",
            },
        },
        "required": ["urls"],
    }

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        urls = args.get("urls", [])
        if isinstance(urls, str):
            urls = [urls]
        if not urls:
            return ToolResult(
                success=False,
                output="`urls` must be a non-empty list of URLs.",
                error="invalid_args",
            )
        output = _run_web_visit(urls)
        return ToolResult(success=True, output=output)
