from __future__ import annotations

import os
import re
import shlex
import subprocess

from ..harness.tool import Tool
from ..harness.types import ToolContext, ToolResult
from ..runner.environment import build_execution_env
from ..utils.tool_output import log_reference, output_preview, save_output_logs

MAX_OUTPUT_CHARS = 6000

# Patterns that modify shared conda environments (cross-experiment pollution).
# Checked on the full command string so chained commands like
# `cd proj && pip install x` are caught.
_ENV_MODIFY_PATTERNS = [
    re.compile(r'\bpip3?\s+(?:install|uninstall)\b'),
    re.compile(r'\bpython\d*(?:\.\d+)?\s+-m\s+pip\s+(?:install|uninstall)\b'),
    re.compile(r'\bconda\s+(?:install|create|remove)\b'),
    re.compile(r'\bconda\s+env\s+(?:create|remove)\b'),
    re.compile(r'\buv\s+pip\s+(?:install|uninstall)\b'),
]
# pip install --target installs to a local dir, not the shared env — allowed.
_PIP_LOCAL_TARGET_RE = re.compile(r'--target[=\s]')

# ── Read-only mode: filesystem-mutating shell verbs ──────────────────────────
# Checked once per shell segment (see _is_write_command), so a write hiding
# after a separator (`ls && rm -rf x`) is caught, not just the leading verb.
_WRITE_COMMANDS = frozenset({
    "rm", "rmdir", "mv", "cp", "mkdir", "touch", "chmod", "chown", "chgrp",
    "ln", "tee", "truncate", "dd", "install", "shred", "unlink",
})
# Wrappers that prefix another command; keep scanning the segment for the verb.
_PASSTHROUGH_COMMANDS = frozenset({
    "cd", "pushd", "popd", "env", "time", "nohup", "sudo", "xargs",
    "nice", "ionice", "stdbuf", "timeout", "command", "exec", "parallel",
})
# Redirect targets that discard output — harmless in read-only mode.
_SINK_TARGETS = frozenset({"/dev/null", "/dev/stdout", "/dev/stderr", "/dev/tty"})
_WRITE_REDIRECTS = frozenset({">", ">>", "&>", ">&", ">|", "&>>"})
_READ_REDIRECTS = frozenset({"<", "<<", "<<<"})
_SHELL_SEPARATORS = frozenset({"&&", "||", ";", "|", "&", "\n"})
_HEREDOC_RE = re.compile(r"<<-?\s*(['\"]?)([A-Za-z_][A-Za-z0-9_]*)\1")
_WRITE_VERB_FALLBACK_RE = re.compile(
    r"(?:^|[;&|]\s*)\s*(?:%s)\b" % "|".join(sorted(_WRITE_COMMANDS))
)


def _strip_heredoc_bodies(command: str) -> str:
    """Drop heredoc bodies so their contents aren't parsed as shell syntax.

    A heredoc body is data for the spawned program (typically a Python script),
    not shell code — a '>' inside it is a comparison operator or part of a
    string, never a redirection.
    """
    lines = command.split("\n")
    kept: list[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        kept.append(line)
        delimiters = [m.group(2) for m in _HEREDOC_RE.finditer(line)]
        i += 1
        for delimiter in delimiters:
            while i < len(lines) and lines[i].strip() != delimiter:
                i += 1
            i += 1  # skip the terminator line itself
    return "\n".join(kept)


class BashTool(Tool):
    name = "bash"
    description = (
        "Execute a shell command. Use for running scripts, installing packages, "
        "listing files, grepping, etc. Commands run in the agent's working directory."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The shell command to execute",
            },
            "timeout": {
                "type": "integer",
                "description": "Timeout in seconds. Defaults to remaining agent budget (up to 7200s). Set explicitly for long-running tasks like ML training.",
            },
        },
        "required": ["command"],
    }

    def __init__(self, readonly: bool = False) -> None:
        self._readonly = readonly
        if readonly:
            self.description += " (read-only mode: no file modifications allowed)"

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        command = args.get("command", "")
        default_timeout = min(int(context.budget_remaining_seconds), 7200) if context.budget_remaining_seconds > 0 else 120
        timeout = args.get("timeout", default_timeout)

        if not command.strip():
            return ToolResult(success=False, output="Empty command", error="empty_command")

        # Hard block: never let the agent pollute shared conda envs across experiments.
        # Escapable via AR_ALLOW_ENV_MODIFY=1 for maintenance/setup scripts.
        if not os.environ.get("AR_ALLOW_ENV_MODIFY") and self._is_env_modifying_command(command):
            return ToolResult(
                success=False,
                output=(
                    "Blocked: this command would modify a shared conda environment "
                    "(pip/conda install/uninstall), which pollutes the framework for "
                    "all experiments. Use only the already-installed packages. If you "
                    "truly need a local helper, install to a project-local dir: "
                    "`pip install --target=./local_libs <pkg>` and add it to sys.path. "
                    "(Set AR_ALLOW_ENV_MODIFY=1 to bypass for maintenance.)"
                ),
                error="env_modification_blocked",
            )

        if self._readonly and self._is_write_command(command):
            return ToolResult(
                success=False,
                output=(
                    "Blocked in read-only mode: this command writes to the "
                    "filesystem (a redirection into a file such as `> out.txt`, "
                    "or a mutating command such as rm/mv/cp/mkdir/tee/sed -i). "
                    "Rewrite it to print to stdout instead — reading, grepping "
                    "and running analysis scripts are all allowed. Discarding "
                    "stderr with `2>/dev/null` is allowed and is NOT a write."
                ),
                error="readonly",
            )

        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=str(context.working_dir),
                capture_output=True,
                text=True,
                timeout=timeout,
                env=build_execution_env(context.working_dir),
            )
            stdout = output_preview(result.stdout or "", MAX_OUTPUT_CHARS)
            stderr = output_preview(result.stderr or "", MAX_OUTPUT_CHARS)

            output_parts = []
            if stdout:
                output_parts.append(stdout)
            if stderr:
                output_parts.append(f"[stderr]\n{stderr}")
            output_parts.append(f"[exit_code: {result.returncode}]")
            try:
                out_path, err_path = save_output_logs(
                    context.working_dir, "bash", result.stdout or "", result.stderr or "",
                )
                if result.stdout:
                    output_parts.append(f"[full stdout: {log_reference(out_path, context.working_dir)}]")
                if result.stderr:
                    output_parts.append(f"[full stderr: {log_reference(err_path, context.working_dir)}]")
            except (OSError, ValueError):
                output_parts.append("[full logs could not be saved]")

            return ToolResult(
                success=result.returncode == 0,
                output="\n".join(output_parts),
            )
        except subprocess.TimeoutExpired as exc:
            stdout = exc.stdout or ""
            stderr = exc.stderr or ""
            if isinstance(stdout, bytes):
                stdout = stdout.decode("utf-8", errors="replace")
            if isinstance(stderr, bytes):
                stderr = stderr.decode("utf-8", errors="replace")
            parts = [f"Command timed out after {timeout}s"]
            for label, stream in (("stdout", stdout), ("stderr", stderr)):
                if stream:
                    parts.append(f"[{label}]\n{output_preview(stream, MAX_OUTPUT_CHARS)}")
            try:
                out_path, err_path = save_output_logs(context.working_dir, "bash", stdout, stderr)
                if stdout:
                    parts.append(f"[full stdout: {log_reference(out_path, context.working_dir)}]")
                if stderr:
                    parts.append(f"[full stderr: {log_reference(err_path, context.working_dir)}]")
            except (OSError, ValueError):
                parts.append("[full logs could not be saved]")
            return ToolResult(
                success=False,
                output="\n".join(parts),
                error="timeout",
            )
        except Exception as e:
            return ToolResult(success=False, output=f"Command execution error: {e}", error="exec_error")

    def _is_write_command(self, command: str) -> bool:
        """Best-effort detection of filesystem writes in a shell command.

        Tokenizes with shlex so quoted text is opaque: a '>' inside a Python
        snippet ('a->b', 'x>0') or a '2>/dev/null' stderr discard is no longer
        mistaken for a redirection, while a real `> out.txt` still is. Every
        shell segment is checked, so `ls && rm -rf x` is caught too.

        This is an accident guard, NOT a security boundary: read-only agents
        legitimately run python3/awk for analysis, and any interpreter can
        write files on its own. Anything that must be truly unreachable has to
        be protected outside this check.
        """
        stripped = _strip_heredoc_bodies(command)
        # Treat $(...) and backtick substitutions as separate segments so a
        # write verb hiding inside them is still seen at a segment start.
        normalized = (
            stripped.replace("$(", " ; ").replace("`", " ; ").replace(")", " ; ")
        )
        lexer = shlex.shlex(normalized, posix=True, punctuation_chars=True)
        lexer.whitespace_split = True
        try:
            tokens = list(lexer)
        except ValueError:
            # Unbalanced quotes or exotic syntax. Fall back to a word-boundary
            # scan for write verbs rather than the old `'>' in command` test,
            # which misfired on '2>/dev/null' and Python comparison operators.
            return bool(_WRITE_VERB_FALLBACK_RE.search(stripped))

        at_segment_start = True
        for index, token in enumerate(tokens):
            if token in _SHELL_SEPARATORS:
                at_segment_start = True
                continue

            if token in _WRITE_REDIRECTS:
                target = tokens[index + 1] if index + 1 < len(tokens) else ""
                # '2>&1' / '>&2' duplicate a file descriptor — nothing written.
                if token in (">&", "&>") and target.isdigit():
                    continue
                if target not in _SINK_TARGETS:
                    return True
                continue
            if token in _READ_REDIRECTS:
                continue

            if at_segment_start:
                name = token.rsplit("/", 1)[-1]
                if name in _WRITE_COMMANDS:
                    return True
                if name in ("sed", "gsed") and self._has_inplace_flag(tokens[index + 1:]):
                    return True
                if name == "find" and self._find_mutates(tokens[index + 1:]):
                    return True
                if name not in _PASSTHROUGH_COMMANDS:
                    at_segment_start = False
        return False

    @staticmethod
    def _has_inplace_flag(rest: list[str]) -> bool:
        for token in rest:
            if token in _SHELL_SEPARATORS:
                return False
            if token.startswith("-i") or token.startswith("--in-place"):
                return True
        return False

    @staticmethod
    def _find_mutates(rest: list[str]) -> bool:
        for token in rest:
            if token in _SHELL_SEPARATORS:
                return False
            if token in ("-delete", "-exec", "-execdir", "-fprint", "-fprintf"):
                return True
        return False

    def _is_env_modifying_command(self, command: str) -> bool:
        """Detect commands that would pollute shared conda environments.

        Blocks pip/conda install/uninstall. ``pip install --target`` is allowed
        (installs to a local project dir, not the shared env).
        """
        for pattern in _ENV_MODIFY_PATTERNS:
            if pattern.search(command):
                if 'pip' in pattern.pattern and _PIP_LOCAL_TARGET_RE.search(command):
                    continue
                return True
        return False
