"""In-memory todo list for agent self-management."""

from __future__ import annotations

from ..harness.tool import Tool
from ..harness.types import ToolContext, ToolResult


class TodoTool(Tool):
    name = "todo"
    description = (
        "Manage a todo list to track your progress. "
        "Actions: list, add, complete, remove. "
        "Use this to plan and track multi-step tasks."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["list", "add", "complete", "remove"],
                "description": "The action to perform",
            },
            "item": {
                "type": "string",
                "description": "The todo item text (for add) or index (for complete/remove)",
            },
        },
        "required": ["action"],
    }

    def __init__(self) -> None:
        self._items: list[dict] = []

    def execute(self, args: dict, context: ToolContext) -> ToolResult:
        action = args.get("action", "list")
        item = args.get("item", "")

        if action == "list":
            return self._list()
        elif action == "add":
            return self._add(item)
        elif action == "complete":
            return self._complete(item)
        elif action == "remove":
            return self._remove(item)
        else:
            return ToolResult(
                success=False,
                output=f"Unknown action '{action}'. Use: list, add, complete, remove",
            )

    def _list(self) -> ToolResult:
        if not self._items:
            return ToolResult(success=True, output="Todo list is empty.")

        lines = []
        for i, item in enumerate(self._items):
            status = "x" if item["done"] else " "
            lines.append(f"[{status}] {i}: {item['text']}")
        return ToolResult(success=True, output="\n".join(lines))

    def _add(self, text: str) -> ToolResult:
        if not text.strip():
            return ToolResult(success=False, output="Item text cannot be empty")
        self._items.append({"text": text.strip(), "done": False})
        idx = len(self._items) - 1
        return ToolResult(success=True, output=f"Added item {idx}: {text.strip()}")

    def _complete(self, index_str: str) -> ToolResult:
        try:
            idx = int(index_str)
        except (ValueError, TypeError):
            return ToolResult(success=False, output=f"Invalid index: {index_str}")
        if idx < 0 or idx >= len(self._items):
            return ToolResult(success=False, output=f"Index {idx} out of range (0-{len(self._items)-1})")

        self._items[idx]["done"] = True
        return ToolResult(success=True, output=f"Completed item {idx}: {self._items[idx]['text']}")

    def _remove(self, index_str: str) -> ToolResult:
        try:
            idx = int(index_str)
        except (ValueError, TypeError):
            return ToolResult(success=False, output=f"Invalid index: {index_str}")
        if idx < 0 or idx >= len(self._items):
            return ToolResult(success=False, output=f"Index {idx} out of range (0-{len(self._items)-1})")

        removed = self._items.pop(idx)
        return ToolResult(success=True, output=f"Removed item: {removed['text']}")
