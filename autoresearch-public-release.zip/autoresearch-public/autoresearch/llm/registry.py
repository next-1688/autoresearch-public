from __future__ import annotations

from ..config.settings import LLMRoleConfig
from .base import BaseLLM
from .openai_llm import OpenAILLM, OpenAIResponsesLLM


def _create_llm(config: LLMRoleConfig) -> BaseLLM:
    if config.provider == "openai":
        return OpenAILLM(config)
    if config.provider == "openai_responses":
        return OpenAIResponsesLLM(config)
    raise ValueError(f"Unknown LLM provider: {config.provider}")


class LLMRegistry:
    """Manage multiple LLM instances by configured role."""

    def __init__(self, configs: dict[str, LLMRoleConfig]) -> None:
        self._instances: dict[str, BaseLLM] = {}
        for role, cfg in configs.items():
            self._instances[role] = _create_llm(cfg)

    def has(self, role: str) -> bool:
        return role in self._instances

    def get(self, role: str) -> BaseLLM:
        if role not in self._instances:
            raise KeyError(f"No LLM configured for role '{role}'")
        return self._instances[role]
