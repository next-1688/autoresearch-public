from __future__ import annotations

import logging
import time
import uuid
from abc import ABC, abstractmethod
from pathlib import Path

from pydantic import BaseModel, Field

from ..harness.telemetry import (
    UsageRecorder,
    aggregate_calls,
    current_context,
    get_recorder,
    read_jsonl,
    set_context_tags,
    set_recorder,
    timestamp,
    usage_fields,
)

logger = logging.getLogger(__name__)


def set_current_agent(agent: str, experiment: str = "root") -> None:
    """Tag subsequent LLM calls on THIS thread with (agent, experiment)."""
    set_context_tags(agent, experiment)


class LLMAPIError(Exception):
    """API 返回了无效内容（如 finish_reason=error_finish、空响应、错误信息伪装为内容）"""

    def __init__(self, message: str, *, usage: dict | None = None):
        super().__init__(message)
        self.usage = usage or {}


class CircuitBreaker:
    """连续失败超阈值时暂时拒绝新请求，冷却期后自动恢复"""

    def __init__(self, max_failures: int = 5, cooldown: float = 60.0) -> None:
        self._consecutive_failures = 0
        self._last_failure_time = 0.0
        self._max_failures = max_failures
        self._cooldown = cooldown

    def record_success(self) -> None:
        self._consecutive_failures = 0

    def record_failure(self) -> None:
        self._consecutive_failures += 1
        self._last_failure_time = time.time()

    def is_open(self) -> bool:
        if self._consecutive_failures < self._max_failures:
            return False
        return time.time() - self._last_failure_time <= self._cooldown

    @property
    def failure_count(self) -> int:
        return self._consecutive_failures


class LLMResponse(BaseModel):
    content: str = ""
    tool_calls: list[dict] | None = None
    usage: dict[str, int] = Field(default_factory=dict)
    raw: dict = Field(default_factory=dict)


class BaseLLM(ABC):
    _cost_log_path: Path | None = None

    def __init__(self) -> None:
        self._circuit_breaker = CircuitBreaker()

    @classmethod
    def set_cost_log_path(cls, path: Path) -> None:
        cls._cost_log_path = Path(path)
        set_recorder(UsageRecorder(Path(path).parent))

    def _log_call(
        self, record: dict, messages: list[dict], result: LLMResponse | None
    ) -> None:
        recorder = get_recorder()
        if recorder is None:
            return
        recorder.record_call(record)
        conversation = {
            **record,
            "usage": result.usage if result else record.get("raw_usage", {}),
            "messages": messages,
            "response": result.content if result else None,
            "thinking": result.raw.get("thinking", "") if result else "",
            "tool_calls": result.tool_calls if result else None,
        }
        try:
            with recorder.lock:
                recorder._append("llm_conversations.jsonl", conversation)
        except Exception:
            logger.warning("Failed to write conversation log", exc_info=True)

    @classmethod
    def get_cost_summary(cls, extra_paths: list[Path] | None = None) -> dict:
        """Usage summary, including incomplete calls and optional subprocess logs."""
        recorder = get_recorder()
        if recorder:
            for path in extra_paths or []:
                if (
                    cls._cost_log_path is None
                    or Path(path).resolve() != cls._cost_log_path.resolve()
                ):
                    recorder.import_usage(Path(path))
            with recorder.lock:
                records = list(recorder.calls.values())
        else:
            records = read_jsonl(cls._cost_log_path) if cls._cost_log_path else []
        seen = {r["call_id"] for r in records if r.get("call_id")}
        paths = {Path(p).resolve() for p in extra_paths or []}
        if cls._cost_log_path:
            paths.discard(cls._cost_log_path.resolve())
        for path in sorted(paths):
            if recorder:
                continue  # Imported into the same source-of-truth log above.
            for record in read_jsonl(path):
                identifier = record.get("call_id")
                if identifier and identifier in seen:
                    continue
                if identifier:
                    seen.add(identifier)
                records.append(record)
        summary = aggregate_calls(records)
        for group, field in (("by_agent", "agent"), ("by_experiment", "experiment")):
            summary[group] = {
                key: aggregate_calls(
                    [r for r in records if r.get(field, "unknown") == key]
                )
                for key in sorted({r.get(field, "unknown") for r in records})
            }
        return summary

    @abstractmethod
    def _chat_impl(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        tool_choice: str | dict | None = None,
    ) -> LLMResponse:
        """Provider-specific single API call. Subclasses implement this;
        callers use chat(), which wraps it with cost/conversation logging."""
        ...

    def chat(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        tool_choice: str | dict | None = None,
    ) -> LLMResponse:
        """Count one framework attempt, even on failure or absent provider usage."""
        recorder = get_recorder()
        context = current_context()
        call_id = uuid.uuid4().hex
        config = getattr(self, "config", None)
        started_epoch, started_mono = time.time(), time.perf_counter()
        started_at = timestamp()
        if recorder:
            recorder.event(
                "llm_call_started", call_id=call_id, model=getattr(config, "model", "")
            )
        result = None
        error = None
        try:
            result = self._chat_impl(messages, tools=tools, tool_choice=tool_choice)
            return result
        except BaseException as exc:
            error = exc
            raise
        finally:
            elapsed = time.perf_counter() - started_mono
            try:
                usage = result.usage if result else getattr(error, "usage", {}) or {}
                fields = usage_fields(
                    usage, getattr(config, "input_tokens_include_cache", True)
                )
                input_cost = output_cost = None
                pricing = getattr(config, "pricing", None)
                if pricing and fields["usage_status"] == "reported":
                    ti, to = fields["input_tokens"], fields["output_tokens"]
                    cr, cw = (
                        fields["cache_read_tokens"] or 0,
                        fields["cache_creation_tokens"] or 0,
                    )
                    if ti >= cr + cw:
                        input_cost = (
                            (ti - cr - cw) * pricing["input_per_million"]
                            + cr
                            * pricing.get(
                                "cache_read_per_million", pricing["input_per_million"]
                            )
                            + cw
                            * pricing.get(
                                "cache_write_per_million", pricing["input_per_million"]
                            )
                        ) / 1_000_000
                        output_cost = to * pricing["output_per_million"] / 1_000_000
                record = {
                    "schema_version": 1,
                    "call_id": call_id,
                    "run_id": recorder.metadata["run_id"] if recorder else None,
                    "timestamp": started_at,
                    "ended_at": timestamp(),
                    "started_epoch": started_epoch,
                    "ended_epoch": time.time(),
                    "started_monotonic": started_mono,
                    "ended_monotonic": time.perf_counter(),
                    "elapsed_seconds": elapsed,
                    "status": "failed" if error else "succeeded",
                    "error_type": type(error).__name__ if error else None,
                    "agent": context.agent,
                    "experiment": context.experiment,
                    "phase": context.phase,
                    "activity_id": context.activity_id,
                    "attempt_id": context.attempt_id,
                    "model": getattr(config, "model", ""),
                    "raw_usage": usage,
                    **fields,
                    "input_cost": input_cost,
                    "output_cost": output_cost,
                    "call_cost": input_cost + output_cost
                    if input_cost is not None
                    else None,
                }
                self._log_call(record, messages, result)
            except Exception:
                # Accounting must never hide the model result or its original error.
                logger.warning("Failed to record LLM call", exc_info=True)

    def chat_with_retry(
        self,
        messages: list[dict],
        max_retries: int = 3,
        **kwargs,
    ) -> LLMResponse:
        if self._circuit_breaker.is_open():
            raise LLMAPIError(
                f"Circuit breaker open: {self._circuit_breaker.failure_count} consecutive failures, "
                f"waiting for cooldown"
            )

        last_exc: Exception | None = None
        for attempt in range(max_retries):
            try:
                # chat() already records cost + conversation for the call.
                result = self.chat(messages, **kwargs)
                self._circuit_breaker.record_success()
                return result
            except Exception as e:  # noqa: BLE001 - retry arbitrary provider/transport failures
                last_exc = e
                self._circuit_breaker.record_failure()
                wait = 2**attempt
                logger.warning(
                    "LLM call failed (attempt %d/%d): %s — retrying in %ds",
                    attempt + 1,
                    max_retries,
                    e,
                    wait,
                )
                time.sleep(wait)
        raise RuntimeError(f"LLM call failed after {max_retries} retries") from last_exc
