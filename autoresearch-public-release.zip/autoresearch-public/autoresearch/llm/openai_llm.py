"""OpenAI-family providers.

OpenAILLM speaks Chat-Completions (GPT / DeepSeek / Qwen / Claude-via-gateway);
OpenAIResponsesLLM speaks the Responses API (gpt-5.5 reasoning models). Both
share OpenAIFallbackMixin, which handles primary/fallback-endpoint failover.
"""

from __future__ import annotations

import logging

from openai import (
    APIConnectionError,
    APITimeoutError,
    InternalServerError,
    OpenAI,
    RateLimitError,
)

from ..config.settings import LLMRoleConfig
from .base import BaseLLM, LLMAPIError, LLMResponse

logger = logging.getLogger(__name__)


def _field(value, key, default=None):
    return value.get(key, default) if isinstance(value, dict) else getattr(value, key, default)


def _usage(value, *, responses: bool = False) -> dict:
    """Normalize provider usage; keep breakdowns inside input/output totals."""
    if value is None:
        return {}
    result = {}
    for source, target in (("input_tokens" if responses else "prompt_tokens", "prompt_tokens"),
                           ("output_tokens" if responses else "completion_tokens", "completion_tokens"),
                           ("total_tokens", "total_tokens"),
                           ("cache_creation_input_tokens", "cache_creation_input_tokens"),
                           ("cache_read_input_tokens", "cache_read_input_tokens")):
        count = _field(value, source)
        if count is not None:
            result[target] = count
    inputs = _field(value, "input_tokens_details" if responses else "prompt_tokens_details")
    outputs = _field(value, "output_tokens_details" if responses else "completion_tokens_details")
    for details, source, target in ((inputs, "cached_tokens", "cache_read_input_tokens"),
                                    (outputs, "reasoning_tokens", "reasoning_tokens")):
        count = _field(details, source)
        if count is not None:
            result[target] = count
    return result


class OpenAIFallbackMixin:
    """Shared primary/fallback-endpoint handling for OpenAI-compatible providers.

    Behaviour (unchanged from the original inline logic): stay on the primary
    endpoint; count consecutive failures; once the primary has failed
    ``_FALLBACK_CONSECUTIVE_FAILURES`` times in a row, ``_active_client`` starts
    returning the fallback. Each call still re-raises on failure — the caller's
    retry loops (chat_with_retry / loop._call_llm) re-enter and pick up the
    switched client. Any success resets the counter.

    The only fix over the original: transient SDK errors (connection / timeout /
    rate-limit / 5xx) now count toward the threshold too, so failover actually
    engages for them — previously only LLMAPIError (empty responses) did.

    Subclasses build the clients in ``__init__`` (via ``_init_clients``) and
    implement ``_invoke(client, kwargs)`` to make one API call.
    """

    _FALLBACK_CONSECUTIVE_FAILURES = 2

    _TRANSIENT_ERRORS = (
        LLMAPIError,
        APIConnectionError,
        APITimeoutError,
        RateLimitError,
        InternalServerError,
    )

    def _init_clients(self, config: LLMRoleConfig) -> None:
        self.config = config
        kwargs: dict = {
            "api_key": config.api_key,
            "base_url": config.base_url,
            "timeout": config.timeout,
            "max_retries": 3,
        }
        headers = dict(config.extra_headers) if config.extra_headers else {}
        if config.prompt_cache:
            # A stable per-client session id improves cache-hit affinity on
            # gateways that key prompt cache by session. All calls from this
            # role's client in the process share it.
            import uuid
            headers.setdefault("x-session-id", uuid.uuid4().hex)
        if headers:
            kwargs["default_headers"] = headers
        self._client = OpenAI(**kwargs)

        self._fallback_client: OpenAI | None = None
        if config.fallback_base_url:
            fb_kwargs: dict = {
                "api_key": config.fallback_api_key or config.api_key,
                "base_url": config.fallback_base_url,
                "timeout": config.timeout,
                "max_retries": 3,
            }
            if config.fallback_extra_headers:
                fb_kwargs["default_headers"] = config.fallback_extra_headers
            self._fallback_client = OpenAI(**fb_kwargs)
            logger.info("Fallback LLM client configured: %s", config.fallback_base_url)
        self._primary_consecutive_failures = 0

    def _invoke(self, client: OpenAI, kwargs: dict) -> LLMResponse:
        raise NotImplementedError

    def _active_client(self) -> OpenAI:
        if (
            self._fallback_client
            and self._primary_consecutive_failures >= self._FALLBACK_CONSECUTIVE_FAILURES
        ):
            return self._fallback_client
        return self._client

    def _run(self, kwargs: dict) -> LLMResponse:
        try:
            result = self._invoke(self._active_client(), kwargs)
            if self._primary_consecutive_failures > 0:
                logger.info(
                    "Primary endpoint recovered after %d failures",
                    self._primary_consecutive_failures,
                )
            self._primary_consecutive_failures = 0
            return result
        except self._TRANSIENT_ERRORS:
            self._primary_consecutive_failures += 1
            if not self._fallback_client:
                raise
            if self._primary_consecutive_failures >= self._FALLBACK_CONSECUTIVE_FAILURES:
                logger.warning(
                    "Primary endpoint failed %d times consecutively, "
                    "switching to fallback: %s",
                    self._primary_consecutive_failures,
                    self.config.fallback_base_url,
                )
            raise


class OpenAILLM(OpenAIFallbackMixin, BaseLLM):
    """OpenAI-compatible provider (GPT / DeepSeek / Qwen / etc.)."""

    def __init__(self, config: LLMRoleConfig) -> None:
        super().__init__()
        self._init_clients(config)

    def _chat_impl(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        tool_choice: str | dict | None = None,
    ) -> LLMResponse:
        extra_body = dict(self.config.extra_body) if self.config.extra_body else {}

        if self.config.prompt_cache:
            messages, tools = self._apply_prompt_cache(messages, tools, extra_body)

        kwargs: dict = {
            "model": self.config.model,
            "messages": messages,
            "stream": True,
        }
        if self.config.temperature is not None:
            kwargs["temperature"] = self.config.temperature
        if self.config.max_tokens:
            kwargs["max_tokens"] = self.config.max_tokens
        if extra_body:
            kwargs["extra_body"] = extra_body
        if tools:
            kwargs["tools"] = tools
            kwargs["stream"] = False
        if kwargs["stream"] and self.config.include_stream_usage:
            kwargs["stream_options"] = {"include_usage": True}
        if tool_choice is not None:
            kwargs["tool_choice"] = tool_choice

        return self._run(kwargs)

    @staticmethod
    def _apply_prompt_cache(
        messages: list[dict],
        tools: list[dict] | None,
        extra_body: dict,
    ) -> tuple[list[dict], list[dict] | None]:
        """Mark the cacheable prefix for Anthropic-style prompt caching.

        Three breakpoints (Anthropic allows up to 4): the tools array, the system
        prompt, and a rolling breakpoint on the last message. A breakpoint caches
        everything before it, so the rolling one lets the growing conversation
        history be read from cache each turn while only the new turn is written.

        System content must move to ``extendParams.system`` as Anthropic-style
        content blocks (the OpenAI-compat layer only caches system there, not in
        the messages array). The last message is copied before tagging so the
        caller's reused message list is never mutated.
        """
        cc = {"type": "ephemeral"}

        system_blocks: list[dict] = []
        remaining: list[dict] = []
        for msg in messages:
            if msg.get("role") == "system":
                system_blocks.append({"type": "text", "text": msg.get("content", "")})
            else:
                remaining.append(msg)

        if system_blocks:
            system_blocks[-1]["cache_control"] = cc
            extendParams = extra_body.setdefault("extendParams", {})
            extendParams["system"] = system_blocks
            messages = remaining

        if messages:
            messages = list(messages)
            last = dict(messages[-1])
            if last.get("role") == "tool":
                # tool results carry cache_control at the message level
                last["cache_control"] = cc
            else:
                content = last.get("content", "")
                if isinstance(content, str):
                    last["content"] = [
                        {"type": "text", "text": content, "cache_control": cc}
                    ]
                elif isinstance(content, list) and content:
                    blocks = [dict(b) for b in content]
                    blocks[-1] = {**blocks[-1], "cache_control": cc}
                    last["content"] = blocks
            messages[-1] = last

        if tools:
            import copy
            tools = copy.deepcopy(tools)
            func = tools[-1].get("function", tools[-1])
            func["cache_control"] = cc

        return messages, tools

    def _invoke(self, client: OpenAI, kwargs: dict) -> LLMResponse:
        if kwargs.get("stream", False):
            return self._chat_stream(client, kwargs)
        return self._chat_non_stream(client, kwargs)

    _VALID_FINISH_REASONS = frozenset({"stop", "length", None, ""})

    _FIRST_TOKEN_TIMEOUT = 120  # seconds to wait for first content chunk

    def _chat_stream(self, client: OpenAI, kwargs: dict) -> LLMResponse:
        import time

        stream = client.chat.completions.create(**kwargs)
        content_parts: list[str] = []
        usage = {}
        chunk_count = 0
        first_content_received = False
        stream_start = time.time()

        try:
            for chunk in stream:
                chunk_count += 1
                if chunk.usage:
                    usage = _usage(chunk.usage)
                if not chunk.choices:
                    if not first_content_received and time.time() - stream_start > self._FIRST_TOKEN_TIMEOUT:
                        raise LLMAPIError(
                            f"Stream timeout: no content after {self._FIRST_TOKEN_TIMEOUT}s "
                            f"({chunk_count} empty chunks received)"
                        )
                    continue
                choice = chunk.choices[0]
                if choice.finish_reason and choice.finish_reason.lower() not in self._VALID_FINISH_REASONS:
                    content_so_far = "".join(content_parts)
                    raise LLMAPIError(
                        f"API returned non-standard finish_reason='{choice.finish_reason}': "
                        f"{content_so_far[:200]}"
                    )
                if choice.delta and choice.delta.content:
                    content_parts.append(choice.delta.content)
                    first_content_received = True

        except BaseException as exc:
            exc.usage = usage
            raise
        finally:
            try:
                stream.close()
            except Exception:
                logger.warning("Failed to close response stream", exc_info=True)

        content = "".join(content_parts)

        logger.debug(
            "Raw response: len=%d, has_think=%s, chunks=%d, usage=%s, first_200=%r",
            len(content),
            "<think>" in content,
            chunk_count,
            usage,
            content[:200],
        )

        # 保留 thinking 内容用于记录，过滤后的 content 用于返回
        thinking = ""
        if "<think>" in content:
            import re
            think_matches = re.findall(r"<think>(.*?)</think>", content, flags=re.DOTALL)
            thinking = "\n".join(think_matches)
            logger.debug("Filtering <think> tags: think_content_len=%d, total_len=%d", len(thinking), len(content))
            content = re.sub(r"<think>.*?</think>", "", content, flags=re.DOTALL).strip()
            logger.debug("After filtering: remaining_len=%d", len(content))

        if not content.strip():
            raise LLMAPIError("API returned empty content", usage=usage)
        if content.strip().startswith('data: {"error"'):
            raise LLMAPIError(f"API returned error as content: {content[:200]}", usage=usage)

        return LLMResponse(
            content=content,
            tool_calls=None,
            usage=usage,
            raw={"thinking": thinking} if thinking else {},
        )

    def _chat_non_stream(self, client: OpenAI, kwargs: dict) -> LLMResponse:
        resp = client.chat.completions.create(**kwargs)
        usage = _usage(resp.usage)
        if not resp.choices:
            raise LLMAPIError("API returned no choices", usage=usage)
        choice = resp.choices[0]

        tool_calls_out = None
        if choice.message.tool_calls:
            tool_calls_out = [
                {
                    "id": tc.id,
                    "function": {
                        "name": tc.function.name,
                        "arguments": tc.function.arguments,
                    },
                }
                for tc in choice.message.tool_calls
            ]

        return LLMResponse(
            content=choice.message.content or "",
            tool_calls=tool_calls_out,
            usage=usage,
        )



class OpenAIResponsesLLM(OpenAIFallbackMixin, BaseLLM):
    """OpenAI Responses API provider (e.g. gpt-5.5 reasoning models).

    The rest of the system speaks Chat-Completions-shaped messages
    (assistant.tool_calls + role:"tool" results). This provider translates that
    canonical format into Responses `input` items on the way in, and normalizes
    the Responses output back into an LLMResponse on the way out, so callers
    (ReAct loop, agents) need no changes.
    """

    def __init__(self, config: LLMRoleConfig) -> None:
        super().__init__()
        self._init_clients(config)
        # OpenAI-native automatic caching is routed by prompt_cache_key; a stable
        # per-instance key keeps this role's calls hitting the same cache.
        self._cache_key: str | None = None
        if config.prompt_cache:
            import uuid
            self._cache_key = uuid.uuid4().hex

    def _chat_impl(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        tool_choice: str | dict | None = None,
    ) -> LLMResponse:
        instructions, input_items = self._to_responses_input(messages)

        kwargs: dict = {
            "model": self.config.model,
            "input": input_items,
        }
        if instructions:
            kwargs["instructions"] = instructions
        if self.config.max_tokens:
            kwargs["max_output_tokens"] = self.config.max_tokens
        if self.config.extra_body:
            kwargs["extra_body"] = self.config.extra_body
        if self._cache_key:
            kwargs["prompt_cache_key"] = self._cache_key
        if tools:
            kwargs["tools"] = [self._convert_tool(t) for t in tools]
        if tool_choice is not None:
            kwargs["tool_choice"] = self._convert_tool_choice(tool_choice)

        return self._run(kwargs)

    def _invoke(self, client: OpenAI, kwargs: dict) -> LLMResponse:
        resp = client.responses.create(**kwargs)
        return self._parse_response(resp)

    @staticmethod
    def _to_responses_input(messages: list[dict]) -> tuple[str, list[dict]]:
        """Convert Chat-Completions messages into (instructions, input_items).

        - system messages are concatenated into `instructions`
        - user/assistant text become role messages
        - assistant.tool_calls become `function_call` items
        - role:"tool" results become `function_call_output` items
        """
        system_parts: list[str] = []
        items: list[dict] = []
        for msg in messages:
            role = msg.get("role")
            if role == "system":
                if msg.get("content"):
                    system_parts.append(msg["content"])
            elif role == "tool":
                items.append({
                    "type": "function_call_output",
                    "call_id": msg.get("tool_call_id", ""),
                    "output": msg.get("content", "") or "",
                })
            elif role == "assistant":
                if msg.get("content"):
                    items.append({"role": "assistant", "content": msg["content"]})
                for tc in msg.get("tool_calls") or []:
                    fn = tc.get("function", {})
                    items.append({
                        "type": "function_call",
                        "call_id": tc.get("id", ""),
                        "name": fn.get("name", ""),
                        "arguments": fn.get("arguments", "{}") or "{}",
                    })
            else:  # user (or anything else) -> user message
                items.append({"role": "user", "content": msg.get("content", "") or ""})
        return "\n\n".join(system_parts), items

    def _parse_response(self, resp) -> LLMResponse:
        content_parts: list[str] = []
        reasoning_parts: list[str] = []
        tool_calls_out: list[dict] | None = None

        for item in getattr(resp, "output", None) or []:
            itype = getattr(item, "type", None)
            if itype == "message":
                for block in getattr(item, "content", None) or []:
                    if getattr(block, "type", None) == "output_text":
                        content_parts.append(getattr(block, "text", "") or "")
            elif itype == "function_call":
                if tool_calls_out is None:
                    tool_calls_out = []
                tool_calls_out.append({
                    "id": getattr(item, "call_id", "") or getattr(item, "id", ""),
                    "function": {
                        "name": getattr(item, "name", ""),
                        "arguments": getattr(item, "arguments", "{}") or "{}",
                    },
                })
            elif itype == "reasoning":
                for block in getattr(item, "summary", None) or []:
                    text = getattr(block, "text", "") or ""
                    if text:
                        reasoning_parts.append(text)

        content = "".join(content_parts)

        usage = _usage(getattr(resp, "usage", None), responses=True)

        if not content.strip() and not tool_calls_out:
            status = getattr(resp, "status", "")
            details = getattr(resp, "incomplete_details", "")
            raise LLMAPIError(
                f"Responses API returned no content/tool_calls "
                f"(status={status}, details={details})", usage=usage
            )

        thinking = "\n".join(reasoning_parts)
        return LLMResponse(
            content=content,
            tool_calls=tool_calls_out,
            usage=usage,
            raw={"thinking": thinking} if thinking else {},
        )

    @staticmethod
    def _convert_tool(openai_tool: dict) -> dict:
        """Chat-Completions tool -> Responses flat function tool."""
        func = openai_tool.get("function", openai_tool)
        return {
            "type": "function",
            "name": func["name"],
            "description": func.get("description", ""),
            "parameters": func.get("parameters", {"type": "object", "properties": {}}),
        }

    @staticmethod
    def _convert_tool_choice(choice):
        if isinstance(choice, dict) and "function" in choice:
            return {"type": "function", "name": choice["function"]["name"]}
        return choice  # "auto" / "none" / "required" pass through
