from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from ..harness.agent import BaseReActAgent
from ..tools.bash import BashTool
from ..tools.file import FileEditTool, FileReadTool, FileTreeTool, FileWriteTool
from ..tools.python_run import PythonRunTool
from ..tools.task import FinishTool
from ..tools.todo import TodoTool
from ..tools.web import WebSearchTool, WebVisitTool

if TYPE_CHECKING:
    from ..llm.base import BaseLLM

#: What a diagnostic worker is handed. Code-capable on purpose: most useful
#: diagnostics (distribution and coverage checks, correlation or drift analysis,
#: bad-case mining, verifying a feature parses the way the code assumes) have to
#: compute something new rather than re-read an artifact, and which computation
#: answers the Planner's question is decided per plan.
#:
#: `eval` is absent by construction, not by convention: a diagnostic that could
#: run the protected evaluation would be able to shop for a number, and producing
#: a candidate score is the executor's job.
_ANALYSIS_TOOLS = (
    "file_read",
    "file_tree",
    "file_write",
    "file_edit",
    "python_run",
    "bash",
    "web_search",
    "web_visit",
    "todo",
    "finish",
)


class AnalysisAgent(BaseReActAgent):
    """Diagnostic agent.

    A peer of the executor, not a variant: the executor computes to produce a
    candidate, the analysis agent computes to answer the Planner's question.
    The tool set is a framework decision — a task declares what to optimize,
    never how its agents are equipped.
    """

    name = "analysis"
    template_name = "analysis.j2"
    max_iterations = 80

    def __init__(
        self,
        llm: BaseLLM,
        working_dir: Path,
        *,
        execution_timeout: int = 1200,
        task_profile: dict | None = None,
        protected_paths: list[str] | None = None,
        editable_paths: list[str] | None = None,
        read_paths: tuple[Path, ...] = (),
        compression_llm: BaseLLM | None = None,
        prompt_renderer: "PromptRenderer | None" = None,
        model_context_length: int = 200_000,
        budget_start_time: float | None = None,
        budget_total_seconds: float = 3600,
    ) -> None:
        # Surface the per-run cap to the loop (time injection) and ToolContext.
        self.execution_timeout = execution_timeout
        self._task_profile = task_profile or {}
        self._protected_paths = protected_paths or []
        self._editable_paths = editable_paths or []
        self._read_paths = read_paths

        super().__init__(
            llm=llm,
            working_dir=working_dir,
            compression_llm=compression_llm,
            prompt_renderer=prompt_renderer,
            model_context_length=model_context_length,
            budget_start_time=budget_start_time,
            budget_total_seconds=budget_total_seconds,
        )

    def _register_tools(self) -> None:
        tools = {
            "bash": BashTool(),
            "file_read": FileReadTool(allowed_read_paths=self._read_paths),
            "file_write": FileWriteTool(
                protected_paths=self._protected_paths,
                editable_paths=self._editable_paths,
            ),
            "file_edit": FileEditTool(
                protected_paths=self._protected_paths,
                editable_paths=self._editable_paths,
            ),
            "file_tree": FileTreeTool(allowed_read_paths=self._read_paths),
            "python_run": PythonRunTool(),
            "web_search": WebSearchTool(),
            "web_visit": WebVisitTool(),
            "todo": TodoTool(),
            "finish": FinishTool(),
        }
        for name in _ANALYSIS_TOOLS:
            # Indexing, not .get(): a name that stops existing should break the
            # build loudly rather than quietly shrink what the agent can do while
            # analysis.j2 keeps promising it.
            self.tool_registry.register(tools[name])

    def get_runtime_context(self) -> dict:
        # analysis.j2 renders only what the task profile publishes
        # (task_description, metric, evaluation_rule, knowledge_summary, ...);
        # no executor-specific fields are needed here.
        ctx = dict(self._task_profile)
        ctx["task_context"] = self._task_profile
        return ctx

    def get_user_message(self) -> str:
        return (
            "Perform the analysis task described in plan.md in your current working directory.\n"
            "Read ./plan.md first, gather evidence (use paths relative to this "
            "directory), use any accumulated knowledge in the system prompt as prior "
            "context, and follow the constraints in your system prompt. Finish with "
            "actionable findings."
        )
