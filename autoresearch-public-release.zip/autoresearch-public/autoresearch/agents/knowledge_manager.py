"""KnowledgeManagerAgent — maintains the knowledge store from experiment summaries.

Processes experiment summaries, extracts patterns, and performs CRUD operations
on the knowledge store to keep insights accurate, non-redundant, and actionable.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Sequence

from ..harness.agent import BaseReActAgent
from ..harness.evidence import build_evidence_manifest
from ..tools.bash import BashTool
from ..tools.file import FileReadTool
from ..tools.knowledge import (
    KnowledgeAddTool,
    KnowledgeDeleteTool,
    KnowledgeInvalidateTool,
    KnowledgeLinkTool,
    KnowledgeListTool,
    KnowledgeUnlinkTool,
    KnowledgeUpdateTool,
)
from ..tools.task import FinishTool

if TYPE_CHECKING:
    from ..llm.base import BaseLLM
    from ..harness.knowledge import KnowledgeStore

logger = logging.getLogger(__name__)

MAX_SUMMARY_CHARS = 100_000


class KnowledgeManagerAgent(BaseReActAgent):
    name = "knowledge_manager"
    template_name = "knowledge_manager.j2"
    max_iterations = 50

    def __init__(
        self,
        llm: BaseLLM,
        working_dir: Path,
        *,
        knowledge_store: KnowledgeStore,
        summaries: str,
        summary_paths: Sequence[str] | None = None,
        task_type: str = "tabular",
        metric_info: dict | None = None,
        task_profile: dict | None = None,
        compression_llm: BaseLLM | None = None,
        prompt_renderer: "PromptRenderer | None" = None,
        model_context_length: int = 200_000,
        budget_start_time: float | None = None,
        budget_total_seconds: float = 600,
    ) -> None:
        self._knowledge_store = knowledge_store
        self._summaries = summaries
        self._summary_paths = [str(p) for p in (summary_paths or [])]
        self._task_type = task_type
        self._metric_info = metric_info or {}
        # Whatever TaskAdapter.get_task_context() returns, splatted into the
        # render context exactly as the other three agents do. This agent must
        # not know the name of any task-specific variable its prompt renders —
        # the task's knowledge_manager.j2 declares what it needs.
        self._task_profile = task_profile or {}

        super().__init__(
            llm=llm,
            working_dir=working_dir,
            compression_llm=compression_llm,
            prompt_renderer=prompt_renderer,
            model_context_length=model_context_length,
            budget_start_time=budget_start_time,
            budget_total_seconds=budget_total_seconds,
        )

    def _register_tools(self) -> None:
        self.tool_registry.register(KnowledgeListTool(self._knowledge_store))
        self.tool_registry.register(KnowledgeAddTool(self._knowledge_store))
        self.tool_registry.register(KnowledgeUpdateTool(self._knowledge_store))
        self.tool_registry.register(KnowledgeInvalidateTool(self._knowledge_store))
        self.tool_registry.register(KnowledgeLinkTool(self._knowledge_store))
        self.tool_registry.register(KnowledgeUnlinkTool(self._knowledge_store))
        self.tool_registry.register(KnowledgeDeleteTool(self._knowledge_store))
        self.tool_registry.register(FileReadTool())
        self.tool_registry.register(BashTool(readonly=True))
        self.tool_registry.register(FinishTool())

    def get_runtime_context(self) -> dict:
        summaries_block = self._build_summaries_block()
        ctx = dict(self._task_profile)
        ctx.update(
            {
                "summaries": summaries_block,
                "summary_paths": self._summary_paths,
                "existing_insights_count": len(self._knowledge_store.insights),
                # The planner decides which summaries to hand us, and in practice
                # hands only the current round's. Without an index of what else the
                # run has produced, a regularity that only exists across experiments
                # cannot be seen, let alone stored.
                "evidence_manifest": build_evidence_manifest(self.working_dir),
                # The same template serves the capped L2 store and the uncapped L3
                # one; it renders its capacity rule from this instead of hardcoding.
                "knowledge_capacity": self._knowledge_store.max_items,
                "task_type": self._task_type,
                "metric_info": self._metric_info,
                "task_profile": self._task_profile,
                "task_context": self._task_profile,
            }
        )
        return ctx

    def get_user_message(self) -> str:
        n_insights = len(self._knowledge_store.insights)
        return (
            f"Process the following experiment summaries and update the knowledge base.\n"
            f"Current knowledge store has {n_insights} insights.\n\n"
            f"The summaries in your system prompt cover only the experiments you were "
            f"handed this round — usually the latest one or two. The evidence index "
            f"lists everything else the run has produced. Treat the summaries as "
            f"pointers: when a finding would only hold if it also holds in the earlier "
            f"experiments, check them before you claim it, and check them before you "
            f"conclude a number is unavailable.\n\n"
            f"Start by listing current insights with `knowledge_list`."
        )

    def _build_summaries_block(self) -> str:
        parts: list[str] = []
        if self._summary_paths:
            loaded = []
            for raw_path in self._summary_paths:
                loaded.append(self._load_summary_path(raw_path))
            parts.append("Loaded L1 summaries from files:\n\n" + "\n\n".join(loaded))
        if self._summaries.strip():
            parts.append("Inline notes / legacy summary text:\n" + self._summaries.strip())
        if not parts:
            return "(no summaries provided)"
        return "\n\n".join(parts)

    def _load_summary_path(self, raw_path: str) -> str:
        path = self._confine_summary_path(raw_path)
        if path is None:
            return (
                f"--- summary_path: {raw_path}\n"
                "[unreadable: path is outside the working directory]"
            )
        if not path.exists():
            return f"--- summary_path: {raw_path}\n[unreadable: file not found]"
        if not path.is_file():
            return f"--- summary_path: {raw_path}\n[unreadable: not a file]"
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            return f"--- summary_path: {raw_path}\n[unreadable: {e}]"

        suffix = ""
        if len(text) > MAX_SUMMARY_CHARS:
            suffix = (
                f"\n[truncated to {MAX_SUMMARY_CHARS} chars from {len(text)} chars; "
                "use file_read on this path if more detail is needed]"
            )
            text = text[:MAX_SUMMARY_CHARS]
        return f"--- summary_path: {str(path)}\n{text}{suffix}"

    def _confine_summary_path(self, raw_path: str) -> Path | None:
        base = Path(os.path.normpath(str(self.working_dir)))
        p = Path(raw_path)
        candidate = p if p.is_absolute() else base / p
        candidate = Path(os.path.normpath(str(candidate)))
        if candidate == base or base in candidate.parents:
            return candidate
        return None
