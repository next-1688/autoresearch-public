"""KnowledgePromoterAgent — decides which run-local findings become durable.

Runs once, at the end of a run, and is the only writer of the task-level L3 store.
It reads this run's L2 claims and writes the subset worth carrying into the next
run against the L3 store, using the same claim schema, the same tools, and the
same task-specific system prompt as the KnowledgeManagerAgent it subclasses.

There is deliberately no rule deciding what graduates. Durability is a judgement
about whether a finding still holds once the search restarts from the anchor with
a different experiment sequence, and a threshold on confidence or evidence count
does not capture that — a twice-confirmed claim about one experiment's learning
rate is not durable, while a single clean observation about label sparsity is. So
the selection is left to the model, and only the mechanical part (separate cid
namespace, separate file, no cap) is enforced in code.
"""

from __future__ import annotations

import logging

from .knowledge_manager import KnowledgeManagerAgent

logger = logging.getLogger(__name__)


class KnowledgePromoterAgent(KnowledgeManagerAgent):
    name = "knowledge_promoter"
    # Reuses the task's knowledge_manager.j2: it carries the claim schema, the
    # insight prefixes, and the domain objective, all of which apply unchanged.
    # Only the instruction differs, and that lives in the user message.
    template_name = "knowledge_manager.j2"
    # A pass writes one claim per call, then one call per relation, and now also reads
    # every experiment's metrics.json first. A store of ~17 claims with ~20 relations
    # is already 37 calls before any knowledge_list refresh, so the old cap of 30 ran
    # out partway through linking — losing exactly the relation graph that makes the
    # claims navigable, and losing it silently.
    max_iterations = 80

    def get_user_message(self) -> str:
        n_durable = len(self._knowledge_store.insights)
        return (
            "This is the end-of-run promotion pass. You are writing to the "
            "**task-level (L3) knowledge store**, which persists across runs; it "
            f"currently holds {n_durable} claim(s). The block in your system "
            "prompt is not a set of experiment summaries — it is the finished "
            "run-local (L2) knowledge from the run that just ended.\n\n"
            "Your job: decide which of those findings are still true and still "
            "useful to a *fresh run* that restarts from the baseline anchor and "
            "will run a different sequence of experiments, then record exactly "
            "those against the L3 store.\n\n"
            "A finding carries over when it constrains or informs future work no "
            "matter what order experiments happen in — a durable property of the "
            "data or labels, a segment that repeatedly resists a whole family of "
            "approaches, a reproducible resource or execution constraint. A "
            "finding does not carry over when it only describes one experiment's "
            "settings or one particular path through this run's search; the next "
            "run will not have that experiment.\n\n"
            "Before you decide anything, do two passes the per-round Knowledge "
            "Manager could not do. It saw one or two experiments at a time; you have "
            "the whole run indexed in your system prompt, so a regularity that only "
            "exists across experiments is visible to you and to nobody else.\n"
            "1. Read the same fields out of every `metrics.json` in the evidence "
            "index and compare them. Look for a diagnostic that stayed flat (or moved "
            "the wrong way) while the primary metric moved — that is a proxy worth "
            "recording as uninformative — and for a quantity that barely varies across "
            "candidates in a way that caps how much any change can move the metric.\n"
            "2. Tally what the run actually tried, by family of change rather than by "
            "experiment: features, loss, capacity, duration, architecture, data. Then "
            "name the families it never touched. That negative space is the single "
            "most useful thing you can hand the next run, because otherwise it will "
            "re-enter whichever corner this run exhausted.\n\n"
            "Start with `knowledge_list` to see what L3 already holds. Then:\n"
            "- add genuinely new durable claims;\n"
            "- update an existing L3 claim when this run sharpened, widened, or "
            "narrowed it, rather than adding a near-duplicate;\n"
            "- invalidate an L3 claim this run contradicted, so it is retained as "
            "a do-not-re-propose record instead of quietly disappearing;\n"
            "- rewrite each claim to stand alone. Referring to `exp003` is useless "
            "in the next run, where that name means a different experiment. State "
            "what was observed and under what conditions, and keep the experiment "
            "name only as evidence.\n"
            "- write evidence pointers as `<run id> / <experiment name>`, NOT as a "
            "file path. A path like `working/exp004/metrics.json` is readable now and "
            "unreachable next run — its workspace is outside the next planner's "
            "readable area, so a pointer shaped like a path invites a read that comes "
            "back 'Access denied' and buys nothing. The run and experiment names are "
            "what survive; anything a later reader must actually know belongs in the "
            "claim text, not behind a link.\n\n"
            "Two failure modes to avoid, both of which produce a claim that looks "
            "durable and is not. A claim must not be an open question: \"X is "
            "unmeasured, someone should measure it\" is a plan, it belongs in a plan, "
            "and it goes stale the moment anyone measures it — where not-yet-measured "
            "genuinely bounds how far a claim can be trusted, write it as a caveat "
            "inside that claim. And a claim must not lean on a version the reader "
            "cannot see: \"the starting config already does X\" is meaningless in a run "
            "that starts somewhere else, so state the property outright.\n\n"
            "Promote nothing rather than pad the store: every claim you add is "
            "injected into every future planner prompt, so a vague or "
            "run-specific one costs attention in every later run. If nothing "
            "from this run generalizes, say so and finish."
        )
