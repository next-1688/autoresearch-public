"""ExecutorAgent — executes a single experiment plan iteratively.

Receives a plan directory as working_dir, reads plan.md, writes code,
runs experiments, diagnoses failures, fixes bugs, and ensures a valid submission.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from ..harness.agent import BaseReActAgent
from ..tools.bash import BashTool
from ..tools.eval import TaskEvalTool
from ..tools.file import FileEditTool, FileReadTool, FileTreeTool, FileWriteTool
from ..tools.python_run import PythonRunTool
from ..tools.task import FinishTool
from ..tools.todo import TodoTool

if TYPE_CHECKING:
    from ..llm.base import BaseLLM
    from ..task.adapter import TaskAdapter

logger = logging.getLogger(__name__)


class ExecutorAgent(BaseReActAgent):
    name = "executor"
    template_name = "executor.j2"
    max_iterations = 300

    def __init__(
        self,
        llm: BaseLLM,
        working_dir: Path,
        *,
        execution_timeout: int = 1200,
        task_profile: dict | None = None,
        hardware_constraint: str = "",
        protected_paths: list[str] | None = None,
        editable_paths: list[str] | None = None,
        read_paths: tuple[Path, ...] = (),
        task: TaskAdapter | None = None,
        compression_llm: BaseLLM | None = None,
        prompt_renderer: "PromptRenderer | None" = None,
        model_context_length: int = 200_000,
        context_options: dict | None = None,
        budget_start_time: float | None = None,
        budget_total_seconds: float = 3600,
    ) -> None:
        self._execution_timeout = execution_timeout
        # Surface the per-run cap to the loop (time injection) and ToolContext.
        self.execution_timeout = execution_timeout
        self._task_profile = task_profile or {}
        self._hardware_constraint = hardware_constraint
        self._protected_paths = protected_paths or []
        self._editable_paths = editable_paths or []
        self._read_paths = read_paths
        self._task = task

        super().__init__(
            llm=llm,
            working_dir=working_dir,
            compression_llm=compression_llm,
            prompt_renderer=prompt_renderer,
            model_context_length=model_context_length,
            context_options=context_options,
            budget_start_time=budget_start_time,
            budget_total_seconds=budget_total_seconds,
        )

    def _register_tools(self) -> None:
        self.tool_registry.register(BashTool())
        self.tool_registry.register(FileReadTool(allowed_read_paths=self._read_paths))
        self.tool_registry.register(
            FileWriteTool(
                protected_paths=self._protected_paths,
                editable_paths=self._editable_paths,
            )
        )
        self.tool_registry.register(
            FileEditTool(
                protected_paths=self._protected_paths,
                editable_paths=self._editable_paths,
            )
        )
        self.tool_registry.register(FileTreeTool(allowed_read_paths=self._read_paths))
        self.tool_registry.register(PythonRunTool())
        self.tool_registry.register(TodoTool())
        self.tool_registry.register(FinishTool())
        if self._task is not None:
            self.tool_registry.register(TaskEvalTool(self._task))

    def get_runtime_context(self) -> dict:
        tp = self._task_profile
        timeout = self._execution_timeout

        model_complexity = self._build_model_complexity_constraint(timeout)
        has_gpu = tp.get("hardware", {}).get("has_gpu", False)
        installed = tp.get("hardware", {}).get("installed_packages", [])
        submission_spec = tp.get("submission_spec")

        ctx = {
            "execution_timeout": timeout,
            "steps_remaining": tp.get("steps_remaining"),
            "steps_total": tp.get("steps_total"),
            "model_complexity_constraint": model_complexity,
            "hardware_constraint": self._hardware_constraint,
            "has_gpu": has_gpu,
            "installed_packages": ", ".join(installed) if installed else "",
            "submission_spec": submission_spec,
            "model_strategy": tp.get("model_strategy", ""),
        }
        ctx.update(tp)
        ctx["task_context"] = tp
        return ctx

    def get_user_message(self) -> str:
        plan_path = self.working_dir / "plan.md"
        paradigm = self._task_profile.get("paradigm", "ml_competition")

        # Keep prompts ./-relative because file tools join relative paths under working_dir.
        if plan_path.exists():
            if paradigm == "harness_optimization":
                return (
                    "Implement the harness improvement plan in your current working directory.\n"
                    "Read ./plan.md first, then modify the agent code and run evaluation.\n"
                    "Use paths relative to this directory."
                )
            return (
                "Execute the experiment plan in your current working directory.\n"
                "Read ./plan.md first, then implement and run the experiment.\n"
                "Use ./input/ for competition data and paths relative to this directory."
            )

        if paradigm == "harness_optimization":
            return (
                "Work in your current working directory.\n"
                "Read the agent code and implement an improvement. "
                "Use paths relative to this directory."
            )
        return (
            "Work in your current working directory.\n"
            "Explore the data and implement an ML experiment. "
            "Use paths relative to this directory."
        )

    def _build_model_complexity_constraint(self, timeout: int) -> str:
        if timeout <= 600:
            return (
                "## Model Complexity Constraint (MANDATORY)\n"
                f"Execution timeout is only {timeout}s. You MUST use the simplest viable approach:\n"
                "- NO cross-validation (use single 80/20 split)\n"
                "- NO large models (max: logistic regression, small CNN, TF-IDF+LightGBM)\n"
                "- NO more than 5 training epochs for neural networks\n"
                "- Target total training time: <400s"
            )
        elif timeout <= 1800:
            return (
                "## Model Complexity Constraint (MANDATORY)\n"
                f"Execution timeout is {timeout}s. Use moderate complexity:\n"
                "- Max 3-fold CV (not 5-fold)\n"
                "- Models: ResNet18, EfficientNet-B0, LightGBM, XGBoost\n"
                "- Max 15 epochs for neural networks\n"
                "- Target total training time: <1200s"
            )
        elif timeout <= 3600:
            return (
                "## Model Complexity Constraint (ADVISORY)\n"
                f"Execution timeout is {timeout}s. Standard complexity allowed:\n"
                "- Max 3-fold CV\n"
                "- Models: ResNet50, EfficientNet-B2, DeBERTa-base\n"
                "- Max 20 epochs for neural networks\n"
                "- Target total training time: <2500s"
            )
        safe_budget = int(timeout * 0.85)
        return (
            "## Model Complexity Constraint (ADVISORY)\n"
            f"Execution timeout is {timeout}s ({timeout // 60} minutes). "
            f"Safe training budget: {safe_budget}s ({safe_budget // 60} minutes).\n"
            "- For image tasks: each epoch on ~27k images with EfficientNet typically takes ~250s.\n"
            f"  Max feasible: {safe_budget // 250} total epochs across all folds.\n"
            f"  Example: 3-fold × {safe_budget // 250 // 3} epochs, or 2-fold × {safe_budget // 250 // 2} epochs.\n"
            "- Prefer fewer folds with more epochs (better convergence per fold).\n"
            "- Use early stopping to avoid wasting time on converged models.\n"
            "- Reserve 10-15% of timeout for data loading, prediction, and submission saving."
        )
