"""PlannerAgent — the strategic entry point for ReAct-based experiment management.

The Planner analyzes tasks, designs experiment plans, dispatches sub-agents,
and iterates based on results. It orchestrates the full lifecycle:
planning → execution → summarization → knowledge update.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Callable

from ..harness.agent import BaseReActAgent
from ..harness.subagent import SubAgentManager
from ..tools.bash import BashTool
from ..tools.file import FileReadTool, FileTreeTool
from ..tools.plan import PlanEditTool, PlanReadTool, PlanWriteTool
from ..tools.knowledge import KnowledgeListTool
from ..tools.task import BackgroundJobRegistry, FinishTool, TaskJoinTool, TaskSpawnTool
from ..tools.todo import TodoTool

if TYPE_CHECKING:
    from ..llm.base import BaseLLM
    from ..harness.knowledge import KnowledgeStore

logger = logging.getLogger(__name__)

# Directories holding evaluation ground truth. Kept out of the planner's read
# tools; note that bash is not path-confined, so this is a guard against
# accidental access, not an enforced boundary.
_HELD_OUT_DIRS = (".labels",)

#: Hidden from `file_tree` but not from `file_read`: the card library is 69 files
#: deep enough to crowd out the run's own tree, and the planner navigates it by
#: INDEX.md rather than by listing it.
_TREE_HIDDEN_DIRS = _HELD_OUT_DIRS + ("knowledge",)


class PlannerAgent(BaseReActAgent):
    name = "planner"
    template_name = "planner.j2"
    max_iterations = 1000

    def __init__(
        self,
        llm: BaseLLM,
        working_dir: Path,
        *,
        task_description: str,
        task_profile: dict,
        knowledge_store: KnowledgeStore | None = None,
        task_knowledge_store: KnowledgeStore | None = None,
        agent_factory_map: dict[str, Callable] | None = None,
        subagent_manager: SubAgentManager | None = None,
        subagent_managers: dict[str, SubAgentManager] | None = None,
        hardware_constraint: str = "",
        orientation_text: str = "",
        experiment_history: str = "",
        best_score: float | None = None,
        compression_llm: BaseLLM | None = None,
        prompt_renderer: "PromptRenderer | None" = None,
        model_context_length: int = 200_000,
        budget_start_time: float | None = None,
        budget_total_seconds: float = 10800,
    ) -> None:
        self._task_description = task_description
        self._task_profile = task_profile
        self._knowledge_store = knowledge_store
        self._task_knowledge_store = task_knowledge_store
        self._agent_factory_map = agent_factory_map or {}
        self._subagent_manager = subagent_manager or SubAgentManager()
        self._subagent_managers = subagent_managers or {}
        self._hardware_constraint = hardware_constraint
        self._orientation_text = orientation_text
        self._experiment_history = experiment_history
        self._best_score = best_score

        super().__init__(
            llm=llm,
            working_dir=working_dir,
            compression_llm=compression_llm,
            prompt_renderer=prompt_renderer,
            model_context_length=model_context_length,
            budget_start_time=budget_start_time,
            budget_total_seconds=budget_total_seconds,
        )

    def _register_tools(self) -> None:
        self.tool_registry.register(BashTool(readonly=True))
        # The planner's working_dir is only <run>/working, but the material it
        # must read (input/, accepted/, traces/) lives in the run workspace one
        # level up. Confining the read tools to working_dir forced every lookup
        # through bash; widen them to the run workspace instead, minus the
        # held-out label directory.
        read_root = self.working_dir.parent
        self.tool_registry.register(
            FileReadTool(
                read_root=read_root, deny_names=_HELD_OUT_DIRS,
                allowed_read_paths=(Path(__file__).resolve().parents[1] / "knowledge",),
            )
        )
        self.tool_registry.register(
            FileTreeTool(read_root=read_root, deny_names=_TREE_HIDDEN_DIRS)
        )
        self.tool_registry.register(PlanWriteTool())
        self.tool_registry.register(PlanReadTool())
        self.tool_registry.register(PlanEditTool())
        self.tool_registry.register(TodoTool())
        self.tool_registry.register(FinishTool())


        if self._knowledge_store:
            self.tool_registry.register(KnowledgeListTool(self._knowledge_store))

        if self._agent_factory_map:
            # One shared registry lets background task_spawn jobs and task_join
            # see the same handles, so executor and analysis batches can overlap.
            background_registry = BackgroundJobRegistry()
            self.tool_registry.register(
                TaskSpawnTool(
                    self._subagent_manager,
                    self._agent_factory_map,
                    manager_by_agent_type=self._subagent_managers,
                    background_registry=background_registry,
                )
            )
            self.tool_registry.register(TaskJoinTool(background_registry))

    def _kb_index(self) -> str | None:
        """Path to the technique-card index, as the planner's file tools take it.

        Relative to working_dir: the cards live outside the run workspace and are
        reachable only through the link `run()` puts at its root.
        """
        rel = "../knowledge/INDEX.md"
        return rel if (self.working_dir / rel).exists() else None

    def get_runtime_context(self) -> dict:
        # L3 first, then L2: durable findings carried in from earlier runs set the
        # frame, and this run's own observations refine it. Both go into the single
        # `knowledge_summary` variable the prompts already render, so neither layer
        # needs a template change and a task without an L3 store behaves as before.
        blocks = []
        if self._task_knowledge_store:
            blocks.append(self._task_knowledge_store.format_for_prompt())
        if self._knowledge_store:
            blocks.append(self._knowledge_store.format_for_prompt())
        knowledge_summary = "\n\n".join(b for b in blocks if b)

        metric = self._task_profile.get("metric", "unknown")
        metric_direction = self._task_profile.get("metric_direction", "maximize")

        ctx = {
            "task_description": self._task_description,
            "task_profile": self._task_profile,
            "hardware_constraint": self._hardware_constraint,
            "knowledge_summary": knowledge_summary,
            "orientation_text": self._orientation_text,
            "experiment_history": self._experiment_history,
            "best_score": self._best_score,
            "metric": metric,
            "metric_direction": metric_direction,
            "budget_total_seconds": self._budget_total,
            "budget_remaining_seconds": self.get_budget_remaining(),
            "kb_index": self._kb_index(),
        }
        ctx.update(self._task_profile)
        ctx["task_context"] = self._task_profile
        return ctx

    def get_user_message(self) -> str:
        # The task description is already rendered into the system prompt by
        # planner.j2 (### Task); repeating it here duplicated several KB per
        # call, so only the kickoff instruction lives in the user message.
        paradigm = self._task_profile.get("paradigm", "ml_competition")
        if paradigm == "harness_optimization":
            return (
                f"Begin optimizing the harness for this task.\n\n"
                f"Your working directory is: {self.working_dir}\n"
                f"Read the agent code, check knowledge base, and create your first improvement plan."
            )
        return (
            f"Begin working on this ML competition task.\n\n"
            f"Your working directory is: {self.working_dir}\n"
            + (
                "Create your first solution experiment plan."
                if self._task_profile.get("ablation", {}).get("solution_only")
                else "Explore the data and create your first experiment plan."
            )
        )
