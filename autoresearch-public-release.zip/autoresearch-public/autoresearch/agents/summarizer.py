"""SummaryAgent — analyzes completed experiments and produces structured summaries.

Combines the Evaluator's diagnostic rigor (3-layer analysis) with the
Reflector's analytical depth (structured reflection).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from ..harness.agent import BaseReActAgent
from ..tools.bash import BashTool
from ..tools.file import FileReadTool, FileTreeTool
from ..tools.task import FinishTool

if TYPE_CHECKING:
    from ..llm.base import BaseLLM

logger = logging.getLogger(__name__)


class SummaryAgent(BaseReActAgent):
    name = "summarizer"
    template_name = "summarizer.j2"
    max_iterations = 50

    def __init__(
        self,
        llm: BaseLLM,
        working_dir: Path,
        *,
        task_profile: dict | None = None,
        parent_score: float | None = None,
        compression_llm: BaseLLM | None = None,
        prompt_renderer: "PromptRenderer | None" = None,
        model_context_length: int = 200_000,
        budget_start_time: float | None = None,
        budget_total_seconds: float = 600,
    ) -> None:
        self._task_profile = task_profile or {}
        self._parent_score = parent_score

        super().__init__(
            llm=llm,
            working_dir=working_dir,
            compression_llm=compression_llm,
            prompt_renderer=prompt_renderer,
            model_context_length=model_context_length,
            budget_start_time=budget_start_time,
            budget_total_seconds=budget_total_seconds,
        )

    def _register_tools(self) -> None:
        self.tool_registry.register(FileReadTool())
        self.tool_registry.register(FileTreeTool())
        self.tool_registry.register(BashTool(readonly=True))
        self.tool_registry.register(FinishTool())

    def get_runtime_context(self) -> dict:
        ctx = {
            "task_profile": self._task_profile,
            "parent_score": self._parent_score,
        }
        ctx.update(self._task_profile)
        ctx["task_context"] = self._task_profile
        return ctx

    def get_user_message(self) -> str:
        paradigm = self._task_profile.get("paradigm", "ml_competition")
        if paradigm == "harness_optimization":
            return (
                "Analyze the completed harness optimization experiment in your current working directory.\n\n"
                "Read the plan (./plan.md), the modified agent code, and any output logs "
                "(use paths relative to this directory). "
                "Look for the evaluation score and error patterns.\n"
                "Produce a structured JSON summary and call `finish` with it.\n\n"
                f"IMPORTANT: Include \"working_dir\": \"{self.working_dir}\" in your JSON output."
            )
        return (
            "Analyze the completed experiment in your current working directory.\n\n"
            "Read the plan (./plan.md), code (./runfile.py), and any output logs "
            "(use paths relative to this directory). "
            "Check for submission files and saved artifacts.\n"
            "Produce a structured JSON summary and call `finish` with it.\n\n"
            f"IMPORTANT: Include \"working_dir\": \"{self.working_dir}\" in your JSON output "
            f"so the KnowledgeManager can trace back to the original files."
        )
