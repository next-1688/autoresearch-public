from __future__ import annotations

import math
import os
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field, field_validator, model_validator


class LLMRoleConfig(BaseModel):
    """解析后的角色 LLM 配置（供 registry 使用）"""
    provider: Literal["openai", "openai_responses", "anthropic", "google"] = "openai"
    model: str = ""
    api_key: str = ""
    base_url: str | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    timeout: int = 300
    extra_headers: dict[str, str] | None = None
    extra_body: dict | None = None
    prompt_cache: bool = False
    fallback_base_url: str | None = None
    fallback_api_key: str | None = None
    fallback_extra_headers: dict[str, str] | None = None
    include_stream_usage: bool = True
    input_tokens_include_cache: bool = True
    # USD per million tokens. Omit when the endpoint's price is unknown.
    pricing: dict[str, float] | None = None

    @field_validator("pricing")
    @classmethod
    def validate_pricing(cls, value):
        if value is not None:
            if not {"input_per_million", "output_per_million"}.issubset(value):
                raise ValueError("pricing requires input_per_million and output_per_million")
            if any(not math.isfinite(rate) or rate < 0 for rate in value.values()):
                raise ValueError("pricing rates must be finite and nonnegative")
        return value


class BudgetConfig(BaseModel):
    total_time_seconds: int = 14400
    max_concurrent: int = 2
    analysis_max_concurrent: int = 3


class WatchdogSettings(BaseModel):
    enabled: bool = True
    poll_interval: float = 0.5
    kill_on_anomaly: bool = True
    term_grace_seconds: float = 5.0


class RunnerConfig(BaseModel):
    type: Literal["local"] = "local"
    timeout: int = 3600
    watchdog: WatchdogSettings = WatchdogSettings()


class HardwareConfig(BaseModel):
    compute_tier: str = "auto"
    inject_constraint: bool = True


class MemoryConfig(BaseModel):
    l2_max_items: int = 12


class TaskSettings(BaseModel):
    """How this machine runs whatever task is loaded.

    Deliberately here and not in the task's document. A decision like offering
    diagnostic agents describes the hardware and the schedule of one run —
    the same task gets different ones on a laptop and on a GPU host, and a
    value written into the document would travel with the task and be wrong
    everywhere else.
    """

    analysis_agents: bool = True


class ExecutorContextConfig(BaseModel):
    """Opt-in cost budget, separate from the model's physical context window."""

    soft_limit_tokens: int | None = Field(default=None, ge=4096)
    target_tokens: int = Field(default=16000, ge=1024)
    tail_tokens: int = Field(default=8000, ge=256)
    summary_tokens: int = Field(default=2000, ge=256)

    @model_validator(mode="after")
    def validate_budgets(self):
        if self.soft_limit_tokens is not None:
            if self.target_tokens >= self.soft_limit_tokens:
                raise ValueError("executor context target must be below soft_limit_tokens")
            if self.tail_tokens + self.summary_tokens >= self.target_tokens:
                raise ValueError("executor tail plus summary must leave room for the system/task messages")
        return self


class AblationConfig(BaseModel):
    """Independent switches restored from the legacy MLE-bench experiments."""

    single_executor: bool = False
    solution_only: bool = False
    no_knowledge_mgmt: bool = False

    @property
    def method_label(self) -> str:
        enabled = [name for name, value in self.model_dump().items() if value]
        return "+".join(enabled) or "full"


class AutoResearchConfig(BaseModel):
    llm: dict[str, LLMRoleConfig]
    budget: BudgetConfig = BudgetConfig()
    runner: RunnerConfig = RunnerConfig()
    hardware: HardwareConfig = HardwareConfig()
    memory: MemoryConfig = MemoryConfig()
    task: TaskSettings = TaskSettings()
    executor_context: ExecutorContextConfig = ExecutorContextConfig()
    ablation: AblationConfig = AblationConfig()
    k_fold_validation: int = 5


def _expand_env(value: str) -> str:
    if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
        env_key = value[2:-1]
        return os.environ.get(env_key, "")
    return value


def _expand_env_recursive(obj):
    if isinstance(obj, dict):
        return {k: _expand_env_recursive(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_expand_env_recursive(v) for v in obj]
    if isinstance(obj, str):
        return _expand_env(obj)
    return obj


def _resolve_roles(raw: dict) -> dict[str, LLMRoleConfig]:
    """将 models + roles + llm_settings 解析为按角色组织的 LLMRoleConfig"""
    models: dict = raw.get("models", {})
    roles: dict = raw.get("roles", {})
    settings: dict = raw.get("llm_settings", {})

    resolved: dict[str, LLMRoleConfig] = {}
    for role, model_key in roles.items():
        model_cfg = models.get(model_key)
        if not model_cfg:
            raise ValueError(
                f"Role '{role}' references unknown model '{model_key}'. "
                f"Available models: {list(models.keys())}"
            )
        fallback = model_cfg.get("fallback", {})
        resolved[role] = LLMRoleConfig(
            provider=model_cfg.get("provider", "openai"),
            model=model_cfg.get("model_name", ""),
            api_key=model_cfg.get("api_key", ""),
            base_url=model_cfg.get("base_url"),
            temperature=settings.get("temperature"),
            max_tokens=model_cfg.get("max_tokens", settings.get("max_tokens")),
            timeout=settings.get("timeout", 300),
            extra_headers=model_cfg.get("extra_headers"),
            extra_body=model_cfg.get("extra_body"),
            prompt_cache=model_cfg.get("prompt_cache", False),
            fallback_base_url=fallback.get("base_url"),
            fallback_api_key=fallback.get("api_key"),
            fallback_extra_headers=fallback.get("extra_headers"),
            include_stream_usage=model_cfg.get("include_stream_usage", True),
            input_tokens_include_cache=model_cfg.get("input_tokens_include_cache", True),
            pricing=model_cfg.get("pricing"),
        )
    return resolved


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge `override` onto `base`. Nested dicts merge key-by-key;
    scalars and lists in `override` replace those in `base`."""
    result = dict(base)
    for key, value in override.items():
        if (
            key in result
            and isinstance(result[key], dict)
            and isinstance(value, dict)
        ):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _load_raw_with_extends(config_path: Path, _seen: set[Path] | None = None) -> dict:
    """Load a YAML config, resolving an optional top-level `extends: <path>` by
    deep-merging this file over its parent. `extends` is relative to the file's
    own directory and may chain; cycles raise ValueError."""
    config_path = config_path.resolve()
    _seen = _seen if _seen is not None else set()
    if config_path in _seen:
        chain = " -> ".join(str(p) for p in (*_seen, config_path))
        raise ValueError(f"Circular config extends detected: {chain}")
    _seen.add(config_path)

    with open(config_path) as f:
        raw = yaml.safe_load(f) or {}

    parent_ref = raw.pop("extends", None)
    if parent_ref:
        parent_path = config_path.parent / parent_ref
        parent_raw = _load_raw_with_extends(parent_path, _seen)
        raw = _deep_merge(parent_raw, raw)
    return raw


def load_config(config_path: Path) -> AutoResearchConfig:
    from dotenv import load_dotenv
    load_dotenv(config_path.parent.parent / ".env", override=False)
    load_dotenv(config_path.parent / ".env", override=False)

    raw = _load_raw_with_extends(config_path)
    expanded = _expand_env_recursive(raw)

    llm = _resolve_roles(expanded)

    return AutoResearchConfig(
        llm=llm,
        budget=BudgetConfig(**expanded.get("budget", {})),
        runner=RunnerConfig(**expanded.get("runner", {})),
        hardware=HardwareConfig(**expanded.get("hardware", {})),
        memory=MemoryConfig(**expanded.get("memory", {})),
        task=TaskSettings(**expanded.get("task", {})),
        executor_context=ExecutorContextConfig(**expanded.get("executor_context", {})),
        ablation=AblationConfig(**expanded.get("ablation", {})),
        k_fold_validation=expanded.get("k_fold_validation", 5),
    )
