from .react_main import main

main()
