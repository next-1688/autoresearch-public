"""ReAct agent entry point.

Usage:
    python -m autoresearch --task-dir tasks/example_rmse
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

#: Fallback when neither the adapter's task context nor the Profiler declared a
#: task_type. It keys cross-run knowledge retrieval, so guessing a modality here
#: would match another task's recipes; matching nothing is the safer failure.
#: Two call sites used to default differently ("harness_optimization" vs
#: "tabular"), which silently split one run's knowledge across two keys.
DEFAULT_TASK_TYPE = "unknown"


def _ensure_hf_mirror() -> None:
    if os.environ.get("HF_ENDPOINT"):
        return
    import urllib.request
    try:
        urllib.request.urlopen("https://huggingface.co", timeout=5)
    except Exception:
        mirror = "https://hf-mirror.com"
        os.environ["HF_ENDPOINT"] = mirror
        logger.info("huggingface.co unreachable, using mirror: %s", mirror)


_ensure_hf_mirror()

from .config.settings import AutoResearchConfig, ExecutorContextConfig, load_config
from .utils.hardware import detect_hardware
from .harness.prompt import PromptRenderer
from .harness.subagent import SubAgentManager
from .harness.telemetry import agent_activity, get_recorder
from .llm.base import BaseLLM
from .llm.registry import LLMRegistry
from .harness.knowledge import KnowledgeStore
from .agents.executor import ExecutorAgent
from .agents.analysis import AnalysisAgent
from .agents.knowledge_manager import KnowledgeManagerAgent
from .agents.knowledge_promoter import KnowledgePromoterAgent
from .agents.planner import PlannerAgent
from .agents.summarizer import SummaryAgent
from .task.adapter import TaskAdapter
from .task.generic import GenericAdapter
from .task.registry import create_adapter
from .tools.eval import write_metrics_record


def _finalize(task: TaskAdapter, workspace_dir: Path) -> dict[str, Any]:
    """Publish the accepted model's snapshot as this run's deliverable.

    What gets published is the accepted incumbent's snapshot, not the
    best-scoring file lying around the workspace: a run whose highest number came
    from a candidate that was rejected must not ship it.

    The whole snapshot, by link rather than by copy. The framework does not know
    which file in there is the model — that is the task's own rule, the one
    ``artifact_issues`` carries — so it hands back everything the experiment
    produced instead of choosing. Copying would duplicate an 80MB preprocessor to
    deliver what the snapshot already holds, and would have to guess per entry
    whether it is a file or a directory; the predictions file alone was the wrong
    answer twice over, since it is the least useful thing in there to anyone who
    already has the validation labels. The link is relative so the run directory
    stays movable.

    The number in the report is the search-time score, and the report says so. A
    task hands in training data and validation data; there is no third split the
    framework could grade against, and presenting the validation score as an
    independent verdict would be claiming one that was never computed.
    """
    report: dict[str, Any] = {
        "metric": task.metric_name,
        "score_split": task.score_split,
        "evaluation_protocol": task.evaluation_protocol,
        "note": task.evaluation_note,
    }
    if hasattr(task, "competition_id"):
        report["competition_id"] = task.competition_id

    selector = getattr(task, "select_final_snapshot", None)
    snapshot = selector(workspace_dir) if callable(selector) else None
    if snapshot is None:
        logger.warning("no accepted model to finalize; nothing was promoted this run")
        report["deliverable"] = None
        _write_json(workspace_dir / "final_report.json", report)
        return report

    link = workspace_dir / "final"
    # Only ever replace a link this function made. A real directory at that name
    # belongs to something else, and refusing to remove it costs one warning
    # whereas guessing costs whatever was inside it.
    published = True
    if link.is_symlink():
        link.unlink()
    elif link.exists():
        logger.warning(
            "not linking: %s exists and is not a symlink; the deliverable is at %s",
            link,
            snapshot,
        )
        published = False
    if published:
        link.symlink_to(
            os.path.relpath(snapshot.resolve(), workspace_dir.resolve()),
            target_is_directory=True,
        )
        logger.info("deliverable: %s -> %s", link, snapshot)
        report["final"] = str(link)

    report["deliverable"] = str(snapshot)
    report["experiment"] = snapshot.name
    # Names only, never contents — the same restraint harness/evidence.py keeps:
    # say what is there and let the reader open what they need.
    try:
        report["contents"] = sorted(
            entry.name + ("/" if entry.is_dir() else "")
            for entry in snapshot.iterdir()
        )
    except OSError as exc:
        logger.warning("could not list deliverable contents: %s", exc)

    incumbent_metrics = snapshot / "metrics.json"
    if incumbent_metrics.is_file():
        try:
            metrics = json.loads(incumbent_metrics.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("accepted model's metrics.json is unreadable: %s", exc)
        else:
            report["score"] = metrics.get(task.metric_name, metrics.get("score"))
            report[task.baseline_metric_key] = metrics.get(task.baseline_metric_key)
            report["segments"] = metrics.get("segments")
    _write_json(workspace_dir / "final_report.json", report)
    return report


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n",
        encoding="utf-8",
    )


def _auto_evaluate_plan_if_needed(
    task: TaskAdapter,
    working_dir: Path,
    *,
    execution_timeout: int,
    agent_name: str = "executor_auto_eval",
) -> None:
    relpath = getattr(task, "submission_relpath", "submission/submission.csv")
    submission_path = working_dir / relpath
    metrics_path = working_dir / "metrics.json"
    if not submission_path.exists() or metrics_path.exists():
        return

    allowed = getattr(task, "allowed_eval_splits", None)
    split = "dev" if not allowed or "dev" in allowed else sorted(allowed)[0]
    try:
        logger.info("Auto-evaluating %s because submission exists but metrics.json is missing", working_dir)
        result = task.evaluate(
            working_dir,
            split=split,
            execution_timeout=execution_timeout,
        )
        write_metrics_record(
            task,
            working_dir,
            split,
            result,
            agent_name=agent_name,
        )
        if result.get("valid"):
            logger.info("Auto-eval score for %s: %s", working_dir.name, result.get("score"))
        else:
            logger.warning("Auto-eval failed for %s: %s", working_dir.name, result.get("details"))
    except Exception as e:
        logger.warning("Auto-evaluate failed for %s: %s", working_dir, e)


def _task_read_paths(task: TaskAdapter, workspace_dir: Path) -> tuple[Path, ...]:
    """Grant shared input and declared local data, never the whole task directory."""
    paths = [workspace_dir / "input"]
    for location in getattr(task, "agent_visible_locations", {}).values():
        value = str(location)
        if "://" not in value:
            paths.append(Path(value))
    return tuple(path.resolve() for path in paths)


def make_executor_factory(
    llm_registry: LLMRegistry,
    task_profile: dict,
    hardware_constraint: str,
    runner_timeout: int,
    budget_start_time: float,
    budget_total_seconds: float,
    workspace_dir: Path,
    task: TaskAdapter,
    protected_paths: list[str] | None = None,
    editable_paths: list[str] | None = None,
    prompt_renderer: "PromptRenderer | None" = None,
    executor_context: ExecutorContextConfig | None = None,
):
    def factory(plan_dir: str):
        working_dir = Path(plan_dir)
        task.prepare_executor_workspace(working_dir, workspace_dir)
        remaining = max(300, budget_total_seconds - (time.time() - budget_start_time))
        effective_timeout = min(runner_timeout, int(remaining))
        effective_timeout = max(300, effective_timeout)
        executor = ExecutorAgent(
            llm=llm_registry.get("code_generator"),
            working_dir=working_dir,
            execution_timeout=effective_timeout,
            task_profile=task_profile,
            hardware_constraint=hardware_constraint,
            protected_paths=protected_paths,
            editable_paths=editable_paths,
            read_paths=_task_read_paths(task, workspace_dir),
            task=task,
            compression_llm=llm_registry.get("evaluator"),
            context_options=(
                executor_context.model_dump()
                if executor_context is not None and executor_context.soft_limit_tokens is not None
                else None
            ),
            prompt_renderer=prompt_renderer,
            budget_start_time=time.time(),
            budget_total_seconds=effective_timeout * 3,
        )
        _original_run = executor.run
        def _run_with_sync():
            mode_reader = getattr(task, "_read_experiment_mode", lambda path: "unknown")
            with agent_activity("executor", working_dir, mode=mode_reader(working_dir)) as outcome:
                try:
                    result = _original_run()
                finally:
                    try:
                        task.cleanup_plan_artifacts(working_dir)
                    except Exception as exc:
                        logger.warning("Post-run artifact cleanup failed for %s: %s", working_dir, exc)
                _auto_evaluate_plan_if_needed(task, working_dir, execution_timeout=effective_timeout)
                if result.success and hasattr(task, "sync_best_result"):
                    task.sync_best_result(working_dir, workspace_dir)
                outcome["success"] = result.success
                return result
        executor.run = _run_with_sync
        return executor
    return factory


def make_analysis_factory(
    llm_registry: LLMRegistry,
    task_profile: dict,
    runner_timeout: int,
    budget_start_time: float,
    budget_total_seconds: float,
    workspace_dir: Path,
    task: TaskAdapter,
    protected_paths: list[str] | None = None,
    editable_paths: list[str] | None = None,
    prompt_renderer: "PromptRenderer | None" = None,
    knowledge_store=None,
    task_knowledge_store=None,
):
    """Factory for diagnostic sub-agents (EDA, bad-case analysis, ...).

    Same shape as an executor, minus two things: a narrower tool set the agent
    defines itself (see agents/analysis.py), and NO sync-back — analysis writes
    only inside its own plan_dir and must not copy results into the shared
    workspace, which would race a concurrently running executor.
    """
    analysis_llm = (
        llm_registry.get("analysis")
        if llm_registry.has("analysis")
        else llm_registry.get("evaluator")
    )

    def factory(plan_dir: str):
        working_dir = Path(plan_dir)
        task.prepare_analysis_workspace(working_dir, workspace_dir)
        remaining = max(300, budget_total_seconds - (time.time() - budget_start_time))
        effective_timeout = max(300, min(runner_timeout, int(remaining)))
        analysis_task_profile = dict(task_profile)
        # L3 first, then L2: same order as the planner. Durable cross-run
        # findings frame the diagnostic; this run's observations refine it.
        blocks = []
        if task_knowledge_store is not None:
            blocks.append(task_knowledge_store.format_for_prompt())
        if knowledge_store is not None:
            blocks.append(knowledge_store.format_for_prompt())
        knowledge_summary = "\n\n".join(b for b in blocks if b)
        if knowledge_summary:
            analysis_task_profile["knowledge_summary"] = knowledge_summary
        return AnalysisAgent(
            llm=analysis_llm,
            working_dir=working_dir,
            execution_timeout=effective_timeout,
            task_profile=analysis_task_profile,
            protected_paths=protected_paths,
            editable_paths=editable_paths,
            read_paths=_task_read_paths(task, workspace_dir),
            compression_llm=analysis_llm,
            prompt_renderer=prompt_renderer,
            budget_start_time=time.time(),
            budget_total_seconds=effective_timeout * 3,
        )
    return factory


def _build_agent_factory_map(
    executor_factory,
    summarizer_factory,
    km_factory,
    analysis_factory=None,
    include_summarizer: bool = True,
    include_km: bool = True,
):
    """Assemble the planner's agent factory map.

    'analysis' is included ONLY when the task opts in (analysis_factory is not
    None), so existing benches keep exactly their original set of sub-agent
    types (executor/summarizer/knowledge_manager).
    """
    factory_map = {"executor": executor_factory}
    if include_summarizer:
        factory_map["summarizer"] = summarizer_factory
    if include_km:
        factory_map["knowledge_manager"] = km_factory
    if analysis_factory is not None:
        factory_map["analysis"] = analysis_factory
    return factory_map


def make_summarizer_factory(
    llm_registry: LLMRegistry,
    task_profile: dict,
    prompt_renderer: "PromptRenderer | None" = None,
):
    def factory(plan_dir: str):
        return SummaryAgent(
            llm=llm_registry.get("evaluator"),
            working_dir=Path(plan_dir),
            task_profile=task_profile,
            compression_llm=llm_registry.get("evaluator"),
            prompt_renderer=prompt_renderer,
            budget_start_time=time.time(),
            budget_total_seconds=1800,
        )
    return factory


def make_km_factory(
    llm_registry: LLMRegistry,
    knowledge_store: KnowledgeStore,
    task_type: str,
    metric_info: dict,
    working_dir: Path,
    prompt_renderer: "PromptRenderer | None" = None,
    task_profile: dict | None = None,
):
    def factory(summaries_text: str = "", summary_paths: list[str] | None = None):
        return KnowledgeManagerAgent(
            llm=llm_registry.get("distiller"),
            working_dir=working_dir,
            knowledge_store=knowledge_store,
            summaries=summaries_text,
            summary_paths=summary_paths or [],
            task_type=task_type,
            metric_info=metric_info,
            task_profile=task_profile,
            prompt_renderer=prompt_renderer,
            budget_start_time=time.time(),
            budget_total_seconds=1800,
        )
    return factory


def _resolve_task_info(task: TaskAdapter) -> dict[str, Any]:
    """The four task facts the run needs before anything is built.

    Pulled out of ``run()`` so ``--check-only`` can report them without starting
    a search: each one raises if the task's config is incomplete, so reading
    them is itself the first check.
    """
    return {
        "task_description": task.task_description,
        "data_dir": task.data_dir,
        "metric_name": task.metric_name,
        "lower_is_better": task.metric_lower_is_better,
    }


def _link_technique_cards(workspace_dir: Path) -> None:
    """Link the packaged technique cards into the run workspace.

    The planner's file tools reject absolute paths outside the run workspace, so
    the cards are only reachable through a link inside it.
    """
    source = Path(__file__).resolve().parent / "knowledge"
    if not source.is_dir():
        return
    link = workspace_dir / "knowledge"
    if link.is_symlink() or link.exists():
        return
    os.symlink(str(source), str(link))


def _seed_incumbent(
    task: TaskAdapter,
    workspace_dir: Path,
    incumbent_from: Path,
) -> float | None:
    """Adopt a pre-measured anchor as this run's starting incumbent.

    Lets the run open a candidate_improvement immediately instead of spending a
    training slot reproducing a baseline it already has a verified score for.
    Returns that verified score so the planner is told the starting point.

    Deliberately not wrapped in try/except: a bad anchor must stop the run rather
    than silently degrade it into an unanchored search, where every later delta
    would be measured against nothing.
    """
    seeder = getattr(task, "seed_incumbent_from", None)
    if seeder is None:
        raise SystemExit(f"--incumbent-from is not supported by {type(task).__name__}")
    state = seeder(Path(incumbent_from), workspace_dir)
    seeded_score = state.get(task.metric_name)
    # A task that supplies no baseline has no command to measure a reference
    # with, so without this the seeded incumbent is unbeatable-in-practice:
    # every later candidate would be judged against nothing and come back
    # invalid. The seeded score is that reference.
    if seeded_score is not None and not getattr(
        task, "has_supplied_baseline", True
    ):
        task.record_baseline_reference(
            workspace_dir, float(seeded_score), "incumbent_seed"
        )
    logger.info(
        "Seeded incumbent from %s: %s=%s (reference baseline %s)",
        incumbent_from,
        task.metric_name,
        seeded_score,
        state.get(task.baseline_metric_key),
    )
    return seeded_score


def _continue_from_previous_run(task: TaskAdapter, workspace_dir: Path) -> float | None:
    """Adopt the best snapshot a previous run of this task left behind.

    For a task that supplies no baseline there is nothing to reproduce, so
    runs chain: each one starts from the best accepted result of the runs
    before it — the same adoption ``--incumbent-from`` performs manually —
    and only the very first run generates a baseline from scratch. A broken
    or stale snapshot falls back to generating rather than stopping the run:
    regenerating is cheap, blocking on a bad anchor is not.
    """
    seeder = getattr(task, "seed_incumbent_from", None)
    if seeder is None:
        return None

    task_root = workspace_dir.parent
    candidates: list[tuple[float, Path]] = []
    for run_dir in sorted(task_root.iterdir()):
        if not run_dir.is_dir() or run_dir == workspace_dir:
            continue
        final = run_dir / "final"
        if not final.exists():
            continue
        snapshot = final.resolve()
        metrics_path = snapshot / "metrics.json"
        if not metrics_path.is_file():
            continue
        try:
            metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
            score = float(metrics.get(task.metric_name, metrics.get("score")))
        except (OSError, ValueError, TypeError):
            continue
        # NaN would poison the min/max below (every comparison against it is
        # False), so a snapshot with a non-finite score is no candidate at all.
        if not math.isfinite(score):
            continue
        candidates.append((score, snapshot))

    if not candidates:
        logger.info(
            "No previous run to continue from under %s; the first round will "
            "generate a baseline.",
            task_root,
        )
        return None

    pick = min if task.metric_lower_is_better else max
    best_score, best_snapshot = pick(candidates, key=lambda item: item[0])
    try:
        state = seeder(
            best_snapshot, workspace_dir, mode_label="cross_run_continuation"
        )
    except Exception as exc:
        logger.warning(
            "Continuing from %s failed (%s); the first round will generate a "
            "baseline instead.",
            best_snapshot,
            exc,
        )
        return None

    seeded_score = float(state.get(task.metric_name, best_score))
    recorder = getattr(task, "record_baseline_reference", None)
    if recorder is not None:
        recorder(workspace_dir, seeded_score, "cross_run_seed")
    logger.info(
        "Continued from previous run: incumbent %s=%s (snapshot %s)",
        task.metric_name,
        seeded_score,
        best_snapshot,
    )
    return seeded_score


def check_only(
    task: TaskAdapter, workspace_dir: Path, submission: Path | None = None
) -> int:
    """Prove a task's contract holds before spending a search on it.

    Runs the adapter's own self-check and prints it as a checklist. The point of
    doing this separately is that all three things it verifies — the baseline
    runs, the evaluation prints the metric the document named, and the same
    submission scores the same number twice — are silent when they fail during a
    real run: the search just produces deltas that mean nothing.
    """
    checker = getattr(task, "check", None)
    if checker is None:
        print(f"{type(task).__name__} does not implement check()")
        return 2

    # Resolved here: a relative path on the command line is relative to the
    # user's shell, but the evaluation command runs with its cwd set to the
    # task directory, where the same string means something else or nothing.
    if submission is not None:
        submission = submission.resolve()

    print(f"checking {type(task).__name__} in {workspace_dir}")
    report = checker(workspace_dir, submission) if submission else checker(workspace_dir)
    for step in report.get("steps", []):
        mark = "ok  " if step.get("ok") else "FAIL"
        detail = step.get("detail", "")
        print(f"  [{mark}] {step['step']}" + (f" — {detail}" if detail else ""))

    if report.get("ok"):
        print(
            f"\nready: metric={report.get('metric')} "
            f"direction={report.get('direction')}"
        )
        return 0
    print("\nnot ready — fix the failing step above before starting a run.")
    return 1


def run(
    config_path: Path,
    workspace_dir: Path,
    task: TaskAdapter,
    incumbent_from: Path | None = None,
    method_label: str | None = None,
):
    config = load_config(config_path)
    BaseLLM.set_cost_log_path(workspace_dir / "api_costs.jsonl")
    recorder = get_recorder()
    recorder.update_metadata(
        task_name=workspace_dir.parent.name,
        method_label=method_label or config.ablation.method_label,
        ablation=config.ablation.model_dump(),
        benchmark="mlebench" if hasattr(task, "competition_id") else "generic",
        competition_id=getattr(task, "competition_id", None),
        evaluation_protocol=getattr(task, "evaluation_protocol", "validation"),
        score_split=getattr(task, "score_split", "validation"),
        config_path=str(config_path.resolve()), metric=task.metric_name,
        metric_lower_is_better=task.metric_lower_is_better,
        budget=config.budget.model_dump(),
        runner_timeout=config.runner.timeout,
        executor_context=config.executor_context.model_dump(),
        models={role: {
            "model": item.model, "provider": item.provider,
            "pricing": item.pricing, "include_stream_usage": item.include_stream_usage,
            "input_tokens_include_cache": item.input_tokens_include_cache,
        } for role, item in config.llm.items()},
        requested_incumbent=str(incumbent_from.resolve()) if incumbent_from else None,
    )
    status = "failed"
    try:
        result = _run(config, workspace_dir, task, incumbent_from)
        status = "succeeded" if result.success else "failed"
        return result
    except BaseException as exc:
        status = "interrupted" if not isinstance(exc, Exception) else "failed"
        raise
    finally:
        try:
            recorder.finish(status)
        except Exception:
            logger.warning("Failed to finalize API usage summary", exc_info=True)


def _run(
    config: AutoResearchConfig,
    workspace_dir: Path,
    task: TaskAdapter,
    incumbent_from: Path | None = None,
):
    llm_registry = LLMRegistry(config.llm)
    abl = config.ablation
    knowledge_enabled = not abl.no_knowledge_mgmt
    analysis_enabled = task.wants_analysis_agents and config.task.analysis_agents and not abl.solution_only
    experiment_max_concurrent = 1 if abl.single_executor else config.budget.max_concurrent
    logger.info("Ablation: %s; executor concurrency=%d; analysis=%s; knowledge=%s",
                abl.model_dump(), experiment_max_concurrent, analysis_enabled, knowledge_enabled)

    workspace_dir.mkdir(parents=True, exist_ok=True)

    # === Resolve task info from adapter ===
    info = _resolve_task_info(task)
    task_desc = info["task_description"]
    metric_name = info["metric_name"]
    lower_is_better = info["lower_is_better"]

    working_dir = workspace_dir / "working"
    working_dir.mkdir(parents=True, exist_ok=True)
    _link_technique_cards(workspace_dir)
    task.setup_workspace(workspace_dir)

    if incumbent_from is not None:
        baseline_score = _seed_incumbent(task, workspace_dir, incumbent_from)
    else:
        baseline_score = None

    # A task that supplies no baseline has nothing to reproduce. Its runs
    # chain instead: the best snapshot a previous run left behind becomes
    # this run's starting incumbent — the same adoption --incumbent-from
    # performs manually — and only the very first run generates a baseline.
    if baseline_score is None and not getattr(task, "has_supplied_baseline", True):
        baseline_score = _continue_from_previous_run(task, workspace_dir)

    recorder = get_recorder()
    state_reader = getattr(task, "_load_incumbent_state", None)
    incumbent_state = state_reader(workspace_dir) if state_reader else None
    recorder.update_metadata(
        incumbent_loaded=incumbent_state is not None,
        incumbent_source=incumbent_state.get("snapshot_path") if incumbent_state else None,
        initial_score=baseline_score,
    )

    # === Hardware detection ===
    hardware_info = detect_hardware()
    if config.hardware.compute_tier != "auto":
        hardware_info.has_gpu = config.hardware.compute_tier != "cpu_only"
    hardware_constraint = ""
    if config.hardware.inject_constraint:
        # Both pools can hold GPU work at once, so the number the agent is told is
        # their sum. Understating it is how "size to what you have" turns into an
        # OOM the agent then misreads as its own model being too large.
        hardware_constraint = hardware_info.to_constraint_str(
            gpu_sharers=experiment_max_concurrent
            + (config.budget.analysis_max_concurrent if analysis_enabled else 0)
        )
    logger.info(
        "Hardware: %s (tier=%s, RAM=%.1fGB, %d cores)",
        hardware_info.gpu_name or "CPU only", hardware_info.compute_tier,
        hardware_info.ram_gb, hardware_info.cpu_count,
    )

    # === Knowledge stores: L2 (this run) and L3 (across runs) ===
    #
    # L2 lives beside the run it describes, so it dies with the timestamped
    # workspace — which is correct for observations like "exp003's lr was too
    # high", but meant that nothing at all survived a restart.
    #
    # L3 sits one level up, in the per-task directory shared by every run of this
    # task, and is deliberately uncapped: it is the only place a durable finding
    # can accumulate. Keeping the two apart is not tidiness. They share a
    # relation graph keyed by cid, both would start numbering at 1, and L2's
    # capacity eviction sorts by confidence — which has nothing to do with
    # whether a claim is durable, so a mixed store would let this run's noise
    # evict a fact learned three runs ago.
    knowledge_store = KnowledgeStore(max_items=config.memory.l2_max_items) # defalut = 12
    knowledge_path = workspace_dir / "knowledge.json"
    if knowledge_enabled and knowledge_path.exists():
        knowledge_store.load(knowledge_path)

    task_knowledge_store = KnowledgeStore(
        max_items=None,
        cid_prefix="T",
        label="Durable Task Knowledge Carried Across Runs (L3 Memory)",
    )
    task_knowledge_path = workspace_dir.parent / "task_knowledge.json"
    if knowledge_enabled and task_knowledge_path.exists():
        task_knowledge_store.load(task_knowledge_path)
        logger.info(
            "Loaded %d durable L3 claim(s) from %s",
            len(task_knowledge_store.insights),
            task_knowledge_path,
        )
    elif knowledge_enabled:
        logger.info("No L3 task knowledge yet at %s (first run)", task_knowledge_path)
    else:
        logger.info("Knowledge management disabled; L2/L3 are not loaded")

    recorder.update_metadata(
        hardware=hardware_info.to_dict(),
        l3_loaded=knowledge_enabled and task_knowledge_path.exists(),
        l3_initial_claims=len(task_knowledge_store.insights),
        effective_executor_concurrency=experiment_max_concurrent,
        analysis_enabled=analysis_enabled,
        knowledge_enabled=knowledge_enabled,
    )

    # The task's own document is the brief. There used to be an LLM profiling pass
    # here that previewed the data and guessed a task type, target column and
    # sample-submission shape before the loop started. It was removed rather than
    # generalized: every question it answered is already answered in the document
    # the task author wrote, and the way it answered them — read train.csv, guess the
    # target, cross-check sample_submission.csv, build stratified folds — assumed
    # a tabular Kaggle layout that a segmentation or ASR task does not have.
    metric_info = {
        "name": metric_name or "score",
        "lower_is_better": lower_is_better,
    }
    orientation_text = ""

    task_profile = task.get_task_context()
    task_profile["hardware"] = hardware_info.to_dict()
    task_profile["hardware_constraint"] = hardware_constraint
    task_profile["total_time_seconds"] = config.budget.total_time_seconds
    task_profile["execution_timeout"] = config.runner.timeout
    task_profile["ablation"] = abl.model_dump()
    task_profile["analysis_enabled"] = analysis_enabled
    task_profile["knowledge_enabled"] = knowledge_enabled
    task_profile["experiment_max_concurrent"] = experiment_max_concurrent

    budget_start = time.time()
    budget_total = float(config.budget.total_time_seconds)

    # One renderer shared by every role. Benchmark templates extend framework
    # blocks; generic task documents keep the default role templates.
    prompt_renderer = PromptRenderer(task.get_prompts_dir())

    # === Sub-agent factories ===
    executor_factory = make_executor_factory(
        llm_registry, task_profile, hardware_constraint,
        config.runner.timeout, budget_start, budget_total,
        workspace_dir=workspace_dir,
        task=task,
        protected_paths=task.protected_paths,
        editable_paths=task.editable_paths,
        prompt_renderer=prompt_renderer,
        executor_context=config.executor_context,
    )
    summarizer_factory = make_summarizer_factory(
        llm_registry, task_profile, prompt_renderer=prompt_renderer,
    )
    km_factory = make_km_factory(
        llm_registry, knowledge_store,
        task_profile.get("task_type", DEFAULT_TASK_TYPE), metric_info,
        workspace_dir / "working",
        prompt_renderer=prompt_renderer,
        task_profile=task_profile,
    )

    # Concurrency is the only GPU control the framework keeps, and it is a config
    # number rather than a lock. The framework used to serialize GPU work outright
    # for tasks that asked for it, which meant blocking every python_run/bash on a
    # host lock — including the ones that never touch the GPU — with no bound on
    # the wait and nothing in the log to show an agent was queued rather than
    # working. What replaces it is information, not policy: agents are told how
    # many of them share the card and to size their work against free memory
    # (see utils/hardware.py), and a CUDA OOM comes back labelled with how many
    # experiments were in flight so a collision is not mistaken for "this model
    # was too big".
    subagent_manager = SubAgentManager(
        max_workers=experiment_max_concurrent,
        timeout_per_agent=config.runner.timeout * 3,
    )
    analysis_subagent_manager = SubAgentManager(
        max_workers=config.budget.analysis_max_concurrent,
        timeout_per_agent=config.runner.timeout,
    )

    # === Phase 1: ReAct Search Loop ===
    #    PlannerAgent 拿到"任务描述 + 任务画像 + 知识库 + 子 Agent 工厂 + 预算"这些信息后,自主进行 ReAct 循环：
    #    写实验计划 → 派发 Executor 跑实验 → 派发 Analysis 诊断 → 派发 Summarizer 总结 →
    #    派发 KnowledgeManager 沉淀经验 → 循环直到预算耗尽或主动 finish。
    logger.info("=== Phase 1: ReAct Search Loop ===")
    planner = PlannerAgent(
        llm=llm_registry.get("planner"),
        working_dir=workspace_dir / "working",
        task_description=task_desc,
        task_profile=task_profile,
        knowledge_store=knowledge_store if knowledge_enabled else None,
        task_knowledge_store=task_knowledge_store if knowledge_enabled else None,
        agent_factory_map=_build_agent_factory_map(
            executor_factory, summarizer_factory, km_factory,
            analysis_factory=(
                make_analysis_factory(
                    llm_registry, task_profile,
                    config.runner.timeout, budget_start, budget_total,
                    workspace_dir=workspace_dir,
                    task=task,
                    protected_paths=task.protected_paths,
                    editable_paths=task.editable_paths,
                    prompt_renderer=prompt_renderer,
                    knowledge_store=knowledge_store if knowledge_enabled else None,
                    task_knowledge_store=task_knowledge_store if knowledge_enabled else None,
                )
                if analysis_enabled
                else None
            ),
            include_summarizer=knowledge_enabled,
            include_km=knowledge_enabled,
        ),
        subagent_manager=subagent_manager,
        subagent_managers={"analysis": analysis_subagent_manager},
        hardware_constraint=hardware_constraint,
        orientation_text=orientation_text,
        compression_llm=llm_registry.get("evaluator"),
        prompt_renderer=prompt_renderer,
        best_score=baseline_score,
        model_context_length=200_000,
        budget_start_time=budget_start,
        budget_total_seconds=budget_total,
    )

    result = planner.run()

    # === Phase 2: Publish the accepted model's snapshot as the deliverable ===
    #    No evaluation happens here. The score was measured during the search and
    #    is copied out of the snapshot's metrics.json; this phase links, lists and
    #    reports. The name used to promise a held-out evaluation the framework has
    #    no split to perform.
    logger.info("=== Phase 2: Deliverable ===")
    final_report = _finalize(task, workspace_dir)
    recorder.update_metadata(best_score=final_report.get("score"), score_split=task.score_split)

    # === Phase 3: Persistence ===
    logger.info("=== Phase 3: Persistence ===")
    if knowledge_enabled:
        knowledge_store.save(knowledge_path)

    # Promote this run's durable findings into the task-level L3 store. Runs after
    # L2 is saved so a failure here cannot cost the run-local knowledge, and is
    # wrapped because the run's real output (submission, incumbent, metrics) is
    # already on disk — losing the promotion pass should degrade the next run's
    # starting context, not fail this one.
    if knowledge_enabled and knowledge_store.insights:
        try:
            promoter = KnowledgePromoterAgent(
                llm=(
                    llm_registry.get("promoter")
                    if llm_registry.has("promoter")
                    else llm_registry.get("distiller")
                ),
                working_dir=working_dir,
                knowledge_store=task_knowledge_store,
                summaries=knowledge_store.format_for_prompt(),
                task_type=task_profile.get("task_type", DEFAULT_TASK_TYPE),
                metric_info=metric_info,
                task_profile=task_profile,
                prompt_renderer=prompt_renderer,
                budget_start_time=time.time(),
                # 900s no longer covers the pass: it now sweeps every experiment's
                # metrics.json for cross-experiment regularities before writing, and
                # a claim plus its relations is one tool call each. This runs after the
                # research deadline, so the cost is delaying the next run's start, not
                # taking time from this run's experiments.
                budget_total_seconds=1800,
            )
            before = len(task_knowledge_store.insights)
            promoter.run()
            task_knowledge_store.save(task_knowledge_path)
            logger.info(
                "L3 promotion: %d -> %d durable claim(s) at %s",
                before,
                len(task_knowledge_store.insights),
                task_knowledge_path,
            )
            # Also snapshot L3 into this run's directory. task_knowledge.json is
            # rewritten by every run, so it only ever holds the latest state —
            # without a per-run copy there is no way to tell which run created,
            # sharpened, or refuted a claim. Diffing consecutive snapshots
            # reconstructs the full L3 history. Guarded separately so a failed
            # snapshot is reported as such and not as a failed promotion.
            try:
                task_knowledge_store.save(workspace_dir / "l3_snapshot.json")
            except Exception as e:
                logger.warning("L3 per-run snapshot failed: %s", e)
        except Exception as e:
            logger.warning("L3 promotion pass failed (L2 knowledge is saved): %s", e)
    elif knowledge_enabled:
        logger.info("L3 promotion skipped: this run produced no L2 claims")
    else:
        logger.info("L3 promotion disabled by no_knowledge_mgmt")

    # Merge orchestrator usage (api_costs.jsonl) with any eval-subprocess usage
    # (subprocess_tokens.jsonl — browsecomp solver/grader, tau3 agent/user LLMs).
    cost = BaseLLM.get_cost_summary(
        extra_paths=[workspace_dir / "subprocess_tokens.jsonl"]
    )
    if cost:
        logger.info(
            "API usage: %d calls, %s input tokens, %s output tokens, missing usage=%d, estimated USD=%s",
            cost["calls"], f'{cost["input_tokens"]:,}', f'{cost["output_tokens"]:,}',
            cost["usage_missing_calls"], cost["total_cost"],
        )
        for agent_name, s in sorted(
            cost.get("by_agent", {}).items(), key=lambda kv: -kv[1]["input_tokens"]
        ):
            logger.info(
                "  [agent] %-24s %d calls, %s in / %s out tokens, estimated USD=%s",
                agent_name, s["calls"],
                f'{s["input_tokens"]:,}', f'{s["output_tokens"]:,}', s["cost"],
            )
        for exp_name, s in sorted(
            cost.get("by_experiment", {}).items(), key=lambda kv: -kv[1]["input_tokens"]
        ):
            logger.info(
                "  [experiment] %-20s %d calls, %s in / %s out tokens, estimated USD=%s",
                exp_name, s["calls"],
                f'{s["input_tokens"]:,}', f'{s["output_tokens"]:,}', s["cost"],
            )

    logger.info(
        "PlannerAgent finished: success=%s, iterations=%d",
        result.success, result.iterations_used,
    )
    return result


# Third-party libraries whose DEBUG chatter (per-request HTTP framing, font
# cache scans, deprecation notes) buries the framework's own log lines.
_NOISY_LIBRARIES = frozenset({
    "httpx", "openai", "httpcore", "urllib3",
    "matplotlib", "graphviz", "h5py", "PIL", "tensorflow", "asyncio",
    "filelock", "fsspec", "botocore", "s3transfer",
})


class _ThirdPartyNoiseFilter(logging.Filter):
    """Drop third-party chatter; keep every level from our own loggers."""

    def filter(self, record: logging.LogRecord) -> bool:
        return record.name.split(".")[0] not in _NOISY_LIBRARIES


class _ConsoleFilter(_ThirdPartyNoiseFilter):
    def filter(self, record: logging.LogRecord) -> bool:
        return super().filter(record) and record.levelno >= logging.INFO


def _setup_logging(run_workspace: Path, verbose: bool = False) -> None:
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG if verbose else logging.INFO)
    console.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S",
    ))
    if not verbose:
        console.addFilter(_ConsoleFilter())
    root.addHandler(console)

    run_workspace.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(run_workspace / "run.log", encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s [%(name)s] %(levelname)s: %(message)s"))
    # run.log keeps DEBUG from our own loggers but not from third parties --
    # without this the file handler recorded every HTTP frame, so a short run
    # produced megabytes in which the framework's INFO lines were <1%.
    if not verbose:
        fh.addFilter(_ThirdPartyNoiseFilter())
    root.addHandler(fh)


def main():
    autoresearch_dir = Path(__file__).parent
    default_workspace = autoresearch_dir / "workspace"

    parser = argparse.ArgumentParser(description="AutoResearch ReAct Agent")
    default_config = autoresearch_dir / "config" / "default_config.yaml"
    parser.add_argument("--config", type=Path, default=default_config)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--task-dir", type=Path, default=None,
                        help="Task directory (e.g. tasks/example_rmse, holding task.md)")
    source.add_argument("--bench", choices=["mlebench"],
                        help="Legacy benchmark adapter; mlebench loads tasks by competition ID")
    parser.add_argument("--competition-id", help="Kaggle competition ID (required for --bench mlebench)")
    parser.add_argument("--bench-dir", type=Path,
                        help="MLE-bench prepared data root; defaults to MLEBENCH_DATA_DIR or its registry default")
    parser.add_argument("--workspace", type=Path, default=default_workspace)
    parser.add_argument("--method-label", default=None,
                        help="Optional reporting label; defaults to enabled ablation flags; does not change the algorithm")
    parser.add_argument("--incumbent-from", type=Path, default=None,
                        help="Pre-measured baseline snapshot directory to adopt as the "
                             "initial incumbent, skipping the supplied-baseline "
                             "reproduction round (e.g. .../accepted/exp000_baseline_anchor)")
    parser.add_argument("--check-only", action="store_true",
                        help="Verify this task is runnable and exit: the baseline "
                             "runs, the evaluation prints the metric the document "
                             "named, and the same submission scores the same number "
                             "twice. Costs one baseline run and no LLM calls. A task "
                             "that supplies no baseline gets a reduced check here — "
                             "document, data, workspace — because its reference is "
                             "established by the run's first generated-baseline round.")
    parser.add_argument("--check-submission", type=Path, default=None,
                        help="With --check-only: score this existing submission instead "
                             "of training the baseline to produce one. Use it when the "
                             "baseline is hours of GPU time — the checks that matter "
                             "need any valid submission, not specifically the baseline's.")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args()

    if args.bench and not args.competition_id:
        parser.error("--bench mlebench requires --competition-id")
    if not args.bench and (args.competition_id or args.bench_dir):
        parser.error("--competition-id and --bench-dir require --bench mlebench")
    if args.check_submission and not args.check_only:
        parser.error("--check-submission requires --check-only")

    config = load_config(args.config)
    run_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

    # Validate the adapter before deriving a path from the competition ID.
    try:
        if args.bench:
            task = create_adapter(
                args.bench, args.bench_dir, competition_id=args.competition_id,
                task_settings=config.task.model_dump(),
            )
            run_name = str(Path(args.bench) / args.competition_id)
        else:
            task = GenericAdapter(args.task_dir, task_settings=config.task.model_dump())
            run_name = args.task_dir.name
    except (ValueError, FileNotFoundError, ModuleNotFoundError) as exc:
        print(f"cannot read the task: {exc}", file=sys.stderr)
        raise SystemExit(2) from None
    # Resolve to an absolute path up front. Downstream, executor/planner working
    # dirs are derived from this and embedded into agent prompts; if it stays
    # relative, the file tools (which join relative args under working_dir) can
    # double-concatenate the path the model echoes back from the prompt and fail
    # with "File not found". Absolute paths are used verbatim, avoiding that.
    run_workspace = (args.workspace / run_name / run_timestamp).resolve()

    _setup_logging(run_workspace, verbose=args.verbose)
    logger.info("Run workspace: %s", run_workspace)

    logger.info("Task dir: %s", task.data_dir)

    # What keeps the search honest is that the validation labels live inside the
    # task's evaluation script: the framework never holds that path, so it cannot
    # pass it to an agent, print it in a log, or render it into a prompt. This line
    # records which splits the eval tool will accept, which is the part of that
    # arrangement the framework does enforce.
    logger.info("Scoring split(s) allowed: %s", sorted(task.allowed_eval_splits))

    # Branches before run() rather than being a subcommand: --task-dir/--config
    # mean the same thing here as they do for a real run, and subparsers would
    # break every documented `python -m autoresearch --task-dir ...` invocation
    # for one extra mode.
    if args.check_only:
        raise SystemExit(check_only(task, run_workspace, args.check_submission))

    result = run(
        config_path=args.config,
        workspace_dir=run_workspace,
        task=task,
        incumbent_from=args.incumbent_from,
        method_label=args.method_label,
    )
    print(f"Done: success={result.success}, iterations={result.iterations_used}")


if __name__ == "__main__":
    main()
